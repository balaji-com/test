const mongoose = require('mongoose');

const attachmentSchema = new mongoose.Schema(
  {
    taskId:       { type: mongoose.Schema.Types.ObjectId, ref: 'Task', required: true, index: true },
    filename:     { type: String, required: true },          // original file name shown to user
    storedName:   { type: String, required: true },          // UUID-based name on disk
    mimetype:     { type: String },
    size:         { type: Number },                          // bytes
    uploadedBy:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    uploadedByName: { type: String },                        // denormalised for fast display
  },
  { timestamps: true }
);

module.exports = mongoose.model('Attachment', attachmentSchema);
