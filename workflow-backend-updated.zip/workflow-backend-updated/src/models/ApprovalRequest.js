const mongoose = require('mongoose');

const approvalRequestSchema = new mongoose.Schema(
  {
    taskId:          { type: mongoose.Schema.Types.ObjectId, ref: 'Task', required: true, index: true },
    taskName:        { type: String, required: true },
    requestedBy:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    requestedByName: { type: String },
    requestedTo:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    requestedToName: { type: String },
    message:         { type: String, maxlength: 1000 },
    comment:         { type: String, maxlength: 1000 },
    status: {
      type: String,
      enum: ['Pending', 'Approved', 'Rejected', 'Cancelled'],
      default: 'Pending',
      index: true,
    },
    resolvedAt: { type: Date },
  },
  { timestamps: true }
);

approvalRequestSchema.index({ requestedTo: 1, status: 1 });
approvalRequestSchema.index({ requestedBy: 1, status: 1 });

module.exports = mongoose.model('ApprovalRequest', approvalRequestSchema);
