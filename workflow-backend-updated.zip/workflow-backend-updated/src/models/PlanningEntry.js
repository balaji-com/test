const mongoose = require('mongoose');

const planningEntrySchema = new mongoose.Schema(
  {
    week: { type: Number, min: 1 },
    publicationDate: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
    contentTitle: { type: String, required: true, trim: true, maxlength: 300 },
    offerings: { type: String, trim: true, maxlength: 500 },
    segmentsIndustries: { type: String, trim: true, maxlength: 500 },
    format: { type: String, trim: true, maxlength: 200 },
    contentObjectives: { type: String, trim: true, maxlength: 500 },
    contentPillars: { type: String, trim: true, maxlength: 500 },
    targetAudience: { type: String, trim: true, maxlength: 500 },
    channel: { type: String, trim: true, maxlength: 500 },
    kpi: { type: String, trim: true, maxlength: 500 },
    assignedTo: { type: String, trim: true, maxlength: 200 },
    submissionDueDate: { type: String, trim: true },
    submissionActualDate: { type: String, trim: true },
    reviewer: { type: String, trim: true, maxlength: 200 },
    reviewDueDate: { type: String, trim: true },
    reviewActualDate: { type: String, trim: true },
    depositoryLink: { type: String, trim: true, maxlength: 2048 },
    postedLink: { type: String, trim: true, maxlength: 2048 },
    status: { type: String, trim: true, maxlength: 100 },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    importBatchId: { type: String, required: true },
    sourceFileName: { type: String, required: true, maxlength: 255 },
  },
  { timestamps: true }
);

planningEntrySchema.index({ createdBy: 1, publicationDate: 1 });
planningEntrySchema.index({ importBatchId: 1 });

module.exports = mongoose.model('PlanningEntry', planningEntrySchema);
