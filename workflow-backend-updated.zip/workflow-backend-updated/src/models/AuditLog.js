const mongoose = require('mongoose');

const auditSchema = new mongoose.Schema(
  {
    action:     { type: String, required: true },
    user:       { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    userName:   { type: String },
    taskId:     { type: mongoose.Schema.Types.ObjectId, ref: 'Task' },
    taskName:   { type: String },
    assignedTo: { type: String },
    extra:      { type: String },
    changes:    { type: mongoose.Schema.Types.Mixed },
  },
  { timestamps: true }
);

auditSchema.index({ createdAt: -1 });
auditSchema.index({ user: 1 });

module.exports = mongoose.model('AuditLog', auditSchema);
