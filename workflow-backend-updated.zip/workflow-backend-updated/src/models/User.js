const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

// ── Module permission levels ───────────────────────────────────────
const ACCESS_LEVELS = ['no_access', 'viewer', 'editor', 'admin'];

// ── All navigable modules ──────────────────────────────────────────
const MODULE_KEYS = [
  'my_tasks', 'all_works', 'reminders', 'kanban', 'approvals',
  'calendar', 'planner',
  'team_overview', 'monthly_reports',
  'seo_checker', 'topic_selector',
  'ai_configuration', 'customize_fields', 'add_members',
  'audit_log', 'backup', 'change_password',
];

// Build default permissions object: every module = 'no_access'
const defaultPermissions = () => {
  const p = {};
  MODULE_KEYS.forEach(k => { p[k] = 'no_access'; });
  return p;
};

// Build member default: member gets editor on task-related modules
const memberDefaultPermissions = () => {
  const p = defaultPermissions();
  ['my_tasks', 'all_works', 'reminders', 'kanban', 'approvals',
   'calendar', 'planner', 'change_password'].forEach(k => { p[k] = 'editor'; });
  ['team_overview', 'monthly_reports'].forEach(k => { p[k] = 'viewer'; });
  return p;
};

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String, required: [true, 'Name is required'],
      trim: true, minlength: 2, maxlength: 15,
    },
    email: {
      type: String, required: [true, 'Email is required'],
      unique: true, lowercase: true, trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Invalid email address'],
    },
    password: {
      type: String, required: [true, 'Password is required'],
      minlength: 4, select: false,
    },
    role: {
      type: String,
      enum: ['admin', 'member', 'viewer'],
      default: 'member',
    },
    isAdmin:  { type: Boolean, default: false },
    isActive: { type: Boolean, default: true  },
    color:    { type: String,  default: '#c8890a' },

    // ── Per-module permissions (only meaningful for role=member/viewer) ──
    permissions: {
      type: Map,
      of:   { type: String, enum: ACCESS_LEVELS, default: 'no_access' },
      default: memberDefaultPermissions,
    },

    refreshToken:      { type: String, select: false },
    passwordChangedAt: Date,
    lastLogin:         Date,
  },
  { timestamps: true }
);

// ── Hash password before save ──────────────────────────────────────
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  if (!this.isNew) this.passwordChangedAt = new Date();
  next();
});

// ── Instance methods ───────────────────────────────────────────────
userSchema.methods.comparePassword = async function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.changedPasswordAfter = function (jwtIat) {
  if (this.passwordChangedAt) {
    return Math.round(this.passwordChangedAt.getTime() / 1000) > jwtIat;
  }
  return false;
};

// Check if user can access a module at a given level
userSchema.methods.canAccess = function (moduleKey, requiredLevel = 'viewer') {
  if (this.isAdmin || this.role === 'admin') return true;
  const order = ACCESS_LEVELS;
  const userLevel = this.permissions?.get(moduleKey) || 'no_access';
  return order.indexOf(userLevel) >= order.indexOf(requiredLevel);
};

// ── Serialise: remove sensitive fields ────────────────────────────
userSchema.methods.toJSON = function () {
  const obj = this.toObject();
  // Convert Map → plain object for JSON
  if (obj.permissions instanceof Map) {
    obj.permissions = Object.fromEntries(obj.permissions);
  }
  delete obj.password;
  delete obj.refreshToken;
  delete obj.__v;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
module.exports.MODULE_KEYS   = MODULE_KEYS;
module.exports.ACCESS_LEVELS = ACCESS_LEVELS;
module.exports.memberDefaultPermissions = memberDefaultPermissions;
