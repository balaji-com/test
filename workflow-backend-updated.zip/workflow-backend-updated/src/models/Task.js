const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema(
  {
    task:             { type: String, required: [true, 'Task name is required'], trim: true, maxlength: 300 },
    assignedTo:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assignedToName:   { type: String },
    createdBy:        { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

    status: {
      type: String,
      enum: ['Not Started', 'In Progress', 'In Review', 'Completed'],
      default: 'Not Started',
    },
    priority: {
      type: String,
      enum: ['High', 'Medium', 'Low'],
      default: 'Medium',
    },

    fn:   { type: String, trim: true },   // Function
    cat:  { type: String, trim: true },   // Category
    sub:  { type: String, trim: true },   // Sub-category
    month:{ type: String },
    year: { type: String },

    dueDate:   { type: String },
    startDate: { type: String },
    estHrs:    { type: String },
    actHrs:    { type: String },
    rework:    { type: Number, default: 0 },

    notes:            { type: String, maxlength: 2000 },
    link:             { type: String, trim: true, maxlength: 2048 },
    brief:            { type: String, enum: ['Given', 'Not Given', 'NA'], default: 'NA' },
    internalCustomer: { type: String },

    approvalStatus:  { type: String, enum: ['', 'Pending', 'Approved', 'Rejected'], default: '' },
    approvalTo:      { type: String },
    approvalComment: { type: String },

    reviewers: [{ type: String }],

    recurEnabled: { type: Boolean, default: false },
    recurFreq:    { type: String },
    recurEnd:     { type: String },
  },
  { timestamps: true }
);

// ── Indexes ────────────────────────────────────────────────────────
taskSchema.index({ assignedTo: 1, status: 1 });
taskSchema.index({ dueDate: 1 });
taskSchema.index({ createdBy: 1 });

module.exports = mongoose.model('Task', taskSchema);
