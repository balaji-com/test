const jwt = require('jsonwebtoken');

// ── Sign tokens ────────────────────────────────────────────────────
const signAccessToken = (userId) =>
  jwt.sign({ id: String(userId) }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m',   // short-lived
  });

const signRefreshToken = (userId) =>
  jwt.sign({ id: String(userId) }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  });

// ── Verify tokens — return null instead of throwing ───────────────
// Callers that need the decoded payload can check for null.
const verifyAccessToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return null;
  }
};

const verifyRefreshToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_REFRESH_SECRET);
  } catch {
    return null;
  }
};

// ── Cookie options ─────────────────────────────────────────────────
// sameSite:'lax'  → cookie sent on same-site and top-level cross-site navigations.
// In development (HTTP) secure must be false or the browser won't store the cookie.
// In production (HTTPS) set secure:true.
const cookieOptions = (days = 30) => ({
  httpOnly:  true,                                         // JS cannot access it
  secure:    process.env.NODE_ENV === 'production',        // HTTPS only in prod
  sameSite:  process.env.NODE_ENV === 'production' ? 'none' : 'lax', // 'none' requires secure
  maxAge:    days * 24 * 60 * 60 * 1000,
  path:      '/',
});

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  cookieOptions,
};
