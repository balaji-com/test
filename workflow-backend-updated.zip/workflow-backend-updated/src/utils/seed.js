require('dotenv').config();
const mongoose = require('mongoose');
const User     = require('../models/User');
const Task     = require('../models/Task');

const seed = async () => {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB');

  // Clear existing
  await User.deleteMany({});
  await Task.deleteMany({});
  console.log('Cleared existing data');

  // ── Seed users ─────────────────────────────────────────────────
  const users = await User.insertMany([
    { name: 'Admin',   email: 'admin@hinduja.com',   password: 'admin123',   role: 'admin',  isAdmin: true,  color: '#c8890a' },
    { name: 'Sunitha', email: 'sunitha@hinduja.com', password: 'sunitha123', role: 'member', isAdmin: false, color: '#0aab78' },
    { name: 'Priya',   email: 'priya@hinduja.com',   password: 'priya123',   role: 'member', isAdmin: false, color: '#6336d6' },
    { name: 'Ramesh',  email: 'ramesh@hinduja.com',  password: 'ramesh123',  role: 'viewer', isAdmin: false, color: '#0887b0' },
  ]);
  console.log(`Created ${users.length} users`);

  const [admin, sunitha, priya, ramesh] = users;

  // ── Seed tasks ─────────────────────────────────────────────────
  const today = new Date().toISOString().slice(0, 10);
  const past  = '2026-05-31';
  const future = '2026-07-05';

  const tasks = await Task.insertMany([
    { task: 'Write Q2 Blog Post — Cloud Security', assignedTo: sunitha._id, assignedToName: 'Sunitha', createdBy: admin._id, status: 'In Progress', priority: 'High', fn: 'External Communication', cat: 'Content', sub: 'Blog', month: 'June', year: '2026', dueDate: today, startDate: '2026-06-01', estHrs: '4', actHrs: '2', rework: 0, brief: 'Given' },
    { task: 'Design LinkedIn Banner — World Environment Day', assignedTo: priya._id, assignedToName: 'Priya', createdBy: admin._id, status: 'Not Started', priority: 'Medium', fn: 'Social Media', cat: 'Design', sub: 'Banner', month: 'June', year: '2026', dueDate: past, estHrs: '2', actHrs: '0', rework: 1, brief: 'Given' },
    { task: 'Monthly Newsletter — May Edition', assignedTo: sunitha._id, assignedToName: 'Sunitha', createdBy: admin._id, status: 'Completed', priority: 'High', fn: 'Internal Communication', cat: 'Newsletter', month: 'May', year: '2026', dueDate: past, startDate: '2026-05-20', estHrs: '3', actHrs: '3.5', rework: 0, brief: 'Given', approvalStatus: 'Approved' },
    { task: 'Event Microsite Copy — Tech Summit 2026', assignedTo: sunitha._id, assignedToName: 'Sunitha', createdBy: admin._id, status: 'In Review', priority: 'High', fn: 'Events', cat: 'Copy', month: 'July', year: '2026', dueDate: future, estHrs: '6', actHrs: '4', rework: 2, brief: 'Not Given', approvalStatus: 'Pending', approvalTo: 'Admin' },
    { task: 'Social Post — World Engineering Day', assignedTo: ramesh._id, assignedToName: 'Ramesh', createdBy: admin._id, status: 'Not Started', priority: 'Low', fn: 'Social Media', cat: 'Posting', sub: 'LinkedIn', month: 'June', year: '2026', estHrs: '1', actHrs: '0', rework: 0, brief: 'NA' },
    { task: 'SEO Audit — Company Website Q2', assignedTo: priya._id, assignedToName: 'Priya', createdBy: admin._id, status: 'In Progress', priority: 'High', fn: 'SEO', cat: 'Audit', month: 'June', year: '2026', dueDate: today, estHrs: '5', actHrs: '3', rework: 0, brief: 'Given' },
  ]);
  console.log(`Created ${tasks.length} tasks`);

  console.log('\n✅ Seed complete!');
  console.log('Login credentials:');
  console.log('  admin@hinduja.com   / admin123   (Admin)');
  console.log('  sunitha@hinduja.com / sunitha123 (Member)');
  console.log('  priya@hinduja.com   / priya123   (Member)');
  console.log('  ramesh@hinduja.com  / ramesh123  (Viewer)');

  await mongoose.disconnect();
};

seed().catch(err => { console.error(err); process.exit(1); });
