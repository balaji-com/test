const AuditLog = require('../models/AuditLog');

// ── GET /api/audit ─────────────────────────────────────────────────
exports.getAuditLog = async (req, res, next) => {
  try {
    const { action, search, page = 1, limit = 25 } = req.query;
    const filter = {};

    if (action) filter.action = action;
    if (search) {
      filter.$or = [
        { taskName:   { $regex: search, $options: 'i' } },
        { userName:   { $regex: search, $options: 'i' } },
        { assignedTo: { $regex: search, $options: 'i' } },
      ];
    }

    const skip  = (parseInt(page) - 1) * parseInt(limit);
    const total = await AuditLog.countDocuments(filter);
    const logs  = await AuditLog.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      status: 'success',
      total,
      page:  parseInt(page),
      pages: Math.ceil(total / parseInt(limit)),
      data:  logs,
    });
  } catch (err) { next(err); }
};

// ── DELETE /api/audit (admin only) ────────────────────────────────
exports.clearAuditLog = async (req, res, next) => {
  try {
    await AuditLog.deleteMany({});
    res.status(200).json({ status: 'success', message: 'Audit log cleared.' });
  } catch (err) { next(err); }
};
