const ApprovalRequest = require('../models/ApprovalRequest');
const Task            = require('../models/Task');
const User            = require('../models/User');
const { AppError }    = require('../middleware/errorHandler');

// ── Helper: sync task approval state without changing task status ───
const syncTaskApprovalStatus = async (taskId) => {
  const all      = await ApprovalRequest.find({ taskId, status: { $ne: 'Cancelled' } });
  if (!all.length) {
    await Task.findByIdAndUpdate(taskId, { approvalStatus: '' });
    return;
  }
  const anyRejected  = all.some(r => r.status === 'Rejected');
  const allApproved  = all.every(r => r.status === 'Approved');

  if (anyRejected) {
    await Task.findByIdAndUpdate(taskId, { approvalStatus: 'Rejected' });
  } else if (allApproved) {
    await Task.findByIdAndUpdate(taskId, { approvalStatus: 'Approved' });
  } else {
    await Task.findByIdAndUpdate(taskId, { approvalStatus: 'Pending' });
  }
};

// ── POST /api/approvals ─────────────────────────────────────────────
// Body: { taskId, reviewers: string[], message? }
// Accepts one OR many reviewer IDs.
exports.sendRequest = async (req, res, next) => {
  try {
    const { taskId, reviewers, message } = req.body;
    if (!taskId)            return next(new AppError('taskId is required.', 400));
    if (!reviewers?.length) return next(new AppError('At least one reviewer is required.', 400));

    const task = await Task.findById(taskId);
    if (!task) return next(new AppError('Task not found.', 404));
    if (task.status === 'Completed')
      return next(new AppError('Cannot add reviewers to a completed task.', 400));

    // Validate all reviewer IDs
    const reviewerDocs = await User.find({ _id: { $in: reviewers } });
    if (reviewerDocs.length !== reviewers.length) {
      return next(new AppError('One or more reviewers not found.', 404));
    }

    // Cancel all existing pending requests for this task
    await ApprovalRequest.updateMany(
      { taskId, status: 'Pending' },
      { status: 'Cancelled', resolvedAt: new Date() }
    );

    // Create one request per reviewer
    const docs = reviewerDocs.map(reviewer => ({
      taskId,
      taskName:        task.task,
      requestedBy:     req.user._id,
      requestedByName: req.user.name,
      requestedTo:     reviewer._id,
      requestedToName: reviewer.name,
      message:         message || '',
      status:          'Pending',
    }));

    const created = await ApprovalRequest.insertMany(docs);

    // Sync task status
    await Task.findByIdAndUpdate(taskId, { approvalStatus: 'Pending' });

    // Populate for response
    const populated = await ApprovalRequest.find({ _id: { $in: created.map(r => r._id) } })
      .populate('requestedBy', 'name email color')
      .populate('requestedTo', 'name email color')
      .populate('taskId',      'task status priority');

    res.status(201).json({ status: 'success', data: populated });
  } catch (err) { next(err); }
};

// ── GET /api/approvals ──────────────────────────────────────────────
exports.listRequests = async (req, res, next) => {
  try {
    const { tab = 'inbox', page = 1, limit = 20 } = req.query;
    const userId   = req.user._id;
    const pageNum  = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, Math.max(1, parseInt(limit)));

    let filter = {};
    if (tab === 'inbox')    filter = { requestedTo: userId };
    else if (tab === 'sent') filter = { requestedBy: userId };
    else if (tab === 'resolved') {
      filter = {
        $or: [{ requestedTo: userId }, { requestedBy: userId }],
        status: { $in: ['Approved', 'Rejected', 'Cancelled'] },
      };
    } else {
      filter = { $or: [{ requestedTo: userId }, { requestedBy: userId }] };
    }

    const total    = await ApprovalRequest.countDocuments(filter);
    const requests = await ApprovalRequest.find(filter)
      .populate('requestedBy', 'name email color')
      .populate('requestedTo', 'name email color')
      .populate('taskId',      'task status priority dueDate')
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum);

    // For sent tab — enrich each request with its sibling requests (same task)
    let data = requests;
    if (tab === 'sent') {
      const taskIds = [...new Set(requests.map(r => String(r.taskId?._id || r.taskId)))];
      const allForTasks = await ApprovalRequest.find({ taskId: { $in: taskIds } })
        .populate('requestedBy', 'name email color')
        .populate('requestedTo', 'name email color');

      const byTask = {};
      for (const r of allForTasks) {
        const tid = String(r.taskId);
        if (!byTask[tid]) byTask[tid] = [];
        byTask[tid].push(r);
      }

      data = requests.map(r => {
        const tid = String(r.taskId?._id || r.taskId);
        return { ...r.toObject(), taskReviewers: byTask[tid] || [r.toObject()] };
      });
    }

    // Sidebar counts
    const inboxPending  = await ApprovalRequest.countDocuments({ requestedTo: userId, status: 'Pending' });
    const sentPending   = await ApprovalRequest.countDocuments({ requestedBy: userId, status: 'Pending' });
    const totalResolved = await ApprovalRequest.countDocuments({
      $or: [{ requestedTo: userId }, { requestedBy: userId }],
      status: { $in: ['Approved', 'Rejected', 'Cancelled'] },
    });

    res.status(200).json({
      status: 'success',
      total, page: pageNum, limit: limitNum,
      pages: Math.ceil(total / limitNum) || 1,
      counts: { inboxPending, sentPending, totalResolved },
      data,
    });
  } catch (err) { next(err); }
};

// ── PATCH /api/approvals/:id/respond ───────────────────────────────
exports.respond = async (req, res, next) => {
  try {
    const { action, comment } = req.body;
    if (!['approve', 'reject'].includes(action))
      return next(new AppError("action must be 'approve' or 'reject'.", 400));

    const request = await ApprovalRequest.findById(req.params.id);
    if (!request) return next(new AppError('Approval request not found.', 404));

    if (String(request.requestedTo) !== String(req.user._id) && !req.user.isAdmin)
      return next(new AppError('You are not the reviewer for this request.', 403));

    if (request.status !== 'Pending')
      return next(new AppError('This request is no longer pending.', 400));

    request.status     = action === 'approve' ? 'Approved' : 'Rejected';
    request.comment    = comment || '';
    request.resolvedAt = new Date();
    await request.save();

    // Approval decisions update only the approval state; task status is manual.
    await syncTaskApprovalStatus(request.taskId);

    const populated = await ApprovalRequest.findById(request._id)
      .populate('requestedBy', 'name email color')
      .populate('requestedTo', 'name email color')
      .populate('taskId',      'task status priority');

    res.status(200).json({ status: 'success', data: populated });
  } catch (err) { next(err); }
};

// ── PATCH /api/approvals/:id/cancel ────────────────────────────────
exports.cancel = async (req, res, next) => {
  try {
    const request = await ApprovalRequest.findById(req.params.id);
    if (!request) return next(new AppError('Approval request not found.', 404));

    if (String(request.requestedBy) !== String(req.user._id) && !req.user.isAdmin)
      return next(new AppError('Only the requester can cancel this.', 403));

    if (request.status !== 'Pending')
      return next(new AppError('Only pending requests can be cancelled.', 400));

    // Cancel ALL pending requests for this task (not just this one)
    await ApprovalRequest.updateMany(
      { taskId: request.taskId, status: 'Pending' },
      { status: 'Cancelled', resolvedAt: new Date() }
    );

    await Task.findByIdAndUpdate(request.taskId, { approvalStatus: '' });

    res.status(200).json({ status: 'success', data: { message: 'All pending requests cancelled.' } });
  } catch (err) { next(err); }
};

// ── GET /api/approvals/task/:taskId ────────────────────────────────
// Returns all requests + a summary for the modal's status section
exports.getTaskApprovals = async (req, res, next) => {
  try {
    const requests = await ApprovalRequest.find({
      taskId: req.params.taskId,
      status: { $ne: 'Cancelled' },
    })
      .populate('requestedBy', 'name email color')
      .populate('requestedTo', 'name email color')
      .sort({ createdAt: -1 });

    const total    = requests.length;
    const approved = requests.filter(r => r.status === 'Approved').length;
    const rejected = requests.filter(r => r.status === 'Rejected').length;
    const pending  = requests.filter(r => r.status === 'Pending').length;

    res.status(200).json({
      status: 'success',
      summary: { total, approved, rejected, pending },
      data: requests,
    });
  } catch (err) { next(err); }
};
