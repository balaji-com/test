const path       = require('path');
const fs         = require('fs');
const { randomUUID } = require('crypto');
const multer     = require('multer');
const Attachment = require('../models/Attachment');
const Task       = require('../models/Task');
const { AppError } = require('../middleware/errorHandler');
const logger     = require('../utils/logger');

// ── Upload directory ───────────────────────────────────────────────
const UPLOAD_DIR = path.join(__dirname, '../../uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const removeUploadedFile = async (file) => {
  try {
    await fs.promises.unlink(file.path);
  } catch (err) {
    if (err.code !== 'ENOENT') {
      logger.error(`Failed to remove unrecorded attachment ${file.filename}: ${err.message}`);
    }
  }
};

// ── Multer storage — UUID-named files to avoid collisions ──────────
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename:    (_req, file, cb) => {
    const ext  = path.extname(file.originalname);
    cb(null, `${randomUUID()}${ext}`);
  },
});

const FILE_SIZE_LIMIT = 10 * 1024 * 1024; // 10 MB

const upload = multer({
  storage,
  limits: { fileSize: FILE_SIZE_LIMIT },
  fileFilter: (_req, file, cb) => {
    // Allow common document / image / archive types
    const ALLOWED = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain', 'text/csv',
      'application/zip', 'application/x-zip-compressed',
    ];
    if (ALLOWED.includes(file.mimetype)) return cb(null, true);
    cb(new AppError(`File type "${file.mimetype}" is not allowed.`, 400));
  },
});

// Export the multer middleware so the route can use it
exports.uploadMiddleware = upload.single('file');

// ── POST /api/tasks/:taskId/attachments ────────────────────────────
exports.uploadAttachment = async (req, res, next) => {
  try {
    if (!req.file) return next(new AppError('No file provided.', 400));

    const task = await Task.findById(req.params.taskId);
    if (!task) {
      await removeUploadedFile(req.file);
      return next(new AppError('Task not found.', 404));
    }

    const attachment = await Attachment.create({
      taskId:         task._id,
      filename:       req.file.originalname,
      storedName:     req.file.filename,
      mimetype:       req.file.mimetype,
      size:           req.file.size,
      uploadedBy:     req.user._id,
      uploadedByName: req.user.name,
    });

    res.status(201).json({ status: 'success', data: attachment });
  } catch (err) {
    if (req.file?.path) await removeUploadedFile(req.file);
    next(err);
  }
};

// ── GET /api/tasks/:taskId/attachments ─────────────────────────────
exports.listAttachments = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.taskId);
    if (!task) return next(new AppError('Task not found.', 404));

    const attachments = await Attachment.find({ taskId: req.params.taskId })
      .populate('uploadedBy', 'name email color role')
      .sort({ createdAt: -1 });

    res.status(200).json({ status: 'success', total: attachments.length, data: attachments });
  } catch (err) { next(err); }
};

// ── GET /api/tasks/:taskId/attachments/:attachmentId/download ──────
exports.downloadAttachment = async (req, res, next) => {
  try {
    const att = await Attachment.findOne({
      _id:    req.params.attachmentId,
      taskId: req.params.taskId,
    });
    if (!att) return next(new AppError('Attachment not found.', 404));

    const filePath = path.join(UPLOAD_DIR, att.storedName);
    if (!fs.existsSync(filePath)) return next(new AppError('File missing from server.', 404));

    res.download(filePath, att.filename);
  } catch (err) { next(err); }
};

// ── DELETE /api/tasks/:taskId/attachments/:attachmentId ───────────
exports.deleteAttachment = async (req, res, next) => {
  try {
    const att = await Attachment.findOne({
      _id:    req.params.attachmentId,
      taskId: req.params.taskId,
    });
    if (!att) return next(new AppError('Attachment not found.', 404));

    // Only the uploader or an admin may delete
    const isOwner = String(att.uploadedBy) === String(req.user._id);
    if (!isOwner && !req.user.isAdmin) {
      return next(new AppError('You do not have permission to delete this attachment.', 403));
    }

    // Remove file from disk
    const filePath = path.join(UPLOAD_DIR, att.storedName);
    if (fs.existsSync(filePath)) fs.unlink(filePath, () => {});

    await att.deleteOne();
    res.status(204).json({ status: 'success', data: null });
  } catch (err) { next(err); }
};
