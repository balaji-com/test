const Task = require('../models/Task');
const User = require('../models/User');
const { AppError } = require('../middleware/errorHandler');

// ── helper: parse numeric fields safely ───────────────────────────
const num = (v) => parseFloat(v) || 0;

// ════════════════════════════════════════════════════════════════════
// GET /api/analytics/team-overview
// Returns per-member task stats across ALL tasks (no month filter).
// Admins see all members; non-admins see only themselves.
// ════════════════════════════════════════════════════════════════════
exports.teamOverview = async (req, res, next) => {
  try {
    const { year, month } = req.query;

    const filter = {};
    if (!req.user.isAdmin) filter.assignedTo = req.user._id;
    if (year)  filter.year  = year;
    if (month) filter.month = month;

    const tasks = await Task.find(filter)
      .populate('assignedTo', 'name email color role')
      .lean();

    // Active members for the member list
    const activeUsers = await User.find({ isActive: true })
      .select('name email color role')
      .sort({ name: 1 })
      .lean();

    // Build per-member buckets using _id so we get the right data
    const buckets = {};
    for (const u of activeUsers) {
      buckets[String(u._id)] = {
        _id:    String(u._id),
        name:   u.name,
        email:  u.email,
        color:  u.color || '#c8890a',
        role:   u.role,
        tasks:  [],
      };
    }

    for (const t of tasks) {
      const uid = t.assignedTo?._id ? String(t.assignedTo._id) : String(t.assignedTo);
      if (buckets[uid]) buckets[uid].tasks.push(t);
    }

    const members = Object.values(buckets).map(b => {
      const mt      = b.tasks;
      const total   = mt.length;
      const done    = mt.filter(t => t.status === 'Completed').length;
      const inProg  = mt.filter(t => t.status === 'In Progress').length;
      const inRev   = mt.filter(t => t.status === 'In Review').length;
      const notSt   = mt.filter(t => t.status === 'Not Started').length;
      const rework  = mt.reduce((a, t) => a + (t.rework || 0), 0);
      const estHrs  = mt.reduce((a, t) => a + num(t.estHrs), 0);
      const actHrs  = mt.reduce((a, t) => a + num(t.actHrs), 0);
      const overdue = mt.filter(t =>
        t.dueDate && t.dueDate < new Date().toISOString().slice(0, 10) && t.status !== 'Completed'
      ).length;
      const pct = total ? Math.round((done / total) * 100) : 0;

      const today = new Date().toISOString().slice(0, 10);
      const byPriority = {
        High:   mt.filter(t => t.priority === 'High').length,
        Medium: mt.filter(t => t.priority === 'Medium').length,
        Low:    mt.filter(t => t.priority === 'Low').length,
      };

      return {
        _id: b._id, name: b.name, email: b.email, color: b.color, role: b.role,
        total, done, inProg, inRev, notSt, rework, overdue,
        estHrs: estHrs.toFixed(1), actHrs: actHrs.toFixed(1), pct,
        byPriority,
      };
    });

    // Sort: members with tasks first, then by name
    members.sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));

    // Team-wide totals
    const totals = members.reduce((acc, m) => ({
      total:   acc.total   + m.total,
      done:    acc.done    + m.done,
      inProg:  acc.inProg  + m.inProg,
      rework:  acc.rework  + m.rework,
      overdue: acc.overdue + m.overdue,
      estHrs:  parseFloat(acc.estHrs) + parseFloat(m.estHrs),
      actHrs:  parseFloat(acc.actHrs) + parseFloat(m.actHrs),
    }), { total: 0, done: 0, inProg: 0, rework: 0, overdue: 0, estHrs: 0, actHrs: 0 });

    totals.estHrs = totals.estHrs.toFixed(1);
    totals.actHrs = totals.actHrs.toFixed(1);
    totals.pct    = totals.total ? Math.round((totals.done / totals.total) * 100) : 0;

    res.status(200).json({ status: 'success', totals, data: members });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// GET /api/analytics/team-overview/tasks
// Paginated task details for interactive Team Overview drill-downs.
// Non-admins are scoped to their own tasks, as in teamOverview.
// ════════════════════════════════════════════════════════════════════
exports.teamOverviewTasks = async (req, res, next) => {
  try {
    const { year, month, status, priority, assignedTo, focus } = req.query;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 25));
    const filter = {};
    if (!req.user.isAdmin) filter.assignedTo = req.user._id;
    else if (assignedTo) filter.assignedTo = assignedTo;
    if (year) filter.year = year;
    if (month) filter.month = month;
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (focus === 'rework') filter.rework = { $gt: 0 };
    if (focus === 'overdue') {
      filter.dueDate = { $lt: new Date().toISOString().slice(0, 10) };
      filter.status = { $ne: 'Completed' };
    }

    const total = await Task.countDocuments(filter);
    const tasks = await Task.find(filter)
      .populate('assignedTo', 'name email color role')
      .sort({ dueDate: 1, createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean();

    res.status(200).json({
      status: 'success',
      total,
      page,
      limit,
      pages: Math.ceil(total / limit) || 1,
      data: tasks,
    });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// GET /api/analytics/monthly-report
// Query: month, year (both required for useful data)
// ════════════════════════════════════════════════════════════════════
exports.monthlyReport = async (req, res, next) => {
  try {
    const { month, year } = req.query;

    const filter = {};
    if (!req.user.isAdmin) filter.assignedTo = req.user._id;
    if (month) filter.month = month;
    if (year)  filter.year  = year;

    const tasks = await Task.find(filter)
      .populate('assignedTo', 'name email color role')
      .sort({ task: 1 })
      .lean();

    // Per-member breakdown
    const memberMap = {};
    for (const t of tasks) {
      const assignee = t.assignedTo;
      const uid  = assignee?._id ? String(assignee._id) : 'unassigned';
      const name = assignee?.name || t.assignedToName || 'Unassigned';
      const color = assignee?.color || '#c8890a';
      if (!memberMap[uid]) memberMap[uid] = { uid, name, color, tasks: [] };
      memberMap[uid].tasks.push(t);
    }

    const byMember = Object.values(memberMap).map(m => {
      const mt = m.tasks;
      return {
        uid: m.uid, name: m.name, color: m.color,
        total:  mt.length,
        done:   mt.filter(t => t.status === 'Completed').length,
        inProg: mt.filter(t => t.status === 'In Progress').length,
        rework: mt.reduce((a, t) => a + (t.rework || 0), 0),
      };
    }).sort((a, b) => b.total - a.total);

    // Category breakdown
    const catMap = {};
    for (const t of tasks) {
      const cat = t.cat || 'Uncategorised';
      if (!catMap[cat]) catMap[cat] = { cat, total: 0, done: 0 };
      catMap[cat].total++;
      if (t.status === 'Completed') catMap[cat].done++;
    }
    const byCategory = Object.values(catMap).sort((a, b) => b.total - a.total);

    const summary = {
      total:   tasks.length,
      done:    tasks.filter(t => t.status === 'Completed').length,
      inProg:  tasks.filter(t => t.status === 'In Progress').length,
      inRev:   tasks.filter(t => t.status === 'In Review').length,
      notSt:   tasks.filter(t => t.status === 'Not Started').length,
      rework:  tasks.reduce((a, t) => a + (t.rework || 0), 0),
      highPri: tasks.filter(t => t.priority === 'High').length,
      overdue: tasks.filter(t =>
        t.dueDate && t.dueDate < new Date().toISOString().slice(0, 10) && t.status !== 'Completed'
      ).length,
    };

    res.status(200).json({
      status: 'success', month, year, summary, byMember, byCategory,
      tasks: tasks.map(t => ({
        _id: t._id, task: t.task,
        assignedToId: t.assignedTo?._id ? String(t.assignedTo._id) : 'unassigned',
        assignedTo: t.assignedTo?.name || t.assignedToName || '—',
        status: t.status, priority: t.priority, cat: t.cat || '',
        rework: t.rework || 0, dueDate: t.dueDate || '', brief: t.brief || '',
      })),
    });
  } catch (err) { next(err); }
};
