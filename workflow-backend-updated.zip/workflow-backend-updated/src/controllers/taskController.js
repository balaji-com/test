const Task     = require('../models/Task');
const AuditLog = require('../models/AuditLog');
const { AppError } = require('../middleware/errorHandler');
const { Parser: CsvParser } = require('json2csv');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');

// ── Audit helper ───────────────────────────────────────────────────
const audit = async (action, user, task, extra = '', changes = null) => {
  await AuditLog.create({
    action,
    user:       user._id,
    userName:   user.name,
    taskId:     task?._id,
    taskName:   task?.task || '',
    assignedTo: task?.assignedToName || '',
    extra,
    changes,
  });
};

// ── Shared date helpers ────────────────────────────────────────────
const todayStr    = () => new Date().toISOString().slice(0, 10);
const tomorrowStr = () => {
  const d = new Date(); d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
};

// ── Shared filter builder for All Works (team-wide) ────────────────
const buildAllWorksFilter = (query) => {
  const { status, priority, assignedTo, month, year, search } = query;
  const filter = {};

  if (status)     filter.status     = status;
  if (priority)   filter.priority   = priority;
  if (assignedTo) filter.assignedTo = assignedTo;
  if (month)      filter.month      = month;
  if (year)       filter.year       = year;

  if (search) {
    const rx = { $regex: search, $options: 'i' };
    filter.$or = [
      { task: rx },
      { cat:  rx },
      { sub:  rx },
      { assignedToName: rx },
    ];
  }

  return filter;
};

// ── Export row flattener ───────────────────────────────────────────
const toExportRow = (t) => ({
  taskName:         t.task,
  assignedTo:       t.assignedTo?.name || t.assignedToName || '—',
  function:         t.fn  || '',
  category:         t.cat || '',
  subCategory:      t.sub || '',
  priority:         t.priority,
  status:           t.status,
  month:            t.month || '',
  year:             t.year  || '',
  startDate:        t.startDate || '',
  dueDate:          t.dueDate   || '',
  estHrs:           t.estHrs    || '',
  actHrs:           t.actHrs    || '',
  rework:           t.rework ?? 0,
  brief:            t.brief || '',
  internalCustomer: t.internalCustomer || '',
  approvalStatus:   t.approvalStatus   || '',
  notes:            t.notes || '',
});

const EXPORT_COLUMNS = [
  { key: 'taskName',         label: 'Task Name'         },
  { key: 'assignedTo',       label: 'Assigned To'       },
  { key: 'function',         label: 'Function'          },
  { key: 'category',         label: 'Category'          },
  { key: 'subCategory',      label: 'Sub-Category'      },
  { key: 'priority',         label: 'Priority'          },
  { key: 'status',           label: 'Status'            },
  { key: 'month',            label: 'Month'             },
  { key: 'year',             label: 'Year'              },
  { key: 'startDate',        label: 'Start Date'        },
  { key: 'dueDate',          label: 'Due Date'          },
  { key: 'estHrs',           label: 'Est. Hours'        },
  { key: 'actHrs',           label: 'Actual Hours'      },
  { key: 'rework',           label: 'Rework'            },
  { key: 'brief',            label: 'Briefing Sheet'    },
  { key: 'internalCustomer', label: 'Internal Customer' },
  { key: 'approvalStatus',   label: 'Approval Status'   },
  { key: 'notes',            label: 'Notes'             },
];

// ════════════════════════════════════════════════════════════════════
// GET /api/tasks
// Supports: search, status, priority, assignedTo, month, year,
//           reminderType, page, limit
// Non-admins are scoped to their own tasks automatically.
// ════════════════════════════════════════════════════════════════════
exports.getTasks = async (req, res, next) => {
  try {
    const {
      status, priority, assignedTo,
      month, year, search,
      reminderType,
      page = 1, limit = 10,
    } = req.query;

    const today    = todayStr();
    const tomorrow = tomorrowStr();

    const filter = {};

    // ── Row-level scoping ──────────────────────────────────────────
    // Non-admins always see only their own tasks.
    // Admins can optionally filter by a specific assignee.
    if (!req.user.isAdmin) {
      filter.assignedTo = req.user._id;
    } else if (assignedTo) {
      filter.assignedTo = assignedTo;
    }

    // ── Standard field filters ─────────────────────────────────────
    if (status)   filter.status   = status;
    if (priority) filter.priority = priority;
    if (month)    filter.month    = month;
    if (year)     filter.year     = year;

    // Search across task name, category, sub-category
    if (search) {
      const rx = { $regex: search, $options: 'i' };
      filter.$or = [{ task: rx }, { cat: rx }, { sub: rx }];
    }

    // ── Reminder-type filters ──────────────────────────────────────
    // These narrow results to the specific date-urgency bucket the
    // Reminders page tabs want, without conflicting with other filters.
    if (reminderType === 'overdue') {
      filter.dueDate = { $lt: today };
      filter.status  = { $ne: 'Completed' };
    } else if (reminderType === 'today') {
      filter.dueDate = today;
      filter.status  = { $ne: 'Completed' };
    } else if (reminderType === 'tomorrow') {
      filter.dueDate = tomorrow;
      filter.status  = { $ne: 'Completed' };
    } else if (reminderType === 'approval') {
      filter.approvalStatus = 'Pending';
    } else if (reminderType === 'all') {
      // Any task due by tomorrow OR pending approval, excluding completed
      filter.$or = [
        { dueDate: { $lte: tomorrow }, status: { $ne: 'Completed' } },
        { approvalStatus: 'Pending' },
      ];
    }

    // ── Pagination ─────────────────────────────────────────────────
    const pageNum  = Math.max(1, parseInt(page));
    const limitNum = Math.min(1000, Math.max(1, parseInt(limit)));
    const skip     = (pageNum - 1) * limitNum;

    const total = await Task.countDocuments(filter);
    const tasks = await Task.find(filter)
      .populate('assignedTo', 'name email color role')
      .sort({ dueDate: 1, createdAt: -1 })
      .skip(skip)
      .limit(limitNum);

    res.status(200).json({
      status: 'success',
      total,
      page:  pageNum,
      limit: limitNum,
      pages: Math.ceil(total / limitNum) || 1,
      data:  tasks,
    });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// GET /api/tasks/task-names
// Returns sorted distinct task names from DB.
// Non-admins see only names from their own tasks.
// Used by the Add/Edit modal "Task Name" combo field.
// ════════════════════════════════════════════════════════════════════
exports.getTaskNames = async (req, res, next) => {
  try {
    // All logged-in users see the full shared task name pool.
    // This lets anyone pick an existing task name when creating a task,
    // regardless of who originally created it.
    const names = await Task.distinct('task', {});
    names.sort((a, b) => a.localeCompare(b));
    res.status(200).json({ status: 'success', total: names.length, data: names });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// GET /api/tasks/:id
// ════════════════════════════════════════════════════════════════════
exports.getTask = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id)
      .populate('assignedTo', 'name email color role');
    if (!task) return next(new AppError('Task not found.', 404));
    res.status(200).json({ status: 'success', data: task });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// POST /api/tasks
// ════════════════════════════════════════════════════════════════════
exports.createTask = async (req, res, next) => {
  try {
    const task = await Task.create({ ...req.body, createdBy: req.user._id });
    await task.populate('assignedTo', 'name email color role');

    if (task.assignedTo?.name) {
      task.assignedToName = task.assignedTo.name;
      await task.save();
    }

    await audit('created', req.user, task);
    res.status(201).json({ status: 'success', data: task });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// PATCH /api/tasks/:id
// Used by: My Tasks edit, All Works edit, Calendar popup,
//          Kanban drag-and-drop (status only), Reminders popup.
// ════════════════════════════════════════════════════════════════════
exports.updateTask = async (req, res, next) => {
  try {
    const old = await Task.findById(req.params.id);
    if (!old) return next(new AppError('Task not found.', 404));

    // Track field-level changes for the audit log
    const changes = {};
    const watched = ['status','priority','assignedTo','dueDate','estHrs','actHrs','rework'];
    watched.forEach(key => {
      if (req.body[key] !== undefined && String(req.body[key]) !== String(old[key])) {
        changes[key] = [String(old[key]), String(req.body[key])];
      }
    });

    const task = await Task.findByIdAndUpdate(req.params.id, req.body, {
      new: true, runValidators: true,
    }).populate('assignedTo', 'name email color role');

    // Keep denormalised name in sync when the assignee changes
    if (changes.assignedTo && task.assignedTo?.name) {
      task.assignedToName = task.assignedTo.name;
      await task.save();
    }

    const action = changes.status ? 'status-changed' : 'edited';
    await audit(action, req.user, task, '', Object.keys(changes).length ? changes : null);

    res.status(200).json({ status: 'success', data: task });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// DELETE /api/tasks/:id
// ════════════════════════════════════════════════════════════════════
exports.deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return next(new AppError('Task not found.', 404));
    await audit('deleted', req.user, task);
    res.status(204).json({ status: 'success', data: null });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// PATCH /api/tasks/bulk
// ════════════════════════════════════════════════════════════════════
exports.bulkAction = async (req, res, next) => {
  try {
    const { ids, action } = req.body;
    if (!ids?.length || !action) return next(new AppError('ids and action are required.', 400));

    if (action === 'complete') {
      await Task.updateMany({ _id: { $in: ids } }, { status: 'Completed' });
      await AuditLog.create({
        action: 'bulk-completed', user: req.user._id, userName: req.user.name,
        taskName: `${ids.length} tasks`, extra: `IDs: ${ids.join(', ')}`,
      });
    } else if (action === 'delete') {
      await Task.deleteMany({ _id: { $in: ids } });
      await AuditLog.create({
        action: 'bulk-deleted', user: req.user._id, userName: req.user.name,
        taskName: `${ids.length} tasks`, extra: `IDs: ${ids.join(', ')}`,
      });
    } else {
      return next(new AppError(`Unknown bulk action: ${action}`, 400));
    }

    res.status(200).json({
      status: 'success',
      message: `Bulk ${action} completed for ${ids.length} tasks.`,
    });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// GET /api/tasks/all-works
// Supports: search, status, priority, assignedTo, month, year,
//           page, limit, groupBy (taskName | none)
//
// groupBy=taskName (default): paginates at the GROUP level —
//   returns N distinct task-name buckets per page, each with their items.
// groupBy=none: flat paginated list.
// ════════════════════════════════════════════════════════════════════
exports.getAllWorks = async (req, res, next) => {
  try {
    const { groupBy = 'taskName', page = 1, limit = 10 } = req.query;
    const filter   = buildAllWorksFilter(req.query);
    const pageNum  = Math.max(1, parseInt(page));
    const limitNum = Math.min(200, Math.max(1, parseInt(limit)));

    // ── Flat (ungrouped) mode ──────────────────────────────────────
    if (groupBy === 'none') {
      const total = await Task.countDocuments(filter);
      const tasks = await Task.find(filter)
        .populate('assignedTo', 'name email color role')
        .sort({ createdAt: -1 })
        .skip((pageNum - 1) * limitNum)
        .limit(limitNum);

      return res.status(200).json({
        status: 'success',
        total,
        page:  pageNum,
        limit: limitNum,
        pages: Math.ceil(total / limitNum) || 1,
        data:  tasks,
      });
    }

    // ── Grouped mode: paginate at the GROUP (task-name) level ──────
    // Step 1: get all distinct task names that match the filter, sorted A→Z
    const allTaskNames = await Task.distinct('task', filter);
    allTaskNames.sort((a, b) => a.localeCompare(b));

    const totalGroups = allTaskNames.length;
    const totalPages  = Math.ceil(totalGroups / limitNum) || 1;

    // Slice the page's task-name keys
    const pageNames = allTaskNames.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    if (pageNames.length === 0) {
      return res.status(200).json({
        status: 'success',
        total:       0,
        totalGroups: 0,
        page:        pageNum,
        limit:       limitNum,
        pages:       totalPages,
        groupCount:  0,
        data:        [],
      });
    }

    // Step 2: fetch all items belonging to this page's task names
    const tasks = await Task.find({ ...filter, task: { $in: pageNames } })
      .populate('assignedTo', 'name email color role')
      .sort({ task: 1, createdAt: -1 });

    // Step 3: bucket them preserving the sorted order
    const buckets = {};
    for (const name of pageNames) buckets[name] = [];
    for (const t of tasks) {
      if (buckets[t.task] !== undefined) buckets[t.task].push(t);
    }

    const groupedData = pageNames.map(taskName => ({
      taskName,
      count:     buckets[taskName].length,
      months:    [...new Set(buckets[taskName].map(i => i.month).filter(Boolean))],
      assignees: [...new Set(buckets[taskName].map(i => i.assignedTo?.name || i.assignedToName).filter(Boolean))],
      items:     buckets[taskName],
    }));

    // Total records across all pages (for the summary line in the UI)
    const totalRecords = await Task.countDocuments(filter);

    res.status(200).json({
      status:      'success',
      total:       totalRecords,
      totalGroups,
      page:        pageNum,
      limit:       limitNum,
      pages:       totalPages,
      groupCount:  groupedData.length,
      data:        groupedData,
    });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// GET /api/tasks/all-works/members
// Distinct assignee list for the filter dropdown
// ════════════════════════════════════════════════════════════════════
exports.getAllWorksMembers = async (req, res, next) => {
  try {
    const tasks = await Task.find({}).populate('assignedTo', 'name _id');
    const seen  = new Map();
    tasks.forEach(t => {
      if (t.assignedTo?._id) seen.set(String(t.assignedTo._id), t.assignedTo.name);
    });
    const members = [...seen.entries()]
      .map(([_id, name]) => ({ _id, name }))
      .sort((a, b) => a.name.localeCompare(b.name));
    res.status(200).json({ status: 'success', data: members });
  } catch (err) { next(err); }
};

// ════════════════════════════════════════════════════════════════════
// EXPORTS — CSV / Excel / PDF  (honour the same filters as the list)
// ════════════════════════════════════════════════════════════════════

exports.exportCSV = async (req, res, next) => {
  try {
    const filter = buildAllWorksFilter(req.query);
    const tasks  = await Task.find(filter).populate('assignedTo', 'name').sort({ task: 1 });
    const rows   = tasks.map(toExportRow);

    const parser = new CsvParser({
      fields: EXPORT_COLUMNS.map(c => ({ label: c.label, value: c.key })),
    });
    const csv = parser.parse(rows);

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="all-works-${Date.now()}.csv"`);
    res.status(200).send(csv);
  } catch (err) { next(err); }
};

exports.exportExcel = async (req, res, next) => {
  try {
    const filter = buildAllWorksFilter(req.query);
    const tasks  = await Task.find(filter).populate('assignedTo', 'name').sort({ task: 1 });
    const rows   = tasks.map(toExportRow);

    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Hinduja Tech Workflow';
    const sheet = workbook.addWorksheet('All Works');

    sheet.columns = EXPORT_COLUMNS.map(c => ({ header: c.label, key: c.key, width: 20 }));
    sheet.getRow(1).font = { bold: true };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEAECF2' } };
    rows.forEach(r => sheet.addRow(r));
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
    sheet.autoFilter = {
      from: { row: 1, column: 1 },
      to:   { row: 1, column: EXPORT_COLUMNS.length },
    };

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="all-works-${Date.now()}.xlsx"`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) { next(err); }
};

exports.exportPDF = async (req, res, next) => {
  try {
    const filter = buildAllWorksFilter(req.query);
    const tasks  = await Task.find(filter).populate('assignedTo', 'name').sort({ task: 1 });
    const rows   = tasks.map(toExportRow);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="all-works-${Date.now()}.pdf"`);

    const doc = new PDFDocument({ margin: 30, size: 'A4', layout: 'landscape' });
    doc.pipe(res);

    doc.fontSize(16).font('Helvetica-Bold').text('All Team Work — Export', { align: 'left' });
    doc.fontSize(9).font('Helvetica').fillColor('#666')
      .text(`Generated ${new Date().toLocaleString()} · ${rows.length} task${rows.length === 1 ? '' : 's'}`);
    doc.moveDown(1).fillColor('#000');

    const cols = [
      { key: 'taskName',   label: 'Task',        width: 160 },
      { key: 'assignedTo', label: 'Assigned To',  width: 90  },
      { key: 'category',   label: 'Category',     width: 80  },
      { key: 'priority',   label: 'Priority',     width: 55  },
      { key: 'status',     label: 'Status',       width: 75  },
      { key: 'dueDate',    label: 'Due Date',     width: 70  },
      { key: 'estHrs',     label: 'Est Hrs',      width: 50  },
      { key: 'actHrs',     label: 'Act Hrs',      width: 50  },
      { key: 'rework',     label: 'Rework',       width: 45  },
    ];

    const totalWidth = cols.reduce((a, c) => a + c.width, 0);
    const startX     = doc.page.margins.left;
    let y            = doc.y;
    const rowH       = 18;

    const drawHeader = () => {
      let x = startX;
      doc.rect(startX, y, totalWidth, rowH).fill('#c8890a');
      doc.font('Helvetica-Bold').fontSize(8.5).fillColor('#fff');
      cols.forEach(c => {
        doc.text(c.label, x + 4, y + 5, { width: c.width - 6 });
        x += c.width;
      });
      y += rowH;
      doc.fillColor('#000');
    };

    drawHeader();
    doc.font('Helvetica').fontSize(8);

    rows.forEach((r, i) => {
      if (y > doc.page.height - doc.page.margins.bottom - rowH) {
        doc.addPage({ margin: 30, size: 'A4', layout: 'landscape' });
        y = doc.page.margins.top;
        drawHeader();
        doc.font('Helvetica').fontSize(8);
      }
      if (i % 2 === 0) {
        doc.rect(startX, y, totalWidth, rowH).fill('#f4f5f7');
        doc.fillColor('#000');
      }
      let x = startX;
      cols.forEach(c => {
        const val = String(r[c.key] ?? '');
        doc.text(val.length > 30 ? val.slice(0, 28) + '…' : val, x + 4, y + 5, { width: c.width - 6 });
        x += c.width;
      });
      y += rowH;
    });

    doc.end();
  } catch (err) { next(err); }
};
