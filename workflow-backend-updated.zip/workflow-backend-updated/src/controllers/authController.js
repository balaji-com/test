const { validationResult } = require('express-validator');
const User                  = require('../models/User');
const { AppError }          = require('../middleware/errorHandler');
const { signAccessToken, signRefreshToken, verifyRefreshToken, cookieOptions } = require('../utils/jwt');
const logger                = require('../utils/logger');

// ── Helper: send token response ────────────────────────────────────
const sendTokens = async (user, statusCode, res) => {
  const accessToken  = signAccessToken(user._id);
  const refreshToken = signRefreshToken(user._id);

  // Save hashed refresh token to DB
  user.refreshToken = refreshToken;
  user.lastLogin    = new Date();
  await user.save({ validateBeforeSave: false });

  // Set refresh token as httpOnly cookie
  res.cookie('refreshToken', refreshToken, cookieOptions(30));

  // Convert permissions Map -> plain object for JSON
  const permissions = user.permissions instanceof Map
    ? Object.fromEntries(user.permissions)
    : (user.permissions || {});

  res.status(statusCode).json({
    status: 'success',
    accessToken,
    user: {
      _id:         user._id,
      name:        user.name,
      email:       user.email,
      role:        user.role,
      isAdmin:     user.isAdmin,
      color:       user.color,
      permissions, // ← module-level access map, e.g. { kanban: 'editor', backup: 'no_access', ... }
    },
  });
};

// ── POST /api/auth/register ────────────────────────────────────────
exports.register = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return next(new AppError(errors.array()[0].msg, 400));
    }

    const { name, email, password, role } = req.body;

    const existing = await User.findOne({ email });
    if (existing) return next(new AppError('Email already in use.', 409));

    const user = await User.create({
      name,
      email,
      password,
      role:    role || 'member',
      isAdmin: role === 'admin',
    });

    logger.info(`New user registered: ${user.email}`);
    await sendTokens(user, 201, res);
  } catch (err) {
    next(err);
  }
};

// ── POST /api/auth/login ───────────────────────────────────────────
exports.login = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return next(new AppError(errors.array()[0].msg, 400));
    }

    const { email, password } = req.body;

    // Select password explicitly (it's excluded by default)
    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.comparePassword(password))) {
      return next(new AppError('Incorrect email or password.', 401));
    }

    if (!user.isActive) {
      return next(new AppError('Account deactivated. Contact admin.', 403));
    }

    logger.info(`User logged in: ${user.email}`);
    await sendTokens(user, 200, res);
  } catch (err) {
    next(err);
  }
};

// ── POST /api/auth/refresh ─────────────────────────────────────────
exports.refresh = async (req, res, next) => {
  try {
    const token = req.cookies?.refreshToken || req.body?.refreshToken;
    if (!token) return next(new AppError('Refresh token missing.', 401));

    // verifyRefreshToken now returns null on expiry/invalid instead of throwing
    const decoded = verifyRefreshToken(token);
    if (!decoded) return next(new AppError('Refresh token expired or invalid. Please log in again.', 401));

    const user = await User.findById(decoded.id).select('+refreshToken');
    if (!user || user.refreshToken !== token) {
      return next(new AppError('Refresh token has been revoked. Please log in again.', 401));
    }

    if (!user.isActive) {
      return next(new AppError('Account is deactivated.', 403));
    }

    // Token rotation — issue new access AND refresh token, invalidate old refresh token
    const newAccessToken  = signAccessToken(user._id);
    const newRefreshToken = signRefreshToken(user._id);

    user.refreshToken = newRefreshToken;
    await user.save({ validateBeforeSave: false });

    res.cookie('refreshToken', newRefreshToken, cookieOptions(30));
    res.status(200).json({ status: 'success', accessToken: newAccessToken });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/auth/logout ──────────────────────────────────────────
exports.logout = async (req, res, next) => {
  try {
    if (req.user) {
      req.user.refreshToken = undefined;
      await req.user.save({ validateBeforeSave: false });
    }
    res.clearCookie('refreshToken');
    res.status(200).json({ status: 'success', message: 'Logged out.' });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/auth/me ───────────────────────────────────────────────
exports.getMe = (req, res) => {
  res.status(200).json({ status: 'success', user: req.user });
};

// ── PATCH /api/auth/change-password ───────────────────────────────
exports.changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return next(new AppError('Both currentPassword and newPassword are required.', 400));
    }
    if (newPassword.length < 4) {
      return next(new AppError('Password must be at least 4 characters.', 400));
    }

    const user = await User.findById(req.user._id).select('+password');
    if (!(await user.comparePassword(currentPassword))) {
      return next(new AppError('Current password is incorrect.', 401));
    }

    user.password = newPassword;
    await user.save();

    logger.info(`Password changed for user: ${user.email}`);
    await sendTokens(user, 200, res);
  } catch (err) {
    next(err);
  }
};
