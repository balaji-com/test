const User = require('../models/User');
const { MODULE_KEYS, ACCESS_LEVELS, memberDefaultPermissions } = require('../models/User');
const { AppError } = require('../middleware/errorHandler');

// ── GET /api/users/active ──────────────────────────────────────────
// Open to ALL logged-in users (no permission check).
// Returns only the fields needed for dropdowns — no passwords, no permissions.
exports.getActiveUsers = async (req, res, next) => {
  try {
    const users = await User.find({ isActive: true })
      .select('name email color role isActive')
      .sort({ name: 1 });
    res.status(200).json({ status: 'success', total: users.length, data: users });
  } catch (err) { next(err); }
};

// ── GET /api/users ─────────────────────────────────────────────────
exports.getUsers = async (req, res, next) => {
  try {
    const users = await User.find({ isActive: true }).select('-__v').sort({ name: 1 });
    res.status(200).json({ status: 'success', total: users.length, data: users });
  } catch (err) { next(err); }
};

// ── GET /api/users/:id ─────────────────────────────────────────────
exports.getUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return next(new AppError('User not found.', 404));
    res.status(200).json({ status: 'success', data: user });
  } catch (err) { next(err); }
};

// ── POST /api/users ────────────────────────────────────────────────
exports.createUser = async (req, res, next) => {
  try {
    const { name, email, password, role, color, permissions } = req.body;
    if (!name || !email || !password) {
      return next(new AppError('name, email and password are required.', 400));
    }

    // Build permissions: admin gets full access, others use provided or defaults
    let resolvedPermissions;
    if (role === 'admin') {
      resolvedPermissions = {};
      MODULE_KEYS.forEach(k => { resolvedPermissions[k] = 'admin'; });
    } else {
      resolvedPermissions = permissions || memberDefaultPermissions();
    }

    const user = await User.create({
      name, email, password, color,
      role:        role || 'member',
      isAdmin:     role === 'admin',
      permissions: resolvedPermissions,
    });

    res.status(201).json({ status: 'success', data: user });
  } catch (err) { next(err); }
};

// ── PATCH /api/users/:id ───────────────────────────────────────────
exports.updateUser = async (req, res, next) => {
  try {
    const { password, refreshToken, permissions, role, ...rest } = req.body;

    // Safety: an admin cannot demote their own account (avoids self-lockout)
    if (role && role !== 'admin' && String(req.user._id) === String(req.params.id) && req.user.isAdmin) {
      return next(new AppError('You cannot remove your own admin role.', 400));
    }

    const updateData = { ...rest };
    if (role) {
      updateData.role    = role;
      updateData.isAdmin = role === 'admin';
    }

    // Update permissions map if provided
    if (permissions && typeof permissions === 'object') {
      // Validate every key/value
      for (const [k, v] of Object.entries(permissions)) {
        if (!MODULE_KEYS.includes(k))     return next(new AppError(`Unknown module: ${k}`, 400));
        if (!ACCESS_LEVELS.includes(v))   return next(new AppError(`Invalid access level for ${k}: ${v}`, 400));
      }
      updateData.permissions = permissions;
    }

    // If role changed to admin, grant full access
    if (role === 'admin') {
      const fullAccess = {};
      MODULE_KEYS.forEach(k => { fullAccess[k] = 'admin'; });
      updateData.permissions = fullAccess;
    }

    const user = await User.findByIdAndUpdate(req.params.id, updateData, {
      new: true, runValidators: true,
    });
    if (!user) return next(new AppError('User not found.', 404));
    res.status(200).json({ status: 'success', data: user });
  } catch (err) { next(err); }
};

// ── PATCH /api/users/:id/permissions ──────────────────────────────
// Dedicated endpoint for saving just the permission grid
exports.updatePermissions = async (req, res, next) => {
  try {
    const { permissions } = req.body;
    if (!permissions || typeof permissions !== 'object') {
      return next(new AppError('permissions object is required.', 400));
    }

    // Validate
    for (const [k, v] of Object.entries(permissions)) {
      if (!MODULE_KEYS.includes(k))   return next(new AppError(`Unknown module: ${k}`, 400));
      if (!ACCESS_LEVELS.includes(v)) return next(new AppError(`Invalid level for ${k}: ${v}`, 400));
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { permissions },
      { new: true, runValidators: true }
    );
    if (!user) return next(new AppError('User not found.', 404));
    res.status(200).json({ status: 'success', data: user, message: 'Permissions saved.' });
  } catch (err) { next(err); }
};

// ── DELETE /api/users/:id (soft delete) ───────────────────────────
exports.deleteUser = async (req, res, next) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive: false },
      { new: true }
    );
    if (!user) return next(new AppError('User not found.', 404));
    res.status(200).json({ status: 'success', message: 'User deactivated.' });
  } catch (err) { next(err); }
};

// ── PATCH /api/users/me ────────────────────────────────────────────
exports.updateMe = async (req, res, next) => {
  try {
    const { password, role, isAdmin, permissions, ...updateData } = req.body;
    const user = await User.findByIdAndUpdate(req.user._id, updateData, {
      new: true, runValidators: true,
    });
    res.status(200).json({ status: 'success', data: user });
  } catch (err) { next(err); }
};

// ── GET /api/users/modules — list all modules ──────────────────────
exports.getModules = (_req, res) => {
  const MODULE_LABELS = {
    my_tasks:         'My Tasks',
    all_works:        'All Works',
    reminders:        'Reminders',
    kanban:           'Workflow Board',
    approvals:        'Approvals',
    calendar:         'My Tasks Calendar',
    planner:          'Planning Calendar',
    team_overview:    'Team Overview',
    monthly_reports:  'Monthly Reports',
    seo_checker:      'SEO Blog Checker',
    topic_selector:   'Blog Topic Selector',
    ai_configuration: 'AI Configuration',
    customize_fields: 'Customize Fields',
    add_members:      'Add Members',
    audit_log:        'Audit Log',
    backup:           'Backup & Restore',
    change_password:  'Change Password',
  };
  const MODULE_GROUPS = {
    Workspace:   ['my_tasks','all_works','reminders','kanban','approvals'],
    Calendar:    ['calendar','planner'],
    Analytics:   ['team_overview','monthly_reports'],
    'SEO Tools': ['seo_checker','topic_selector'],
    Settings:    ['ai_configuration','customize_fields','add_members','audit_log','backup','change_password'],
  };
  res.status(200).json({
    status: 'success',
    data: { MODULE_KEYS, ACCESS_LEVELS, MODULE_LABELS, MODULE_GROUPS },
  });
};
