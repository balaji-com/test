const { randomUUID } = require('crypto');
const ExcelJS = require('exceljs');
const PlanningEntry = require('../models/PlanningEntry');
const { AppError } = require('../middleware/errorHandler');

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const MAX_ROWS = 5000;
const MAX_COLUMNS = 20;

const EXPECTED_HEADERS = [
  [1, 'week'],
  [2, 'date of publication'],
  [4, 'offerings'],
  [5, 'segments / industries'],
  [6, 'format'],
  [7, 'content objectives'],
  [8, 'content pillars'],
  [9, 'target audience'],
  [10, 'channel'],
  [11, 'kpi'],
  [12, 'assigned to'],
  [13, 'due date for submission'],
  [14, 'actual date of submission'],
  [15, 'reviewer'],
  [16, 'due date for reviewing'],
  [17, 'actual date of reviewing'],
  [18, 'depository link'],
  [19, 'posted link'],
  [20, 'status'],
];

const textAt = (row, column) => String(row.getCell(column).text || '').trim();

const dateAt = (cell) => {
  const value = cell.value;
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }

  const text = String(cell.text || value || '').trim();
  const iso = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(text);
  const slash = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text);
  const parts = iso
    ? [Number(iso[1]), Number(iso[2]), Number(iso[3])]
    : slash
      ? [Number(slash[3]), Number(slash[1]), Number(slash[2])]
      : null;
  if (!parts) return '';

  const [year, month, day] = parts;
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    return '';
  }
  return date.toISOString().slice(0, 10);
};

const readEntry = (row, createdBy, importBatchId, sourceFileName) => ({
  week: Number(textAt(row, 1)) || undefined,
  publicationDate: dateAt(row.getCell(2)),
  contentTitle: textAt(row, 3),
  offerings: textAt(row, 4),
  segmentsIndustries: textAt(row, 5),
  format: textAt(row, 6),
  contentObjectives: textAt(row, 7),
  contentPillars: textAt(row, 8),
  targetAudience: textAt(row, 9),
  channel: textAt(row, 10),
  kpi: textAt(row, 11),
  assignedTo: textAt(row, 12),
  submissionDueDate: dateAt(row.getCell(13)),
  submissionActualDate: dateAt(row.getCell(14)),
  reviewer: textAt(row, 15),
  reviewDueDate: dateAt(row.getCell(16)),
  reviewActualDate: dateAt(row.getCell(17)),
  depositoryLink: textAt(row, 18),
  postedLink: textAt(row, 19),
  status: textAt(row, 20),
  createdBy,
  importBatchId,
  sourceFileName,
});

const hasRowData = (row) =>
  Array.from({ length: MAX_COLUMNS }, (_value, index) => row.getCell(index + 1))
    .some((cell) => cell.value !== null && cell.value !== undefined && cell.text.trim() !== '');

exports.listPlanningEntries = async (req, res, next) => {
  try {
    const { year, month } = req.query;
    const filter = {};
    if (!req.user.isAdmin) filter.createdBy = req.user._id;

    if (year !== undefined || month !== undefined) {
      const yearNumber = Number(year);
      const monthNumber = Number(month);
      if (!Number.isInteger(yearNumber) || yearNumber < 2000 || yearNumber > 2100
        || !Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12) {
        return next(new AppError('Provide a valid month (1-12) and year (2000-2100).', 400));
      }

      const lastDay = new Date(Date.UTC(yearNumber, monthNumber, 0)).getUTCDate();
      const monthText = String(monthNumber).padStart(2, '0');
      filter.publicationDate = {
        $gte: `${yearNumber}-${monthText}-01`,
        $lte: `${yearNumber}-${monthText}-${String(lastDay).padStart(2, '0')}`,
      };
    }

    const entries = await PlanningEntry.find(filter)
      .sort({ publicationDate: 1, contentTitle: 1 })
      .limit(5000);

    res.status(200).json({ status: 'success', total: entries.length, data: entries });
  } catch (err) { next(err); }
};

exports.importPlanningWorkbook = async (req, res, next) => {
  try {
    if (!req.file) return next(new AppError('Choose an .xlsx workbook to import.', 400));
    if (req.file.size > MAX_FILE_SIZE) {
      return next(new AppError('The workbook must be 10 MB or smaller.', 413));
    }

    const workbook = new ExcelJS.Workbook();
    try {
      await workbook.xlsx.load(req.file.buffer);
    } catch (_err) {
      return next(new AppError('The uploaded file is not a readable .xlsx workbook.', 400));
    }

    const sheet = workbook.worksheets[0];
    if (!sheet) return next(new AppError('The workbook does not contain a worksheet.', 400));
    if (sheet.rowCount > MAX_ROWS + 1 || sheet.columnCount > MAX_COLUMNS) {
      return next(new AppError(`The worksheet must contain no more than ${MAX_ROWS} data rows and ${MAX_COLUMNS} columns.`, 400));
    }

    const mismatchedHeader = EXPECTED_HEADERS.find(([column, expected]) =>
      textAt(sheet.getRow(1), column).toLowerCase() !== expected
    );
    if (mismatchedHeader) {
      return next(new AppError(
        `Unsupported workbook format: column ${mismatchedHeader[0]} must be "${mismatchedHeader[1]}".`,
        400
      ));
    }

    const importBatchId = randomUUID();
    const sourceFileName = req.file.originalname.slice(0, 255);
    const entries = [];
    const invalidRows = [];

    for (let rowNumber = 2; rowNumber <= sheet.rowCount; rowNumber++) {
      const row = sheet.getRow(rowNumber);
      if (!hasRowData(row)) continue;

      const entry = readEntry(row, req.user._id, importBatchId, sourceFileName);
      if (!entry.publicationDate || !entry.contentTitle) {
        invalidRows.push(rowNumber);
        continue;
      }
      entries.push(entry);
    }

    if (invalidRows.length) {
      return next(new AppError(
        `Each non-empty row needs a valid publication date and content title. Check row${invalidRows.length === 1 ? '' : 's'} ${invalidRows.join(', ')}.`,
        400
      ));
    }
    if (!entries.length) return next(new AppError('No dated content rows were found in the workbook.', 400));

    const createdEntries = await PlanningEntry.insertMany(entries, { ordered: true });
    res.status(201).json({
      status: 'success',
      importedCount: createdEntries.length,
      importBatchId,
      data: createdEntries,
    });
  } catch (err) { next(err); }
};
