const { verifyAccessToken } = require('../utils/jwt');
const { AppError }           = require('./errorHandler');
const User                   = require('../models/User');

// ── Protect: verify JWT, attach user to req ────────────────────────
const protect = async (req, res, next) => {
  try {
    // 1. Get token from Authorization header or cookie
    let token;
    if (req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies?.accessToken) {
      token = req.cookies.accessToken;
    }

    if (!token) {
      return next(new AppError('Not authenticated. Please log in.', 401));
    }

    // 2. Verify token — verifyAccessToken returns null on any failure
    const decoded = verifyAccessToken(token);
    if (!decoded) {
      return next(new AppError('Session expired. Please log in again.', 401));
    }

    // 3. Check user still exists and is active
    const user = await User.findById(decoded.id).select('+passwordChangedAt');
    if (!user) {
      return next(new AppError('User no longer exists.', 401));
    }

    // 4. Check if password changed after token was issued
    if (user.changedPasswordAfter(decoded.iat)) {
      return next(new AppError('Password recently changed. Please log in again.', 401));
    }

    // 5. Check account is active
    if (!user.isActive) {
      return next(new AppError('Account is deactivated.', 403));
    }

    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
};

// ── Restrict to specific roles ─────────────────────────────────────
const restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return next(new AppError('You do not have permission to perform this action.', 403));
  }
  next();
};

// ── Admin only ─────────────────────────────────────────────────────
const adminOnly = (req, res, next) => {
  if (!req.user.isAdmin) {
    return next(new AppError('Admin access required.', 403));
  }
  next();
};

// ── Require per-module permission ───────────────────────────────────
// moduleKey: one of User.MODULE_KEYS (e.g. 'my_tasks', 'kanban', 'add_members')
// requiredLevel: 'viewer' | 'editor' | 'admin' — minimum level needed for this route
//
// Usage:
//   router.get('/',     requirePermission('kanban', 'viewer'), ctrl.list);
//   router.post('/',    requirePermission('kanban', 'editor'), ctrl.create);
//   router.delete('/:id', requirePermission('kanban', 'editor'), ctrl.remove);
//
// Admins (isAdmin === true) always pass, regardless of moduleKey/requiredLevel.
const requirePermission = (moduleKey, requiredLevel = 'viewer') => (req, res, next) => {
  if (!req.user) {
    return next(new AppError('Not authenticated.', 401));
  }
  if (!req.user.canAccess(moduleKey, requiredLevel)) {
    return next(new AppError(
      `You don't have ${requiredLevel === 'viewer' ? 'access to' : requiredLevel + ' access to'} this section.`,
      403
    ));
  }
  next();
};

const requireAnyPermission = (moduleKeys, requiredLevel = 'viewer') => (req, res, next) => {
  if (!req.user) return next(new AppError('Not authenticated.', 401));
  if (moduleKeys.some(key => req.user.canAccess(key, requiredLevel))) return next();
  return next(new AppError('You do not have permission to perform this action.', 403));
};

module.exports = { protect, restrictTo, adminOnly, requirePermission, requireAnyPermission };
