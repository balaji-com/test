const logger = require('../utils/logger');

// ── Operational error class ────────────────────────────────────────
class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    this.status = String(statusCode).startsWith('4') ? 'fail' : 'error';
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

// ── Specific error handlers ────────────────────────────────────────
const handleCastError = (err) =>
  new AppError(`Invalid ${err.path}: ${err.value}`, 400);

const handleDuplicateKey = (err) => {
  const field = Object.keys(err.keyValue)[0];
  return new AppError(`Duplicate value for '${field}'. Please use another value.`, 409);
};

const handleValidationError = (err) => {
  const messages = Object.values(err.errors).map((e) => e.message);
  return new AppError(`Validation failed: ${messages.join('. ')}`, 400);
};

const handleJWTError = () =>
  new AppError('Invalid token. Please log in again.', 401);

const handleJWTExpiredError = () =>
  new AppError('Your token has expired. Please log in again.', 401);

// ── Dev vs Production error responses ────────────────────────────
const sendErrorDev = (err, res) => {
  res.status(err.statusCode).json({
    status:  err.status,
    message: err.message,
    stack:   err.stack,
    error:   err,
  });
};

const sendErrorProd = (err, res) => {
  if (err.isOperational) {
    // Safe to send to client
    res.status(err.statusCode).json({ status: err.status, message: err.message });
  } else {
    // Unknown error — don't leak details
    logger.error('UNHANDLED ERROR', err);
    res.status(500).json({ status: 'error', message: 'Something went wrong.' });
  }
};

// ── Global error handler (must have 4 params) ─────────────────────
const globalErrorHandler = (err, req, res, next) => {
  console.log("error", err.message,err.statusCode, err.status, err.name)
  err.statusCode = err.statusCode || 500;
  err.status     = err.status     || 'error';

  logger.error(`${err.statusCode} ${err.message} — ${req.method} ${req.originalUrl}`);

  if (process.env.NODE_ENV === 'development') {
    return sendErrorDev(err, res);
  }

  // Transform Mongoose/JWT errors to AppError
  let error = { ...err, message: err.message };
  if (err.name === 'CastError')             error = handleCastError(err);
  if (err.code === 11000)                   error = handleDuplicateKey(err);
  if (err.name === 'ValidationError')       error = handleValidationError(err);
  if (err.name === 'JsonWebTokenError')     error = handleJWTError();
  if (err.name === 'TokenExpiredError')     error = handleJWTExpiredError();
  if (err.name === 'MulterError') {
    error = new AppError(
      err.code === 'LIMIT_FILE_SIZE' ? 'Files must be 10 MB or smaller.' : err.message,
      err.code === 'LIMIT_FILE_SIZE' ? 413 : 400
    );
  }

  sendErrorProd(error, res);
};

module.exports = { AppError, globalErrorHandler };
