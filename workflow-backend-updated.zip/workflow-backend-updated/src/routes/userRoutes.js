const router   = require('express').Router();
const userCtrl = require('../controllers/userController');
const { protect, adminOnly, requirePermission } = require('../middleware/auth');

router.use(protect);

router.get('/modules', userCtrl.getModules);   // metadata — any logged-in user can read
router.get('/active',  userCtrl.getActiveUsers); // active user list for dropdowns — any logged-in user

// Viewing the full team list (with permissions) requires add_members viewer access
router.get('/', requirePermission('add_members', 'viewer'), userCtrl.getUsers);

// Creating, editing, deleting members and assigning permissions stays admin-only —
// granting access to others is an administrative act, not a per-module "editor" act.
router.post('/',                adminOnly, userCtrl.createUser);
router.patch('/me',                        userCtrl.updateMe);
router.get('/:id',  requirePermission('add_members', 'viewer'), userCtrl.getUser);
router.patch('/:id',             adminOnly, userCtrl.updateUser);
router.patch('/:id/permissions', adminOnly, userCtrl.updatePermissions);
router.delete('/:id',            adminOnly, userCtrl.deleteUser);

module.exports = router;
