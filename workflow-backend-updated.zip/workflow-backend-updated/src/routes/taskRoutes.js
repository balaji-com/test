const router   = require('express').Router();
const taskCtrl  = require('../controllers/taskController');
const { protect, requirePermission, requireAnyPermission } = require('../middleware/auth');
const attachmentRoutes = require('./attachmentRoutes');

router.use(protect);   // All task routes require login

// ════════════════════════════════════════════════════════════════
// ALL WORKS — team-wide search/filter/list + exports (gated on 'all_works')
// Declared BEFORE '/:id' so 'all-works' isn't swallowed as an :id param.
// ════════════════════════════════════════════════════════════════
router.get('/all-works',                requirePermission('all_works', 'viewer'), taskCtrl.getAllWorks);
router.get('/all-works/members',        requirePermission('all_works', 'viewer'), taskCtrl.getAllWorksMembers);
router.get('/all-works/export/csv',     requirePermission('all_works', 'viewer'), taskCtrl.exportCSV);
router.get('/all-works/export/excel',   requirePermission('all_works', 'viewer'), taskCtrl.exportExcel);
router.get('/all-works/export/pdf',     requirePermission('all_works', 'viewer'), taskCtrl.exportPDF);
router.use('/:taskId/attachments', attachmentRoutes);

// ════════════════════════════════════════════════════════════════
// MY TASKS — personal task CRUD (gated on 'my_tasks')
// ════════════════════════════════════════════════════════════════
router.get('/',             requirePermission('my_tasks', 'viewer'), taskCtrl.getTasks);
router.get('/task-names',   requirePermission('my_tasks', 'viewer'), taskCtrl.getTaskNames);
router.get('/:id',          requirePermission('my_tasks', 'viewer'), taskCtrl.getTask);

router.post('/',      requirePermission('my_tasks', 'editor'), taskCtrl.createTask);
router.patch('/bulk', requirePermission('my_tasks', 'editor'), taskCtrl.bulkAction);
router.patch('/:id',  requireAnyPermission(['my_tasks', 'all_works'], 'editor'), taskCtrl.updateTask);
router.delete('/:id', requirePermission('my_tasks', 'editor'), taskCtrl.deleteTask);

module.exports = router;
