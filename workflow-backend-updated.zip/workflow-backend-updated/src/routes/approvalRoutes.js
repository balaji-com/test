const router = require('express').Router();
const ctrl   = require('../controllers/approvalController');
const { protect, requirePermission } = require('../middleware/auth');

router.use(protect);
router.post('/',               requirePermission('approvals', 'editor'), ctrl.sendRequest);
router.get('/',                requirePermission('approvals', 'viewer'), ctrl.listRequests);
router.patch('/:id/respond',   requirePermission('approvals', 'editor'), ctrl.respond);
router.patch('/:id/cancel',    requirePermission('approvals', 'editor'), ctrl.cancel);
router.get('/task/:taskId',    requirePermission('approvals', 'viewer'), ctrl.getTaskApprovals);

module.exports = router;
