const router = require('express').Router();
const { body } = require('express-validator');
const authCtrl = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');

// ── Validation rules ───────────────────────────────────────────────
const registerRules = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ min: 2 }),
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 4 }).withMessage('Password must be at least 4 characters'),
];

const loginRules = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password is required'),
];

// ── Routes ─────────────────────────────────────────────────────────
router.post('/register', authLimiter, registerRules, authCtrl.register);
router.post('/login',    authLimiter, loginRules,    authCtrl.login);
router.post('/refresh',  authCtrl.refresh);
router.post('/logout',   protect, authCtrl.logout);
router.get('/me',        protect, authCtrl.getMe);
router.patch('/change-password', protect, authCtrl.changePassword);

module.exports = router;
