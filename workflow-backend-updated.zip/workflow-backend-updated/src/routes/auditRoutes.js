const router    = require('express').Router();
const auditCtrl = require('../controllers/auditController');
const { protect, adminOnly, requirePermission } = require('../middleware/auth');

router.use(protect);

router.get('/',    requirePermission('audit_log', 'viewer'), auditCtrl.getAuditLog);
router.delete('/', adminOnly,                                auditCtrl.clearAuditLog);

module.exports = router;
