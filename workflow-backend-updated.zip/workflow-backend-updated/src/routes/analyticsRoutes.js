const router = require('express').Router();
const ctrl   = require('../controllers/analyticsController');
const { protect, requirePermission } = require('../middleware/auth');

router.use(protect);
router.get('/team-overview',   requirePermission('team_overview',    'viewer'), ctrl.teamOverview);
router.get('/team-overview/tasks', requirePermission('team_overview', 'viewer'), ctrl.teamOverviewTasks);
router.get('/monthly-report',  requirePermission('monthly_reports',  'viewer'), ctrl.monthlyReport);

module.exports = router;
