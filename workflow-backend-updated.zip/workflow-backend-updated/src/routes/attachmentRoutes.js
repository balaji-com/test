const router = require('express').Router({ mergeParams: true }); // mergeParams gives access to :taskId
const ctrl   = require('../controllers/attachmentController');
const { protect, requireAnyPermission } = require('../middleware/auth');

router.use(protect);
router.use((_req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// List all attachments for a task
router.get('/',
  requireAnyPermission(['my_tasks', 'all_works'], 'viewer'),
  ctrl.listAttachments
);

// Upload a new attachment
router.post('/',
  requireAnyPermission(['my_tasks', 'all_works'], 'editor'),
  ctrl.uploadMiddleware,
  ctrl.uploadAttachment
);

// Download a specific attachment
router.get('/:attachmentId/download',
  requireAnyPermission(['my_tasks', 'all_works'], 'viewer'),
  ctrl.downloadAttachment
);

// Delete a specific attachment
router.delete('/:attachmentId',
  requireAnyPermission(['my_tasks', 'all_works'], 'editor'),
  ctrl.deleteAttachment
);

module.exports = router;
