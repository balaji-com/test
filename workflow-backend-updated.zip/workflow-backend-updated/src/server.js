require('dotenv').config();

const express  = require('express');
const helmet   = require('helmet');
const cors     = require('cors');
const morgan   = require('morgan');
const cookieParser = require('cookie-parser');

const connectDB    = require('./config/database');
const logger       = require('./utils/logger');
const { globalErrorHandler, AppError } = require('./middleware/errorHandler');
const { apiLimiter } = require('./middleware/rateLimiter');

// ── Routes ─────────────────────────────────────────────────────────
const authRoutes      = require('./routes/authRoutes');
const taskRoutes      = require('./routes/taskRoutes');
const userRoutes      = require('./routes/userRoutes');
const auditRoutes     = require('./routes/auditRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');
const approvalRoutes  = require('./routes/approvalRoutes');
const planningRoutes  = require('./routes/planningRoutes');

const app = express();

// ── Security: Helmet ───────────────────────────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: process.env.NODE_ENV === 'production' ? undefined : false,
}));

// ── CORS ────────────────────────────────────────────────────────────
const configuredOrigins = (process.env.CORS_ORIGIN || '')
  .split(',').map(origin => origin.trim()).filter(Boolean);
const allowedOrigins = new Set([
  ...configuredOrigins,
  'http://localhost:4200',
  'http://localhost:63070',
]);
const corsOptions = {
  origin: (origin, cb) => {
    // Allow requests with no origin (Postman, server-to-server)
    if (!origin || allowedOrigins.has(origin)) return cb(null, true);
    cb(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,                       // Allow cookies
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));       // Pre-flight for all routes

// ── Parsers ─────────────────────────────────────────────────────────
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(cookieParser());

// ── HTTP request logging ────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev', {
    stream: { write: (msg) => logger.http(msg.trim()) },
  }));
}

// ── Rate limiting ───────────────────────────────────────────────────
app.use('/api', apiLimiter);

// ── Health check ────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.status(200).json({
    status:    'ok',
    timestamp: new Date().toISOString(),
    env:       process.env.NODE_ENV,
    version:   '1.0.0',
  });
});

// ── API routes ──────────────────────────────────────────────────────
app.use('/api/auth',       authRoutes);
app.use('/api/tasks',      taskRoutes);
app.use('/api/users',      userRoutes);
app.use('/api/audit',      auditRoutes);
app.use('/api/analytics',  analyticsRoutes);
app.use('/api/approvals',  approvalRoutes);
app.use('/api/planning',   planningRoutes);

// ── 404 handler ─────────────────────────────────────────────────────
app.all('*', (req, res, next) => {
  next(new AppError(`Route ${req.method} ${req.originalUrl} not found.`, 404));
});

// ── Global error handler ─────────────────────────────────────────────
app.use(globalErrorHandler);

// ── Start server ─────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT) || 5000;

const startServer = async () => {
  await connectDB();

  const server = app.listen(PORT, () => {
    logger.info(`🚀 Server running on http://localhost:${PORT} [${process.env.NODE_ENV}]`);
    logger.info(`📋 API docs: http://localhost:${PORT}/health`);
  });

  // ── Graceful shutdown ───────────────────────────────────────────
  const shutdown = async (signal) => {
    logger.warn(`${signal} received. Shutting down gracefully…`);
    server.close(async () => {
      const mongoose = require('mongoose');
      await mongoose.connection.close();
      logger.info('MongoDB connection closed.');
      process.exit(0);
    });
    // Force exit after 10s
    setTimeout(() => process.exit(1), 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT',  () => shutdown('SIGINT'));

  // ── Unhandled rejections ────────────────────────────────────────
  process.on('unhandledRejection', (err) => {
    logger.error(`Unhandled rejection: ${err.message}`);
    shutdown('unhandledRejection');
  });

  process.on('uncaughtException', (err) => {
    logger.error(`Uncaught exception: ${err.message}`);
    shutdown('uncaughtException');
  });
};

startServer();

module.exports = app;
