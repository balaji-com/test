# Workflow Backend — Node.js + Express + MongoDB

JWT-based REST API with CORS, Helmet, rate limiting, global error handling, and Mongoose.

---

## Quick Start

```bash
cd workflow-backend
npm install

# Copy env file and configure
cp .env.example .env
# Edit .env → set MONGODB_URI, JWT_SECRET, etc.

# Seed demo data (optional)
npm run seed

# Start development server
npm run dev

# Start production
npm start
```

---

## Environment Variables (.env)

| Variable | Default | Description |
|---|---|---|
| `PORT` | `5000` | Server port |
| `NODE_ENV` | `development` | Environment |
| `MONGODB_URI` | `mongodb://127.0.0.1:27017/hinduja_workflow` | MongoDB connection string |
| `JWT_SECRET` | — | **Change in production** |
| `JWT_EXPIRES_IN` | `7d` | Access token expiry |
| `JWT_REFRESH_SECRET` | — | **Change in production** |
| `JWT_REFRESH_EXPIRES_IN` | `30d` | Refresh token expiry |
| `CORS_ORIGIN` | `http://localhost:4200` | Allowed Angular origin |
| `RATE_LIMIT_MAX` | `100` | Requests per 15 min window |
| `AUTH_RATE_LIMIT_MAX` | `10` | Auth requests per 15 min |

---

## API Reference

### Auth — `/api/auth`

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/register` | — | Register new user |
| POST | `/login` | — | Login, returns accessToken |
| POST | `/refresh` | Cookie | Refresh access token |
| POST | `/logout` | ✅ | Logout, clear refresh token |
| GET | `/me` | ✅ | Get own profile |
| PATCH | `/change-password` | ✅ | Change password |

**Login request:**
```json
{ "email": "admin@hinduja.com", "password": "admin123" }
```
**Login response:**
```json
{
  "status": "success",
  "accessToken": "eyJhbGci…",
  "user": { "_id": "…", "name": "Admin", "email": "…", "role": "admin", "isAdmin": true }
}
```

---

### Tasks — `/api/tasks` 🔒

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Get tasks (filtered, paginated) |
| GET | `/:id` | Get single task |
| POST | `/` | Create task |
| PATCH | `/:id` | Update task |
| DELETE | `/:id` | Delete task |
| PATCH | `/bulk` | Bulk complete/delete |

**Query params for GET /tasks:**
`status`, `priority`, `assignedTo`, `month`, `year`, `search`, `page`, `limit`

---

### Planning Calendar — `/api/planning` 🔒

| Method | Endpoint | Description |
|---|---|---|
| GET | `/?month=3&year=2026` | List the signed-in user's planning entries for a month (admins see all) |
| POST | `/import` | Import an `.xlsx` content-planning workbook as planning entries |

Both routes require the `planner` permission; listing requires viewer access and importing requires editor access. Imports accept one workbook up to 10 MB and create one `PlanningEntry` MongoDB document for each non-empty row. Each row must include a publication date and content title. The template's blank-header content-title column is read as column C.

The importer maps the template columns for week, publication date, content title, offerings, segments / industries, format, content objectives, content pillars, target audience, channel, KPI, assignee, submission dates, reviewer, review dates, depository link, posted link, and status. Imported documents store the uploader, source filename, and import batch ID.

---

### Users — `/api/users` 🔒

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/` | Admin | List all members |
| POST | `/` | Admin | Create member |
| PATCH | `/me` | Any | Update own profile |
| GET | `/:id` | Any | Get member |
| PATCH | `/:id` | Admin | Update member |
| DELETE | `/:id` | Admin | Deactivate member |

---

### Audit Log — `/api/audit` 🔒

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/` | Any | Get audit entries |
| DELETE | `/` | Admin | Clear all entries |

---

## Security Features

- **Helmet** — Sets 15 security HTTP headers
- **CORS** — Whitelist-based, supports credentials
- **JWT** — Access token (7d) + Refresh token in httpOnly cookie (30d)
- **Rate Limiting** — 100 req/15min global, 10 req/15min on auth
- **Password Hashing** — bcrypt with cost factor 12
- **Global Error Handler** — Normalises Mongoose, JWT, and validation errors
- **Input Validation** — express-validator on all auth routes
- **Graceful Shutdown** — Closes DB on SIGTERM/SIGINT

---

## Demo Credentials (after `npm run seed`)

| Email | Password | Role |
|---|---|---|
| admin@hinduja.com | admin123 | Admin |
| sunitha@hinduja.com | sunitha123 | Member |
| priya@hinduja.com | priya123 | Member |
| ramesh@hinduja.com | ramesh123 | Viewer |

---

## Folder Structure

```
src/
├── server.js              # Entry point — Express app, middleware, routes
├── config/
│   └── database.js        # Mongoose connect with reconnect listeners
├── controllers/
│   ├── authController.js  # register, login, refresh, logout, me, changePassword
│   ├── taskController.js  # CRUD + bulk + audit logging
│   ├── userController.js  # Team member CRUD (admin)
│   └── auditController.js # Audit log read/clear
├── middleware/
│   ├── auth.js            # protect, restrictTo, adminOnly
│   ├── errorHandler.js    # AppError class + globalErrorHandler
│   └── rateLimiter.js     # apiLimiter + authLimiter
├── models/
│   ├── User.js            # Mongoose schema + bcrypt hooks
│   ├── Task.js            # Task schema with indexes
│   └── AuditLog.js        # Audit entry schema
├── routes/
│   ├── authRoutes.js
│   ├── taskRoutes.js
│   ├── userRoutes.js
│   └── auditRoutes.js
└── utils/
    ├── jwt.js             # signAccessToken, signRefreshToken, verify helpers
    ├── logger.js          # Winston — console + file transports
    └── seed.js            # Demo data seeder
```
