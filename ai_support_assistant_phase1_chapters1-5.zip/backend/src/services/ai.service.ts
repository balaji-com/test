function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Simulates an LLM streaming response.
 * We will replace this generator with a real model stream later.
 */
export async function* generateAIResponse(
  question: string
): AsyncGenerator<string> {
  const chunks = [
    `You asked: ${question}. `,
    "This is an AI response. ",
    "We are currently streaming ",
    "the response chunk by chunk."
  ];

  for (const chunk of chunks) {
    await delay(500);
    yield chunk;
  }
}