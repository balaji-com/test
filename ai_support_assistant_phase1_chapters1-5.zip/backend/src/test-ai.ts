import { generateAIResponse } from "./services/ai.service.js";

async function main(): Promise<void> {
  console.log("Starting simulated AI stream...\n");

  for await (const chunk of generateAIResponse("What is Node.js?")) {
    process.stdout.write(chunk);
  }

  process.stdout.write("\n\nStream complete.\n");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});