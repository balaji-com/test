import { Request, Response } from "express";
import { createUser } from "../services/user.service.js";

export function createUserController(
  req: Request,
  res: Response
): void {
  const { name, email, age } = req.body;

  const user = createUser(name, email, age);

  res.status(201).json({
    success: true,
    data: user
  });
}