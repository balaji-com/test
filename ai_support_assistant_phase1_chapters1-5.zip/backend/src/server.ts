import express from "express";
import userRoutes from "./routes/user.routes.js";
import chatRoutes from "./routes/chat.routes.js";

const app = express();

app.use(express.json());

app.use("/api", userRoutes);
app.use("/api", chatRoutes);

app.get("/api/health", (_req, res) => {
  res.json({
    success: true,
    message: "AI Support Assistant API is running"
  });
});

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});