# Chapters 1–5 Quick Notes

## Chapter 1 — Strict TypeScript

- `strict: true`
- Interfaces
- Typed services
- Typed Express controllers
- Routes → Controllers → Services

## Chapter 2 — Async JavaScript

- Promise
- async / await
- Promise.all
- Promise.allSettled
- Async generators

## Chapter 3 — Event Loop

Important mental model:

Synchronous code
→ microtasks (Promises / async continuations)
→ timer/task callbacks

Example:

```ts
console.log("A");

setTimeout(() => console.log("B"), 0);

Promise.resolve().then(() => console.log("C"));

console.log("D");
```

Output:

```text
A
D
C
B
```

## Chapter 4 — Async Iterators

```ts
async function* generate() {
  yield "Hello ";
  yield "world";
}

for await (const chunk of generate()) {
  console.log(chunk);
}
```

## Chapter 5 — Streaming

The live project uses:

```ts
for await (const chunk of generateAIResponse(question)) {
  res.write(chunk);
}

res.end();
```

This is the first streaming backend example.

## Next

Chapter 6: Server-Sent Events (SSE).
