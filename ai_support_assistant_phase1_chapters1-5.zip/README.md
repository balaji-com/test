# AI Support Assistant — Phase 1 Chapters 1–5

This project contains the live examples we have learned so far:

1. Strict TypeScript
2. Promises / async-await
3. Node.js Event Loop examples
4. Async Generators + `for await...of`
5. Streaming with Express `res.write()`

## Requirements

- Node.js 20+ recommended
- npm

## Run

```bash
cd backend
npm install
npm run dev
```

Server:

http://localhost:3000

Health check:

GET http://localhost:3000/api/health

## Test User API

POST http://localhost:3000/api/users

JSON body:

```json
{
  "name": "Balaji",
  "email": "balaji@gmail.com",
  "age": 30
}
```

## Test streaming API

POST http://localhost:3000/api/chat

JSON body:

```json
{
  "question": "What is Node.js?"
}
```

The server sends the simulated AI response progressively.

## Test async generator directly

```bash
npm run test:stream
```

## Build

```bash
npm run build
```

## What is intentionally simulated?

The AI provider is NOT connected yet. `generateAIResponse()` is a simulated async generator.

In the next lessons, we will build:

Async Generator
→ ReadableStream
→ SSE
→ Angular streaming UI
→ Real LLM API
→ RAG
→ Agents

This follows the progression in the supplied AI Engineer roadmap.
