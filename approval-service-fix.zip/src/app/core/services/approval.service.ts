import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface ApprovalUser {
  _id: string; name: string; email?: string; color?: string;
}

export interface ApprovalRequest {
  _id: string;
  taskId: { _id: string; task: string; status: string; priority: string; dueDate?: string } | string;
  taskName: string;
  requestedBy: ApprovalUser | string;
  requestedByName: string;
  requestedTo: ApprovalUser | string;
  requestedToName: string;
  message?: string;
  comment?: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';
  resolvedAt?: string;
  createdAt: string;
  taskReviewers?: ApprovalRequest[];   // sibling requests for the same task (sent tab)
  // Populated for sent tab — sibling requests for the same task
  taskReviewers?: ApprovalRequest[];
}

export interface ApprovalTaskSummary {
  total: number; approved: number; rejected: number; pending: number;
}

export interface ApprovalCounts {
  inboxPending: number; sentPending: number; totalResolved: number;
}

export interface ApprovalListResponse {
  status: string;
  total: number; page: number; limit: number; pages: number;
  counts: ApprovalCounts;
  data: ApprovalRequest[];
}

export interface TaskApprovalsResponse {
  status: string;
  summary: ApprovalTaskSummary;
  data: ApprovalRequest[];
}

@Injectable({ providedIn: 'root' })
export class ApprovalService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/approvals`;

  list(tab: 'inbox' | 'sent' | 'resolved' | 'all', page = 1, limit = 20): Observable<ApprovalListResponse> {
    const params = new HttpParams()
      .set('tab', tab).set('page', String(page)).set('limit', String(limit));
    return this.http.get<ApprovalListResponse>(this.base, { params })
      .pipe(catchError(this.handleError));
  }

  /** Send approval requests to one OR more reviewers at once. */
  send(taskId: string, reviewers: string[], message: string): Observable<ApprovalRequest[]> {
    return this.http.post<{ status: string; count: number; data: ApprovalRequest[] }>(
      this.base, { taskId, reviewers, message }
    ).pipe(map(r => r.data), catchError(this.handleError));
  }

  respond(id: string, action: 'approve' | 'reject', comment: string): Observable<ApprovalRequest> {
    return this.http.patch<{ status: string; data: ApprovalRequest }>(
      `${this.base}/${id}/respond`, { action, comment }
    ).pipe(map(r => r.data), catchError(this.handleError));
  }

  cancel(id: string): Observable<{ message: string }> {
    return this.http.patch<{ status: string; message: string }>(
      `${this.base}/${id}/cancel`, {}
    ).pipe(map(r => ({ message: r.message })), catchError(this.handleError));
  }

  getForTask(taskId: string): Observable<TaskApprovalsResponse> {
    return this.http.get<TaskApprovalsResponse>(`${this.base}/task/${taskId}`)
      .pipe(catchError(this.handleError));
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg = err.error?.message || err.error?.error ||
      (err.status === 0 ? 'Cannot reach server.' : `Server error ${err.status}`);
    return throwError(() => new Error(msg));
  }
}
