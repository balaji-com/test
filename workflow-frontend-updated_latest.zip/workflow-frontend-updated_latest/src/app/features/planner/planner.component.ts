import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PlanningEntry } from '../../core/models/planning-entry.model';
import { PlanningService } from '../../core/services/planning.service';
import { PermissionsService } from '../../core/services/permissions.service';

interface PlannerDay {
  date: Date;
  iso: string;
  isToday: boolean;
  other: boolean;
  planningEntries: PlanningEntry[];
}

@Component({ selector:'app-planner', standalone:true, imports:[NgFor,NgIf,FormsModule],
  templateUrl:'./planner.component.html', styleUrl:'./planner.component.css' })
export class PlannerComponent implements OnInit {
  readonly perms = inject(PermissionsService);
  private readonly planningService = inject(PlanningService);
  private now = new Date();
  currentYear  = signal(this.now.getFullYear());
  currentMonth = signal(this.now.getMonth());
  filterMember = signal('');
  planningEntries = signal<PlanningEntry[]>([]);
  planningLoading = signal(false);
  importing = signal(false);
  importStatus = signal<{ message: string; error: boolean } | null>(null);
  MONTH_NAMES=['January','February','March','April','May','June','July','August','September','October','November','December'];
  DAY_NAMES=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  COLORS=['#2d52e6','#0aab78','#c8890a','#6336d6','#0887b0','#d43b3b','#e8720c'];

  ngOnInit(): void { this.loadPlanningEntries(); }

  get members(){
    return [...new Set(this.planningEntries().map(entry => entry.assignedTo).filter(Boolean))].sort();
  }
  get monthLabel(){ return `${this.MONTH_NAMES[this.currentMonth()]} ${this.currentYear()}`; }

  memberColor(name:string){ return this.COLORS[(name || 'Unassigned').charCodeAt(0)%this.COLORS.length]; }

  calDays = computed(()=>{
    const y=this.currentYear(), m=this.currentMonth();
    const firstDay=new Date(y,m,1).getDay();
    const daysInMonth=new Date(y,m+1,0).getDate();
    const todayStr=new Date().toISOString().slice(0,10);
    const entries=this.planningEntries().filter(e=>!this.filterMember()||e.assignedTo===this.filterMember());
    const days:PlannerDay[]=[];
    const prev=new Date(y,m,0).getDate();
    for(let i=firstDay-1;i>=0;i--){ const d=new Date(y,m-1,prev-i); days.push({date:d,iso:d.toISOString().slice(0,10),isToday:false,other:true,planningEntries:[]}); }
    for(let d=1;d<=daysInMonth;d++){ const date=new Date(y,m,d); const iso=date.toISOString().slice(0,10); days.push({date,iso,isToday:iso===todayStr,other:false,planningEntries:entries.filter(e=>e.publicationDate===iso)}); }
    const rem=42-days.length;
    for(let d=1;d<=rem;d++){ const date=new Date(y,m+1,d); days.push({date,iso:date.toISOString().slice(0,10),isToday:false,other:true,planningEntries:[]}); }
    return days;
  });

  prev(){ if(this.currentMonth()===0){this.currentMonth.set(11);this.currentYear.update(y=>y-1);}else{this.currentMonth.update(m=>m-1);} this.loadPlanningEntries(); }
  next(){ if(this.currentMonth()===11){this.currentMonth.set(0);this.currentYear.update(y=>y+1);}else{this.currentMonth.update(m=>m+1);} this.loadPlanningEntries(); }

  loadPlanningEntries(): void {
    this.planningLoading.set(true);
    this.importStatus.set(null);
    this.planningService.getEntries(this.currentMonth() + 1, this.currentYear()).subscribe({
      next: entries => {
        this.planningEntries.set(entries);
        this.planningLoading.set(false);
      },
      error: err => {
        this.importStatus.set({ message: err.message, error: true });
        this.planningLoading.set(false);
      },
    });
  }

  onWorkbookSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;

    if (!/\.xlsx$/i.test(file.name)) {
      this.importStatus.set({ message: 'Choose an .xlsx workbook.', error: true });
      return;
    }

    this.importing.set(true);
    this.importStatus.set(null);
    this.planningService.importWorkbook(file).subscribe({
      next: response => {
        const firstDate = response.data.reduce(
          (earliest, entry) => entry.publicationDate < earliest ? entry.publicationDate : earliest,
          response.data[0].publicationDate
        );
        const [year, month] = firstDate.split('-').map(Number);
        this.currentYear.set(year);
        this.currentMonth.set(month - 1);
        this.planningEntries.set(response.data);
        this.importStatus.set({
          message: `${response.importedCount} content plan${response.importedCount === 1 ? '' : 's'} imported and saved.`,
          error: false,
        });
        this.importing.set(false);
      },
      error: err => {
        this.importStatus.set({ message: err.message, error: true });
        this.importing.set(false);
      },
    });
  }
}
