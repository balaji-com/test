import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskService, AllWorksGroup, AllWorksMember, ExportFormat } from '../../core/services/task.service';
import { UserService, Member } from '../../core/services/user.service';
import { PermissionsService } from '../../core/services/permissions.service';
import { Task, TaskStatus, TaskPriority, assignedToName } from '../../core/models/task.model';

interface Toast { msg: string; type: 'success' | 'error'; }

// ── Category → Sub-category map (mirrors My Tasks for a consistent edit form) ──
const CATEGORIES: Record<string, string[]> = {
  'Content':    ['Blog', 'Article', 'Whitepaper', 'Case Study', 'Brochure'],
  'Design':     ['Banner', 'Infographic', 'Flyer', 'Poster', 'Emailer'],
  'Posting':    ['LinkedIn', 'Twitter/X', 'Instagram', 'Facebook', 'YouTube'],
  'Video':      ['Reel', 'Short', 'Corporate Video', 'Webinar'],
  'Newsletter': ['Internal', 'External', 'Product Update'],
  'Copy':       ['Event Page', 'Landing Page', 'Ad Copy', 'Script'],
  'PR':         ['Press Release', 'Media Note', 'Interview'],
  'Campaign':   ['Email Campaign', 'Social Campaign', 'SEO Campaign'],
  'Reporting':  ['Monthly Report', 'Weekly Report', 'Analytics'],
  'Other':      [],
};

@Component({
  selector: 'app-all-works',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule],
  templateUrl: './all-works.component.html',
  styleUrl: './all-works.component.css'
})
export class AllWorksComponent implements OnInit {
  private readonly svc     = inject(TaskService);
  private readonly userSvc = inject(UserService);
  readonly perms            = inject(PermissionsService);

  /** True if the user has 'editor' or 'admin' on all_works — gates the Edit action. */
  readonly canEdit = computed(() => this.perms.canEdit('all_works'));

  // ── Data ─────────────────────────────────────────────────────────
  groups    = signal<AllWorksGroup[]>([]);
  members   = signal<AllWorksMember[]>([]);   // for the filter dropdown (all assignees with tasks)
  allMembers = signal<Member[]>([]);          // active members for the edit form's Assigned-To dropdown
  total     = signal(0);
  loading   = signal(true);
  exporting = signal<ExportFormat | null>(null);
  toast     = signal<Toast | null>(null);

  // ── Filters (all wired to backend — no client-side filtering) ────
  filterQ        = signal('');
  filterMember   = signal('');   // member _id
  filterStatus   = signal('');
  filterPriority = signal('');
  filterMonth    = signal('');
  filterYear     = signal('');

  expandedGroups = signal<Set<string>>(new Set());

  // ── Edit modal state ───────────────────────────────────────────────
  showModal = signal(false);
  saving    = signal(false);
  formError = signal('');
  form      = signal<Partial<Task>>({});

  readonly MONTHS = ['January','February','March','April','May','June',
                     'July','August','September','October','November','December'];
  readonly YEARS  = ['2024','2025','2026','2027'];
  readonly STATUSES: TaskStatus[]     = ['Not Started', 'In Progress', 'In Review', 'Completed'];
  readonly PRIORITIES: TaskPriority[] = ['High', 'Medium', 'Low'];
  readonly FUNCTIONS = ['Social Media', 'Internal Communication', 'External Communication', 'Events'];
  readonly CATEGORIES_KEYS = Object.keys(CATEGORIES);
  readonly BRIEF_OPTIONS = ['Given', 'NA', 'Not Given'];

  // Sub-categories for the currently selected category in the edit form
  readonly subCats = computed(() => CATEGORIES[this.form().cat || ''] || []);

  private searchDebounce: ReturnType<typeof setTimeout> | null = null;

  ngOnInit(): void {
    this.loadMembers();
    this.loadAllMembers();
    this.loadGroups();
  }

  // ── GET /api/tasks/all-works/members ──────────────────────────────
  loadMembers(): void {
    this.svc.getAllWorksMembers().subscribe({
      next:  (members: AllWorksMember[]) => this.members.set(members),
      error: () => {} // non-critical — the filter dropdown just stays empty
    });
  }

  // ── GET /api/users/active — active members for the edit form's Assigned-To select ──
  loadAllMembers(): void {
    this.userSvc.getActiveUsers().subscribe({
      next:  (users: Member[]) => this.allMembers.set(users),
      error: () => {} // non-critical
    });
  }

  // ── GET /api/tasks/all-works ──────────────────────────────────────
  loadGroups(): void {
    this.loading.set(true);
    this.svc.getAllWorks({
      search:     this.filterQ()       || undefined,
      assignedTo: this.filterMember()  || undefined,
      status:     (this.filterStatus()   as any) || undefined,
      priority:   (this.filterPriority() as any) || undefined,
      month:      this.filterMonth()   || undefined,
      year:       this.filterYear()    || undefined,
    }).subscribe({
      next: (groups: AllWorksGroup[]) => {
        this.groups.set(groups);
        this.total.set(groups.reduce((a, g) => a + g.count, 0));
        this.loading.set(false);
        // Auto-expand the first few groups so the page isn't empty-looking
        if (this.expandedGroups().size === 0 && groups.length > 0) {
          this.expandedGroups.set(new Set(groups.slice(0, 3).map(g => g.taskName)));
        }
      },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  /** Patches the freshly-saved task into the existing groups array in place, so scroll/expand state survives. */
  private patchTaskInPlace(updated: Task): void {
    this.groups.update(groups =>
      groups.map(g => ({
        ...g,
        items: g.items.map(t => t._id === updated._id ? updated : t),
      }))
    );
  }

  // ── Debounced search — re-query the server, don't filter client-side ──
  onSearchInput(value: string): void {
    this.filterQ.set(value);
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.searchDebounce = setTimeout(() => this.loadGroups(), 350);
  }

  onFilterChange(): void {
    this.loadGroups();
  }

  // ── Group expand/collapse ─────────────────────────────────────────
  toggleGroup(taskName: string): void {
    this.expandedGroups.update(s => {
      const next = new Set(s);
      next.has(taskName) ? next.delete(taskName) : next.add(taskName);
      return next;
    });
  }
  isExpanded(taskName: string): boolean { return this.expandedGroups().has(taskName); }

  expandAll(): void { this.expandedGroups.set(new Set(this.groups().map(g => g.taskName))); }
  collapseAll(): void { this.expandedGroups.set(new Set()); }

  // ── Export → GET /api/tasks/all-works/export/{csv|excel|pdf} ─────
  exportAs(format: ExportFormat): void {
    this.exporting.set(format);
    this.svc.exportAllWorks(format, {
      search:     this.filterQ()       || undefined,
      assignedTo: this.filterMember()  || undefined,
      status:     (this.filterStatus()   as any) || undefined,
      priority:   (this.filterPriority() as any) || undefined,
      month:      this.filterMonth()   || undefined,
      year:       this.filterYear()    || undefined,
    }).subscribe({
      next: (blob: Blob) => {
        this.svc.downloadBlob(blob, format);
        this.exporting.set(null);
        this.showToast(`${format.toUpperCase()} export downloaded.`, 'success');
      },
      error: (err: Error) => { this.exporting.set(null); this.showToast(err.message, 'error'); }
    });
  }

  // ════════════════════════════════════════════════════════════════
  // EDIT — open modal, patch fields, save to backend
  // ════════════════════════════════════════════════════════════════

  openEditModal(t: Task): void {
    if (!this.canEdit()) { this.showToast('You have view-only access to this section.', 'error'); return; }
    // Normalise assignedTo to a plain _id string for the <select>, since the
    // server returns it populated as { _id, name, email, color } on read.
    const assignedToId = typeof t.assignedTo === 'string' ? t.assignedTo : (t.assignedTo?._id ?? '');
    this.form.set({ ...t, assignedTo: assignedToId });
    this.formError.set('');
    this.saving.set(false);
    this.showModal.set(true);
  }

  closeModal(): void {
    this.showModal.set(false);
    this.form.set({});
    this.formError.set('');
  }

  closeOnBackdrop(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) this.closeModal();
  }

  patchForm(field: keyof Task, value: any): void {
    this.form.update(f => ({ ...f, [field]: value }));
    if (field === 'cat') this.form.update(f => ({ ...f, sub: '' }));
  }

  // ── Submit edit → PATCH /api/tasks/:id ────────────────────────────
  submitEdit(): void {
    this.formError.set('');
    const f = this.form();

    if (!f.task?.trim())  { this.formError.set('Task name is required.');   return; }
    if (!f.fn)             { this.formError.set('Function is required.');    return; }
    if (!f.cat)            { this.formError.set('Category is required.');    return; }
    if (!f.assignedTo)     { this.formError.set('Assigned To is required.'); return; }
    if (!f.priority)       { this.formError.set('Priority is required.');    return; }
    if (!f.status)         { this.formError.set('Status is required.');      return; }

    const id = f._id;
    if (!id) { this.formError.set('Missing task id — cannot save.'); return; }

    this.saving.set(true);

    // Strip fields the backend doesn't accept / shouldn't be overwritten
    const { _id, createdAt, updatedAt, reviewers, assignedToName: _an, ...payload } = f as Task;

    this.svc.updateTask(id, { ...payload, rework: Number(payload.rework) || 0 }).subscribe({
      next: (updated: Task) => {
        this.patchTaskInPlace(updated);
        this.saving.set(false);
        this.showModal.set(false);
        this.form.set({});
        this.showToast('✓ Task updated successfully!', 'success');
      },
      error: (err: Error) => { this.saving.set(false); this.formError.set(err.message); }
    });
  }

  // ── Display helpers ────────────────────────────────────────────────
  taskAssigneeName(t: Task): string { return assignedToName(t); }

  initials(name: string): string {
    return (name || '').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '—';
  }

  completionPct(items: Task[]): number {
    if (!items.length) return 0;
    return Math.round(items.filter(t => t.status === 'Completed').length / items.length * 100);
  }

  statusChip(status: string): string {
    const map: Record<string, string> = {
      'Completed': 'chip-completed', 'In Progress': 'chip-progress',
      'In Review': 'chip-review', 'Not Started': 'chip-ns',
    };
    return map[status] ?? '';
  }

  statusIcon(status: string): string {
    const map: Record<string, string> = {
      'Completed': '✓', 'In Progress': '⚡', 'In Review': '👁', 'Not Started': '○',
    };
    return map[status] ?? status;
  }

  priorityClass(p: string): string {
    return p === 'High' ? 'pri-high' : p === 'Medium' ? 'pri-medium' : 'pri-low';
  }

  rowOverdueClass(t: Task): string {
    const today = new Date().toISOString().slice(0, 10);
    return (t.dueDate && t.dueDate < today && t.status !== 'Completed') ? 'row-overdue' : '';
  }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
