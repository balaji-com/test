import { Component, signal, computed } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface SeoResult { score: number; category: string; label: string; detail: string; pass: boolean; }

@Component({
  selector: 'app-seo-checker', standalone: true, imports: [NgIf, NgFor, FormsModule],
  templateUrl: './seo-checker.component.html', styleUrl: './seo-checker.component.css'
})
export class SeoCheckerComponent {
  url     = signal('');
  title   = signal('');
  metaDesc = signal('');
  content = signal('');
  loading = signal(false);
  results = signal<SeoResult[]>([]);
  totalScore = signal(0);
  analyzed = signal(false);

  readonly passedCount = computed(() => this.results().filter(r => r.pass).length);
  readonly totalCount  = computed(() => this.results().length);

  analyze(): void {
    if (!this.content() && !this.url()) return;
    this.loading.set(true);
    setTimeout(() => {
      const t = this.title(), md = this.metaDesc(), c = this.content();
      const wordCount = c.split(/\s+/).filter(Boolean).length;
      const checks: SeoResult[] = [
        { category: 'Title',       label: 'Title length (50–60 chars)',         detail: `Current: ${t.length} chars`,         pass: t.length >= 50 && t.length <= 60,     score: 10 },
        { category: 'Meta',        label: 'Meta description (120–160 chars)',   detail: `Current: ${md.length} chars`,        pass: md.length >= 120 && md.length <= 160, score: 10 },
        { category: 'Content',     label: 'Content length (>800 words)',        detail: `Current: ~${wordCount} words`,       pass: wordCount >= 800,                     score: 15 },
        { category: 'Keywords',    label: 'Keyword in title',                   detail: t.length > 0 ? 'Title present' : 'No title',    pass: t.length > 5,       score: 10 },
        { category: 'Keywords',    label: 'Keyword in meta description',        detail: md.length > 0 ? 'Meta present' : 'No meta',     pass: md.length > 10,     score: 10 },
        { category: 'Readability', label: 'Short paragraphs (avg < 100 words)', detail: 'Check paragraph lengths',            pass: true,                                 score: 10 },
        { category: 'Structure',   label: 'H2/H3 subheadings present',          detail: 'Check content for ##/### markers',  pass: c.includes('##'),                     score: 10 },
        { category: 'Links',       label: 'Internal/external links mentioned',  detail: 'Check for http links',              pass: c.includes('http') || c.includes('www'), score: 10 },
        { category: 'Media',       label: 'Image alt text / media references',  detail: 'Check for image references',        pass: c.toLowerCase().includes('image') || c.includes('!['), score: 10 },
        { category: 'Technical',   label: 'Content freshness signals',          detail: 'Mentions dates/years',              pass: /202[4-9]|2030/.test(c),              score: 5 },
      ];
      const passed = checks.filter(r => r.pass).reduce((a, r) => a + r.score, 0);
      const total  = checks.reduce((a, r) => a + r.score, 0);
      this.results.set(checks);
      this.totalScore.set(Math.round(passed / total * 100));
      this.loading.set(false);
      this.analyzed.set(true);
    }, 800);
  }

  scoreColor(s: number): string { return s >= 80 ? 'var(--green)' : s >= 50 ? 'var(--amber)' : 'var(--red)'; }
  scoreLabel(s: number): string { return s >= 80 ? 'Good' : s >= 50 ? 'Needs Work' : 'Poor'; }
  resultIcon(pass: boolean): string { return pass ? '✅' : '❌'; }
}
