import { Component, signal } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
interface FieldDef{id:string;label:string;type:string;required:boolean;locked?:boolean;}
interface Section{key:string;icon:string;label:string;fields:FieldDef[];}
@Component({ selector:'app-customize-fields', standalone:true, imports:[NgIf,NgFor,FormsModule],
  templateUrl:'./customize-fields.component.html', styleUrl:'./customize-fields.component.css' })
export class CustomizeFieldsComponent {
  sections = signal<Section[]>([
    {key:'task-details',icon:'📝',label:'Task Details',fields:[
      {id:'f-task',label:'Task Name',type:'text',required:true,locked:true},
      {id:'f-fn',label:'Function',type:'select',required:true,locked:true},
      {id:'f-cat',label:'Category',type:'select',required:true,locked:true},
      {id:'f-sub',label:'Sub-Category',type:'select',required:false},
    ]},
    {key:'assignment',icon:'👤',label:'Assignment & Dates',fields:[
      {id:'f-at',label:'Assigned To',type:'select',required:true,locked:true},
      {id:'f-sd',label:'Start Date',type:'date',required:false},
      {id:'f-dd',label:'Due Date',type:'date',required:false},
      {id:'f-pri',label:'Priority',type:'select',required:true},
    ]},
    {key:'tracking',icon:'📊',label:'Tracking & Hours',fields:[
      {id:'f-st',label:'Status',type:'select',required:true,locked:true},
      {id:'f-eh',label:'Estimated Hours',type:'number',required:false},
      {id:'f-ah',label:'Actual Hours',type:'number',required:false},
      {id:'f-rw',label:'Rework Count',type:'number',required:false},
    ]},
  ]);
  saved=signal(false);
  toggleRequired(sKey:string, fId:string){
    this.sections.update(ss=>ss.map(s=>s.key!==sKey?s:{...s,fields:s.fields.map(f=>f.id!==fId?f:{...f,required:!f.required})}));
  }
  save(){this.saved.set(true);setTimeout(()=>this.saved.set(false),2500);}
}
