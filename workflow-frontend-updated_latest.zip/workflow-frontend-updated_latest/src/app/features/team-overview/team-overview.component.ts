import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf, TitleCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  AnalyticsService, MemberOverview, TeamOverviewTaskQuery, TeamTotals
} from '../../core/services/analytics.service';
import { PermissionsService } from '../../core/services/permissions.service';
import { Task, TaskPriority, TaskStatus, assignedToName } from '../../core/models/task.model';
const MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December'];
const YEARS  = ['2024','2025','2026','2027'];

interface Toast { msg: string; type: 'success'|'error'; }
interface TaskListFilter extends TeamOverviewTaskQuery { title: string; }

@Component({
  selector: 'app-team-overview',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule,TitleCasePipe],
  templateUrl: './team-overview.component.html',
  styleUrl: './team-overview.component.css',
})
export class TeamOverviewComponent implements OnInit {
  private readonly svc = inject(AnalyticsService);
  readonly perms        = inject(PermissionsService);

  members  = signal<MemberOverview[]>([]);
  totals   = signal<TeamTotals | null>(null);
  loading  = signal(true);
  toast    = signal<Toast | null>(null);
  taskList = signal<Task[]>([]);
  taskListLoading = signal(false);
  taskListError = signal<string | null>(null);
  taskListTotal = signal(0);
  taskListPage = signal(1);
  taskListPages = signal(1);
  taskListFilter = signal<TaskListFilter | null>(null);

  filterYear  = signal('');
  filterMonth = signal('');

  readonly MONTHS = MONTHS;
  readonly YEARS  = YEARS;

  // Selected member for drill-down panel
  selected = signal<MemberOverview | null>(null);

  readonly statusStats = computed(() => this.members().reduce((stats, member) => ({
    notStarted: stats.notStarted + member.notSt,
    inProgress: stats.inProgress + member.inProg,
    inReview: stats.inReview + member.inRev,
    completed: stats.completed + member.done,
  }), { notStarted: 0, inProgress: 0, inReview: 0, completed: 0 }));

  readonly statusTotal = computed(() => {
    const stats = this.statusStats();
    return stats.notStarted + stats.inProgress + stats.inReview + stats.completed;
  });

  readonly priorityStats = computed(() => this.members().reduce((stats, member) => ({
    high: stats.high + member.byPriority.High,
    medium: stats.medium + member.byPriority.Medium,
    low: stats.low + member.byPriority.Low,
  }), { high: 0, medium: 0, low: 0 }));

  readonly priorityTotal = computed(() => {
    const stats = this.priorityStats();
    return stats.high + stats.medium + stats.low;
  });

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.selected.set(null);
    this.taskListFilter.set(null);
    this.svc.teamOverview(this.filterYear() || undefined, this.filterMonth() || undefined).subscribe({
      next: res => {
        this.members.set(res.data);
        this.totals.set(res.totals);
        this.loading.set(false);
      },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  onFilterChange(): void { this.load(); }
  clearFilters(): void { this.filterYear.set(''); this.filterMonth.set(''); this.load(); }
  readonly hasFilter = computed(() => !!(this.filterYear() || this.filterMonth()));

  selectMember(m: MemberOverview): void {
    if (this.taskListFilter()?.assignedTo === m._id) {
      this.closeTaskList();
      return;
    }
    this.selected.set(m);
    this.openTaskList({ title: `${m.name}'s tasks`, assignedTo: m._id });
  }

  selectMemberTasks(
    member: MemberOverview,
    title: string,
    filter: Pick<TeamOverviewTaskQuery, 'status' | 'priority' | 'focus'> = {}
  ): void {
    this.selected.set(member);
    this.openTaskList({ ...filter, assignedTo: member._id, title: `${member.name} · ${title}` });
  }

  showTasks(title: string, filter: Pick<TeamOverviewTaskQuery, 'status' | 'priority' | 'focus'> = {}): void {
    this.selected.set(null);
    this.openTaskList({ ...filter, title });
  }

  private openTaskList(filter: TaskListFilter): void {
    this.taskListFilter.set(filter);
    this.taskList.set([]);
    this.taskListTotal.set(0);
    this.taskListPage.set(1);
    this.taskListPages.set(1);
    this.loadTaskList(1);
  }

  loadTaskList(page: number): void {
    const filter = this.taskListFilter();
    if (!filter) return;
    this.taskListLoading.set(true);
    this.taskListError.set(null);
    const { title: _title, ...query } = filter;
    this.svc.teamOverviewTasks({
      ...query,
      year: this.filterYear() || undefined,
      month: this.filterMonth() || undefined,
      page,
      limit: 25,
    }).subscribe({
      next: response => {
        this.taskList.set(response.data);
        this.taskListTotal.set(response.total);
        this.taskListPage.set(response.page);
        this.taskListPages.set(response.pages);
        this.taskListLoading.set(false);
      },
      error: (err: Error) => {
        this.taskListLoading.set(false);
        this.taskListError.set(err.message);
        this.showToast(err.message, 'error');
      }
    });
  }

  closeTaskList(): void {
    this.taskListFilter.set(null);
    this.taskList.set([]);
    this.taskListError.set(null);
    this.taskListTotal.set(0);
    this.taskListPage.set(1);
    this.taskListPages.set(1);
    this.selected.set(null);
  }

  taskAssigneeName(task: Task): string {
    return assignedToName(task);
  }

  statusClass(status: TaskStatus): string {
    const classes: Record<TaskStatus, string> = {
      'Not Started': 'task-status-not-started',
      'In Progress': 'task-status-in-progress',
      'In Review': 'task-status-in-review',
      'Completed': 'task-status-completed',
    };
    return classes[status];
  }

  priorityClass(priority: TaskPriority): string {
    return `task-priority-${priority.toLowerCase()}`;
  }

  dueLabel(dueDate: string): string {
    if (!dueDate) return 'No due date';
    const today = new Date().toISOString().slice(0, 10);
    return dueDate < today ? `Overdue · ${dueDate}` : dueDate;
  }

  initials(name: string): string {
    return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  }

  barWidth(value: number, total: number): string {
    return `${total ? Math.round(value / total * 100) : 0}%`;
  }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success'|'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
