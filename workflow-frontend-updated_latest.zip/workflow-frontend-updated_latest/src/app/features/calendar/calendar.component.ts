import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf, DatePipe, SlicePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { from } from 'rxjs';
import { concatMap, toArray } from 'rxjs/operators';
import { AuthService } from '../../core/services/auth.service';
import { TaskService } from '../../core/services/task.service';
import { PermissionsService } from '../../core/services/permissions.service';
import { Task, Attachment, assignedToName, assignedToRole } from '../../core/models/task.model';


type ViewMode = 'mine' | 'team';

interface CalDay {
  date: Date;
  iso: string;
  isToday: boolean;
  isOtherMonth: boolean;
  tasks: Task[];
}

interface Toast { msg: string; type: 'success' | 'error'; }

@Component({
  selector: 'app-calendar',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule, SlicePipe],
  templateUrl: './calendar.component.html',
  styleUrl: './calendar.component.css'
})
export class CalendarComponent implements OnInit {
  readonly auth  = inject(AuthService);
  readonly perms = inject(PermissionsService);
  private readonly svc  = inject(TaskService);

  private now = new Date();
  currentYear  = signal(this.now.getFullYear());
  currentMonth = signal(this.now.getMonth());

  viewMode     = signal<ViewMode>('mine');
  readonly canViewTeam = computed(() => this.perms.canView('all_works'));
  readonly canEdit     = computed(() => this.viewMode() === 'team'
    ? this.perms.canEdit('all_works')
    : this.perms.canEdit('my_tasks'));

  // ── Data ──────────────────────────────────────────────────────────
  myTasks   = signal<Task[]>([]);
  teamTasks = signal<Task[]>([]);
  loading   = signal(true);
  toast     = signal<Toast | null>(null);

  readonly activeTasks = computed(() =>
    this.viewMode() === 'team' ? this.teamTasks() : this.myTasks()
  );

  // ── Modal state ───────────────────────────────────────────────────
  modalTask      = signal<Task | null>(null);
  modalEdit      = signal<Partial<Task>>({});
  modalSaving    = signal(false);
  modalOpen      = signal(false);

  // Attachments
  attachments        = signal<Attachment[]>([]);
  attachmentsLoading = signal(false);
  uploadingFile      = signal(false);
  dragOver           = signal(false);
  selectedFiles      = signal<File[]>([]);

  readonly STATUS_OPTIONS  = ['Not Started', 'In Progress', 'In Review', 'Completed'];
  readonly PRIORITY_OPTIONS = ['High', 'Medium', 'Low'];
  readonly BRIEF_OPTIONS    = ['Given', 'Not Given', 'NA'];

  MONTH_NAMES = ['January','February','March','April','May','June','July','August',
                 'September','October','November','December'];
  DAY_NAMES   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  readonly monthLabel = computed(() =>
    `${this.MONTH_NAMES[this.currentMonth()]} ${this.currentYear()}`
  );

  readonly calDays = computed((): CalDay[] => {
    const y = this.currentYear(), m = this.currentMonth();
    const firstDay    = new Date(y, m, 1).getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const todayStr    = new Date().toISOString().slice(0, 10);
    const tasks       = this.activeTasks();
    const days: CalDay[] = [];

    const prevDays = new Date(y, m, 0).getDate();
    for (let i = firstDay - 1; i >= 0; i--) {
      const d = new Date(y, m - 1, prevDays - i);
      days.push({ date: d, iso: d.toISOString().slice(0, 10), isToday: false, isOtherMonth: true, tasks: [] });
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(y, m, d);
      const iso  = date.toISOString().slice(0, 10);
      days.push({ date, iso, isToday: iso === todayStr, isOtherMonth: false,
        tasks: tasks.filter(t => t.dueDate === iso) });
    }
    const remaining = 42 - days.length;
    for (let d = 1; d <= remaining; d++) {
      const date = new Date(y, m + 1, d);
      days.push({ date, iso: date.toISOString().slice(0, 10), isToday: false, isOtherMonth: true, tasks: [] });
    }
    return days;
  });

  // ── Lifecycle ──────────────────────────────────────────────────────
  ngOnInit(): void { this.loadMine(); }

  // ── Toggle ─────────────────────────────────────────────────────────
  setViewMode(mode: ViewMode): void {
    if (mode === 'team' && !this.canViewTeam()) {
      this.showToast("You don't have permission to view the team calendar.", 'error');
      return;
    }
    if (this.viewMode() === mode) return;
    this.viewMode.set(mode);
    if (mode === 'team' && this.teamTasks().length === 0) this.loadTeam();
    else if (mode === 'mine' && this.myTasks().length === 0) this.loadMine();
  }

  loadMine(): void {
    this.loading.set(true);
    this.svc.getTasks().subscribe({
      next:  tasks => { this.myTasks.set(tasks); this.loading.set(false); },
      error: err   => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  loadTeam(): void {
    this.loading.set(true);
    this.svc.getAllWorks({}).subscribe({
      next:  groups => { this.teamTasks.set(groups.flatMap(g => g.items)); this.loading.set(false); },
      error: err    => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  refresh(): void { this.viewMode() === 'team' ? this.loadTeam() : this.loadMine(); }

  // ── Month nav ─────────────────────────────────────────────────────
  prevMonth(): void {
    if (this.currentMonth() === 0) { this.currentMonth.set(11); this.currentYear.update(y => y - 1); }
    else { this.currentMonth.update(m => m - 1); }
  }
  nextMonth(): void {
    if (this.currentMonth() === 11) { this.currentMonth.set(0); this.currentYear.update(y => y + 1); }
    else { this.currentMonth.update(m => m + 1); }
  }
  goToday(): void {
    const t = new Date();
    this.currentYear.set(t.getFullYear());
    this.currentMonth.set(t.getMonth());
  }

  // ── Open task popup ───────────────────────────────────────────────
  openTaskModal(task: Task, event: Event): void {
    event.stopPropagation();
    this.modalTask.set(task);
    this.modalEdit.set({
      task:             task.task,
      status:           task.status,
      priority:         task.priority,
      dueDate:          task.dueDate,
      startDate:        task.startDate,
      estHrs:           task.estHrs,
      actHrs:           task.actHrs,
      rework:           task.rework,
      notes:            task.notes,
      link:             task.link || '',
      brief:            task.brief,
      internalCustomer: task.internalCustomer,
      fn:               task.fn,
      cat:              task.cat,
      sub:              task.sub,
      month:            task.month,
      year:             task.year,
    });
    this.modalOpen.set(true);
    this.selectedFiles.set([]);
    this.attachments.set([]);
    this.loadAttachments(task._id);
    document.body.style.overflow = 'hidden';
  }

  closeModal(): void {
    this.modalOpen.set(false);
    this.modalTask.set(null);
    this.selectedFiles.set([]);
    document.body.style.overflow = '';
  }

  // ── Save edits ────────────────────────────────────────────────────
  saveTask(): void {
    const task = this.modalTask();
    if (!task || this.modalSaving()) return;
    this.modalSaving.set(true);
    const { link, notes } = this.modalEdit();
    this.svc.updateTask(task._id, { link: link || '', notes: notes || '' }).subscribe({
      next: updated => {
        // Patch the task in whichever list it lives in
        const patch = (list: Task[]) =>
          list.map(t => t._id === updated._id ? { ...t, ...updated } : t);
        if (this.viewMode() === 'team') this.teamTasks.update(patch);
        else                            this.myTasks.update(patch);
        this.modalTask.set(updated);
        this.modalSaving.set(false);
        this.showToast('Task updated successfully.', 'success');
      },
      error: err => { this.showToast(err.message, 'error'); this.modalSaving.set(false); }
    });
  }

  // ── Attachments ───────────────────────────────────────────────────
  loadAttachments(taskId: string): void {
    this.attachmentsLoading.set(true);
    this.svc.getAttachments(taskId).subscribe({
      next:  list => { this.attachments.set(list); this.attachmentsLoading.set(false); },
      error: err  => { this.showToast(err.message, 'error'); this.attachmentsLoading.set(false); }
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.length) this.selectedFiles.set(Array.from(input.files));
    input.value = '';
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragOver.set(false);
    const files = event.dataTransfer?.files;
    if (files?.length) this.selectedFiles.set(Array.from(files));
  }

  onDragOver(event: DragEvent): void { event.preventDefault(); this.dragOver.set(true); }
  onDragLeave(): void { this.dragOver.set(false); }
  clearSelectedFile(): void { this.selectedFiles.set([]); }

  uploadFile(): void {
    const task = this.modalTask();
    const files = this.selectedFiles();
    if (!task || !files.length || this.uploadingFile()) return;
    this.uploadingFile.set(true);
    from(files).pipe(
      concatMap(file => this.svc.uploadAttachment(task._id, file)),
      toArray()
    ).subscribe({
      next: uploaded => {
        this.selectedFiles.set([]);
        this.uploadingFile.set(false);
        this.attachments.update(current => [...uploaded, ...current]);
        this.showToast(`${uploaded.length} file${uploaded.length === 1 ? '' : 's'} uploaded successfully.`, 'success');
      },
      error: err => { this.showToast(err.message, 'error'); this.uploadingFile.set(false); this.loadAttachments(task._id); }
    });
  }

  deleteAttachment(att: Attachment): void {
    const task = this.modalTask();
    if (!task) return;
    if (!confirm(`Delete "${att.filename}"?`)) return;
    this.svc.deleteAttachment(task._id, att._id).subscribe({
      next:  ()  => {
        this.attachments.update(list => list.filter(a => a._id !== att._id));
        this.showToast('Attachment deleted.', 'success');
      },
      error: err => this.showToast(err.message, 'error')
    });
  }

  downloadAttachmentFile(att: Attachment): void {
    const task = this.modalTask();
    if (!task) return;
    this.svc.downloadAttachment(task._id, att._id).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = att.filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      },
      error: err => this.showToast(err.message, 'error')
    });
  }

  // ── Display helpers ───────────────────────────────────────────────
  taskAssigneeName(t: Task): string { return assignedToName(t); }
  taskAssigneeRole(t: Task): string {
    const r = assignedToRole(t);
    return r.charAt(0).toUpperCase() + r.slice(1);
  }
  initials(name: string): string {
    return (name || '').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '—';
  }
  taskChipClass(status: string): string {
    const m: Record<string, string> = {
      'Completed': 'chip-done', 'In Progress': 'chip-wip',
      'In Review': 'chip-rev',  'Not Started': 'chip-ns'
    };
    return m[status] ?? 'chip-ns';
  }

  formatFileSize(bytes: number): string {
    if (!bytes) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  fileIcon(mimetype: string): string {
    if (!mimetype) return '📎';
    if (mimetype.startsWith('image/')) return '🖼️';
    if (mimetype === 'application/pdf') return '📄';
    if (mimetype.includes('word')) return '📝';
    if (mimetype.includes('excel') || mimetype.includes('spreadsheet')) return '📊';
    if (mimetype.includes('powerpoint') || mimetype.includes('presentation')) return '📑';
    if (mimetype.includes('zip')) return '🗜️';
    if (mimetype.startsWith('text/')) return '📃';
    return '📎';
  }

  uploaderName(att: Attachment): string {
    const u = att.uploadedBy;
    if (typeof u === 'object' && u?.name) return u.name;
    return att.uploadedByName || '—';
  }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
