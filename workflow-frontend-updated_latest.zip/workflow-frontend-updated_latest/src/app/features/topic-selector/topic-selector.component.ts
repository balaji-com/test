import { Component, signal } from '@angular/core';
import { NgIf, NgFor, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
interface Topic { title:string; angle:string; keywords:string[]; difficulty:'Easy'|'Medium'|'Hard'; }
@Component({ selector:'app-topic-selector', standalone:true, imports:[NgIf,NgFor,NgClass,FormsModule],
  templateUrl:'./topic-selector.component.html', styleUrl:'./topic-selector.component.css' })
export class TopicSelectorComponent {
  industry=signal(''); audience=signal(''); keywords=signal(''); tone=signal('');
  loading=signal(false); topics=signal<Topic[]>([]);
  TONES=['Professional','Conversational','Technical','Inspirational','Educational'];
  SAMPLE_TOPICS: Record<string,Topic[]> = {
    'technology': [
      {title:'5 Ways AI is Transforming Enterprise Workflows in 2026',angle:'Business impact',keywords:['AI','automation','enterprise','productivity'],difficulty:'Medium'},
      {title:'Cloud Security Best Practices Every CTO Must Know',angle:'Security guide',keywords:['cloud','security','CTO','best practices'],difficulty:'Hard'},
      {title:'From Zero to DevOps: A Beginner\'s Roadmap',angle:'Tutorial',keywords:['DevOps','beginners','CI/CD'],difficulty:'Easy'},
    ],
    'marketing': [
      {title:'How to Build a B2B Content Strategy That Actually Converts',angle:'Strategy guide',keywords:['B2B','content','strategy','leads'],difficulty:'Medium'},
      {title:'LinkedIn vs Instagram: Which Platform Drives More B2B Leads?',angle:'Comparison',keywords:['LinkedIn','Instagram','B2B','social media'],difficulty:'Easy'},
      {title:'The Complete SEO Checklist for SaaS Companies',angle:'Checklist',keywords:['SEO','SaaS','checklist'],difficulty:'Medium'},
    ],
    default: [
      {title:'10 Productivity Hacks for Remote Teams in 2026',angle:'Listicle',keywords:['productivity','remote work','teams'],difficulty:'Easy'},
      {title:'Why Storytelling is the Secret Weapon of Modern Brands',angle:'Opinion piece',keywords:['storytelling','branding','content'],difficulty:'Medium'},
      {title:'A Complete Guide to Building a Thought Leadership Strategy',angle:'How-to guide',keywords:['thought leadership','personal brand'],difficulty:'Hard'},
    ]
  };
  generate(){
    if(!this.industry()&&!this.keywords()) return;
    this.loading.set(true);
    setTimeout(()=>{
      const key = this.industry().toLowerCase();
      const pool = this.SAMPLE_TOPICS[key] ?? this.SAMPLE_TOPICS['default'];
      this.topics.set(pool);
      this.loading.set(false);
    },700);
  }
  diffClass(d:string){ return d==='Easy'?'diff-easy':d==='Medium'?'diff-med':'diff-hard'; }
}
