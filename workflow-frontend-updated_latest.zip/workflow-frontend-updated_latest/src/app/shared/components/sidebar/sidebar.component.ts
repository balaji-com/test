import { Component, inject, signal, computed } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NgIf } from '@angular/common';
import { AppStateService } from '../../../core/services/app-state.service';
import { PermissionsService, ModuleKey } from '../../../core/services/permissions.service';

interface NavItem {
  id: string; label: string; icon: string; route: string;
  moduleKey: ModuleKey;
  badgeKey?: 'myTasks' | 'reminders' | 'approvals';
}
interface NavGroup { label: string; id: string; items: NavItem[]; }

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, NgIf],
  template: `
    <nav class="sidebar" [class.collapsed]="collapsed()">

      <!-- Brand -->
      <div class="brand">
        <div class="brand-logo">HT</div>
        <span class="brand-name" *ngIf="!collapsed()">Hinduja Tech</span>
        <button class="collapse-btn" (click)="toggleCollapse()"
                [attr.aria-label]="collapsed() ? 'Expand' : 'Collapse'">
          {{ collapsed() ? '›' : '‹' }}
        </button>
      </div>

      <!-- Scrollable nav area -->
      <div class="nav-scroll">
        @for (group of visibleGroups(); track group.id) {
          <div class="nav-group-label" *ngIf="!collapsed()">{{ group.label }}</div>
          <div class="nav-group-divider" *ngIf="collapsed()"></div>
          @for (item of group.items; track item.id) {
            <a class="nav-item"
               [routerLink]="item.route"
               routerLinkActive="active"
               [class.viewer-only]="isViewerOnly(item.moduleKey)"
               [attr.title]="collapsed() ? item.label : (isViewerOnly(item.moduleKey) ? item.label + ' (view only)' : null)">
              <span class="nav-icon">{{ item.icon }}</span>
              <span class="nav-label" *ngIf="!collapsed()">
                {{ item.label }}
                <span class="viewer-badge" *ngIf="isViewerOnly(item.moduleKey)">👁</span>
              </span>
              @if (item.badgeKey && getBadge(item.badgeKey) > 0) {
                <span class="nav-badge">{{ getBadge(item.badgeKey) }}</span>
              }
            </a>
          }
        }
      </div>

      <!-- User pill pinned to bottom -->
      <div class="user-pill" *ngIf="state.currentUser() as user">
        <div class="user-avatar">{{ user.name[0] }}</div>
        <div class="user-info" *ngIf="!collapsed()">
          <div class="user-name">{{ user.name }}</div>
          <div class="user-role">{{ user.role }}</div>
        </div>
        <button class="logout-btn" *ngIf="!collapsed()" (click)="logout()" title="Logout">⏻</button>
      </div>
    </nav>
  `,
  styles: [`
    .sidebar {
      width: 230px;
      height: 100vh;
      background: var(--white);
      border-right: 1.5px solid var(--border);
      display: flex;
      flex-direction: column;
      transition: width 0.25s ease;
      overflow: hidden;
      flex-shrink: 0;
    }
    .sidebar.collapsed { width: 60px; }

    /* ── Brand ── */
    .brand {
      display: flex; align-items: center; gap: 10px;
      padding: 16px 14px 13px;
      border-bottom: 1.5px solid var(--border);
      flex-shrink: 0;
    }
    .brand-logo {
      width: 32px; height: 32px; background: var(--accent); color: #fff;
      border-radius: var(--radius-xs); display: flex; align-items: center;
      justify-content: center; font-weight: 800; font-size: 13px; flex-shrink: 0;
    }
    .brand-name { font-weight: 700; font-size: 14px; color: var(--text); white-space: nowrap; flex: 1; }
    .collapse-btn {
      background: none; border: none; cursor: pointer; color: var(--text3);
      font-size: 18px; padding: 2px 4px; line-height: 1; border-radius: 4px; flex-shrink: 0;
    }
    .collapse-btn:hover { background: var(--bg2); color: var(--text); }

    /* ── Scrollable nav ── */
    .nav-scroll {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      padding: 8px 0;
    }
    .nav-scroll::-webkit-scrollbar { width: 4px; }
    .nav-scroll::-webkit-scrollbar-track { background: transparent; }
    .nav-scroll::-webkit-scrollbar-thumb {
      background: var(--border2); border-radius: 3px;
    }
    .nav-scroll::-webkit-scrollbar-thumb:hover { background: var(--text3); }
    .nav-scroll { scrollbar-width: thin; scrollbar-color: var(--border2) transparent; }

    /* ── Group labels ── */
    .nav-group-label {
      font-size: 10px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.08em; color: var(--text3); padding: 14px 16px 4px;
    }
    .nav-group-divider { height: 1px; background: var(--border); margin: 8px 10px; }

    /* ── Nav items ── */
    .nav-item {
      display: flex; align-items: center; gap: 9px;
      padding: 8px 14px; border-radius: var(--radius-xs);
      margin: 1px 6px; color: var(--text2); text-decoration: none;
      font-size: 13.5px; font-weight: 500; cursor: pointer;
      transition: background 0.15s, color 0.15s; white-space: nowrap;
      overflow: hidden;
    }
    .nav-item:hover { background: var(--bg2); color: var(--text); }
    .nav-item.active { background: var(--accent-light); color: var(--accent); font-weight: 600; }
    .nav-item.viewer-only { opacity: .8; }
    .nav-icon { font-size: 16px; flex-shrink: 0; }
    .nav-label { flex: 1; overflow: hidden; text-overflow: ellipsis; display: flex; align-items: center; gap: 5px; }
    .viewer-badge { font-size: 9px; opacity: .65; flex-shrink: 0; }
    .nav-badge {
      background: var(--accent); color: #fff; font-size: 10px; font-weight: 700;
      border-radius: 20px; padding: 1px 6px; min-width: 18px; text-align: center; flex-shrink: 0;
    }

    /* ── User pill ── */
    .user-pill {
      display: flex; align-items: center; gap: 10px;
      padding: 12px 14px; border-top: 1.5px solid var(--border);
      flex-shrink: 0;
    }
    .user-avatar {
      width: 32px; height: 32px; background: var(--purple-light); color: var(--purple);
      border-radius: 50%; display: flex; align-items: center; justify-content: center;
      font-weight: 700; font-size: 13px; flex-shrink: 0;
    }
    .user-info { flex: 1; overflow: hidden; min-width: 0; }
    .user-name { font-size: 13px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .user-role { font-size: 11px; color: var(--text3); }
    .logout-btn {
      background: none; border: none; cursor: pointer;
      color: var(--text3); font-size: 16px; padding: 4px; border-radius: 4px; flex-shrink: 0;
    }
    .logout-btn:hover { background: var(--red-light); color: var(--red); }
  `]
})
export class SidebarComponent {
  readonly state  = inject(AppStateService);
  readonly perms  = inject(PermissionsService);
  readonly collapsed = signal(false);

  readonly navGroups: NavGroup[] = [
    {
      label: 'Workspace', id: 'workspace',
      items: [
        { id: 'nav-mytasks',   label: 'My Tasks',        icon: '✅', route: '/my-tasks',    moduleKey: 'my_tasks',   badgeKey: 'myTasks'   },
        { id: 'nav-allwork',   label: 'All Works',       icon: '📋', route: '/all-works',   moduleKey: 'all_works'                          },
        { id: 'nav-reminders', label: 'Reminders',       icon: '⏰', route: '/reminders',   moduleKey: 'reminders', badgeKey: 'reminders' },
        { id: 'nav-kanban',    label: 'Workflow Board',  icon: '🗂️', route: '/kanban',      moduleKey: 'kanban'                              },
        { id: 'nav-approvals', label: 'Approvals',       icon: '✍️', route: '/approvals',   moduleKey: 'approvals', badgeKey: 'approvals' },
      ],
    },
    {
      label: 'Calendar', id: 'calendar',
      items: [
        { id: 'nav-calendar', label: 'My Tasks Calendar', icon: '📅', route: '/calendar', moduleKey: 'calendar' },
        { id: 'nav-planner',  label: 'Planning Calendar', icon: '🗓️', route: '/planner',  moduleKey: 'planner'  },
      ],
    },
    {
      label: 'Analytics', id: 'analytics',
      items: [
        { id: 'nav-members',       label: 'Team Overview',   icon: '📊', route: '/team-overview',   moduleKey: 'team_overview'   },
        { id: 'nav-monthlyreport', label: 'Monthly Reports', icon: '📑', route: '/monthly-reports', moduleKey: 'monthly_reports' },
      ],
    },
    {
      label: 'SEO Tools', id: 'seo',
      items: [
        { id: 'nav-seochecker',    label: 'SEO Blog Checker',    icon: '🔍', route: '/seo-checker',    moduleKey: 'seo_checker'    },
        { id: 'nav-topicselector', label: 'Blog Topic Selector', icon: '📝', route: '/topic-selector', moduleKey: 'topic_selector' },
      ],
    },
    {
      label: 'Account & Team Settings', id: 'team',
      items: [
        { id: 'nav-seosettings', label: 'AI Configuration', icon: '🤖', route: '/ai-configuration', moduleKey: 'ai_configuration' },
        { id: 'nav-fields',      label: 'Customize Fields', icon: '⚙️', route: '/customize-fields', moduleKey: 'customize_fields' },
        { id: 'nav-admin',       label: 'Add Members',      icon: '👤', route: '/add-members',      moduleKey: 'add_members'      },
        { id: 'nav-auditlog',    label: 'Audit Log',        icon: '🕵️', route: '/audit-log',        moduleKey: 'audit_log'        },
        { id: 'nav-backup',      label: 'Backup & Restore', icon: '💾', route: '/backup',           moduleKey: 'backup'           },
        { id: 'nav-chgpwd',      label: 'Change Password',  icon: '🔑', route: '/change-password',  moduleKey: 'change_password'  },
      ],
    },
  ];

  // ── Only show groups/items the user has at least 'viewer' access to ──
  readonly visibleGroups = computed<NavGroup[]>(() => {
    return this.navGroups
      .map(group => ({
        ...group,
        items: group.items.filter(item => this.perms.canView(item.moduleKey)),
      }))
      .filter(group => group.items.length > 0);
  });

  getBadge(key: 'myTasks' | 'reminders' | 'approvals'): number {
    return this.state.badges()[key];
  }

  isViewerOnly(moduleKey: ModuleKey): boolean {
    return this.perms.isViewerOnly(moduleKey);
  }

  toggleCollapse(): void { this.collapsed.update(v => !v); }
  logout(): void { this.state.logout(); }
}
