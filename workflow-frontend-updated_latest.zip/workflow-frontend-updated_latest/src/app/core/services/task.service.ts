import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { Task, TaskStatus, TaskPriority, Attachment } from '../models/task.model';

export interface TaskQuery {
  status?: TaskStatus;
  priority?: TaskPriority;
  assignedTo?: string;
  month?: string;
  year?: string;
  search?: string;
  page?: number;
  limit?: number;
  reminderType?: 'overdue' | 'today' | 'tomorrow' | 'approval' | 'all';
}

export interface TaskListResponse {
  status: string;
  total: number;
  page: number;
  limit: number;
  pages: number;
  data: Task[];
}

export interface TaskSingleResponse {
  status: string;
  data: Task;
}

// ── All Works ────────────────────────────────────────────────────
export interface AllWorksQuery {
  search?: string;
  status?: TaskStatus;
  priority?: TaskPriority;
  assignedTo?: string;   // member _id
  month?: string;
  year?: string;
}

export interface AllWorksGroup {
  taskName: string;
  count: number;
  months: string[];
  assignees: string[];
  items: Task[];
}

export interface AllWorksResponse {
  status: string;
  total: number;
  groupCount: number;
  data: AllWorksGroup[];
}

export interface AllWorksMember {
  _id: string;
  name: string;
}

export type ExportFormat = 'csv' | 'excel' | 'pdf';

@Injectable({ providedIn: 'root' })
export class TaskService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/tasks`;

  // ── GET /api/tasks/task-names — distinct task names for combo field ─
  getTaskNames(): Observable<string[]> {
    return this.http.get<{ status: string; total: number; data: string[] }>(
      `${this.base}/task-names`
    ).pipe(map(r => r.data), catchError(this.handleError));
  }

  // ── GET /api/tasks  (returns Task[] — used by My Tasks, Kanban, Calendar) ──
  getTasks(query: TaskQuery = {}): Observable<Task[]> {
    const params = this.buildParams(query);
    return this.http.get<TaskListResponse>(this.base, { params }).pipe(
      map(res => res.data),
      catchError(this.handleError)
    );
  }

  // ── GET /api/tasks  (returns full paginated envelope — used by Reminders) ──
  getTasksPaginated(query: TaskQuery = {}): Observable<TaskListResponse> {
    const params = this.buildParams(query);
    return this.http.get<TaskListResponse>(this.base, { params }).pipe(
      catchError(this.handleError)
    );
  }

  // ── GET /api/tasks/:id ──────────────────────────────────────────
  getTask(id: string): Observable<Task> {
    return this.http.get<TaskSingleResponse>(`${this.base}/${id}`).pipe(
      map(res => res.data),
      catchError(this.handleError)
    );
  }

  // ── POST /api/tasks ─────────────────────────────────────────────
  createTask(payload: Partial<Task>): Observable<Task> {
    return this.http.post<TaskSingleResponse>(this.base, payload).pipe(
      map(res => res.data),
      catchError(this.handleError)
    );
  }

  // ── PATCH /api/tasks/:id ────────────────────────────────────────
  updateTask(id: string, payload: Partial<Task>): Observable<Task> {
    return this.http.patch<TaskSingleResponse>(`${this.base}/${id}`, payload).pipe(
      map(res => res.data),
      catchError(this.handleError)
    );
  }

  // ── DELETE /api/tasks/:id ───────────────────────────────────────
  deleteTask(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  // ── PATCH /api/tasks/bulk ───────────────────────────────────────
  bulkAction(ids: string[], action: 'complete' | 'delete'): Observable<{ message: string }> {
    return this.http.patch<{ status: string; message: string }>(`${this.base}/bulk`, { ids, action }).pipe(
      map(res => ({ message: res.message })),
      catchError(this.handleError)
    );
  }

  // ════════════════════════════════════════════════════════════════
  // ALL WORKS — team-wide search/filter/list grouped by task name
  // ════════════════════════════════════════════════════════════════

  // ── GET /api/tasks/all-works ─────────────────────────────────────
  getAllWorks(query: AllWorksQuery = {}): Observable<AllWorksGroup[]> {
    const params = this.buildParams(query);
    return this.http.get<AllWorksResponse>(`${this.base}/all-works`, { params }).pipe(
      map(res => res.data),
      catchError(this.handleError)
    );
  }

  // ── GET /api/tasks/all-works/members ─────────────────────────────
  getAllWorksMembers(): Observable<AllWorksMember[]> {
    return this.http.get<{ status: string; data: AllWorksMember[] }>(`${this.base}/all-works/members`).pipe(
      map(res => res.data),
      catchError(this.handleError)
    );
  }

  // ── Export download (CSV / Excel / PDF) ──────────────────────────
  // Triggers a browser download by fetching the file as a Blob and
  // programmatically clicking a temporary <a> link.
  exportAllWorks(format: ExportFormat, query: AllWorksQuery = {}): Observable<Blob> {
    const endpointMap: Record<ExportFormat, string> = {
      csv:   'export/csv',
      excel: 'export/excel',
      pdf:   'export/pdf',
    };
    const params = this.buildParams(query);
    return this.http.get(`${this.base}/all-works/${endpointMap[format]}`, {
      params, responseType: 'blob',
    }).pipe(
      catchError(this.handleError)
    );
  }

  /** Downloads the blob with a sensible filename and extension for the given format. */
  downloadBlob(blob: Blob, format: ExportFormat): void {
    const extMap: Record<ExportFormat, string> = { csv: 'csv', excel: 'xlsx', pdf: 'pdf' };
    const filename = `all-works-${new Date().toISOString().slice(0, 10)}.${extMap[format]}`;
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  // ════════════════════════════════════════════════════════════════
  // ATTACHMENTS — per-task file upload / list / delete
  // ════════════════════════════════════════════════════════════════

  getAttachments(taskId: string): Observable<Attachment[]> {
    return this.http.get<{ status: string; total: number; data: Attachment[] }>(
      `${this.base}/${taskId}/attachments`
    ).pipe(map(r => r.data), catchError(this.handleError));
  }

  uploadAttachment(taskId: string, file: File): Observable<Attachment> {
    const form = new FormData();
    form.append('file', file);
    return this.http.post<{ status: string; data: Attachment }>(
      `${this.base}/${taskId}/attachments`, form
    ).pipe(map(r => r.data), catchError(this.handleError));
  }

  deleteAttachment(taskId: string, attachmentId: string): Observable<void> {
    return this.http.delete<void>(
      `${this.base}/${taskId}/attachments/${attachmentId}`
    ).pipe(catchError(this.handleError));
  }

  downloadAttachment(taskId: string, attachmentId: string): Observable<Blob> {
    return this.http.get(
      `${this.base}/${taskId}/attachments/${attachmentId}/download`,
      { responseType: 'blob' }
    ).pipe(catchError(this.handleError));
  }

  // ── Helper: build HttpParams, skipping empty values ───────────────
  private buildParams(query: Record<string, any>): HttpParams {
    let params = new HttpParams();
    Object.entries(query).forEach(([key, val]) => {
      if (val !== undefined && val !== null && val !== '') {
        params = params.set(key, String(val));
      }
    });
    return params;
  }

  // ── Error handler ────────────────────────────────────────────────
  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg =
      err.error?.message ||
      err.error?.error   ||
      (err.status === 0 ? 'Cannot reach the server. Check your connection.' : `Server error ${err.status}`);
    return throwError(() => new Error(msg));
  }
}
