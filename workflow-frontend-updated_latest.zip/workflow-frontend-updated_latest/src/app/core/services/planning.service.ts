import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { PlanningEntry, PlanningImportResponse } from '../models/planning-entry.model';

@Injectable({ providedIn: 'root' })
export class PlanningService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/planning`;

  getEntries(month: number, year: number): Observable<PlanningEntry[]> {
    const params = new HttpParams().set('month', String(month)).set('year', String(year));
    return this.http.get<{ status: string; total: number; data: PlanningEntry[] }>(
      this.base,
      { params }
    ).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  importWorkbook(file: File): Observable<PlanningImportResponse> {
    const form = new FormData();
    form.append('file', file);
    return this.http.post<PlanningImportResponse>(`${this.base}/import`, form).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const message = err.error?.message ||
      err.error?.error ||
      (err.status === 0 ? 'Cannot reach the server. Check your connection.' : `Server error ${err.status}`);
    return throwError(() => new Error(message));
  }
}
