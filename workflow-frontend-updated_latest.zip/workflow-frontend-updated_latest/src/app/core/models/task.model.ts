export type TaskStatus = 'Not Started' | 'In Progress' | 'In Review' | 'Completed';
export type TaskPriority = 'High' | 'Medium' | 'Low';

// Backend populates `assignedTo` with this shape via .populate('assignedTo', 'name email color role').
// When creating/updating a task, send just the member's _id as a string instead —
// Mongoose accepts a bare ObjectId string for write operations.
export interface AssignedToRef {
  _id: string;
  name: string;
  email?: string;
  color?: string;
  role?: 'admin' | 'member' | 'viewer';
}

export interface Task {
  _id: string;              // MongoDB document id (primary key)
  id?: number;               // legacy/local-only fallback id, optional
  task: string;
  assignedTo: AssignedToRef | string;  // populated object when read, plain _id string when writing
  assignedToName?: string;             // denormalised fallback name kept in sync by the backend
  status: TaskStatus;
  priority: TaskPriority;
  fn: string;
  cat: string;
  sub: string;
  month: string;
  year: string;
  dueDate: string;
  startDate: string;
  estHrs: string;
  actHrs: string;
  rework: number;
  notes: string;
  link?: string;
  brief: string;
  internalCustomer: string;
  approvalStatus: string;
  approvalTo: string;
  approvalComment: string;
  reviewers: string[];
  recurEnabled?: boolean;
  recurFreq?: string;
  recurEnd?: string;
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Attachment {
  _id: string;
  taskId: string;
  filename: string;
  storedName: string;
  mimetype: string;
  size: number;
  uploadedBy: { _id: string; name: string; email?: string; color?: string; role?: string } | string;
  uploadedByName: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Employee {
  name: string;
  role: string;
  isAdmin: boolean;
  color: string;
  password?: string;
  sections?: string[];
}

export interface ApprovalRequest {
  id: number;
  taskId: number;
  taskName: string;
  requestedBy: string;
  requestedTo: string;
  message: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';
  createdAt: string;
  resolvedAt?: string;
  comment?: string;
}

export interface AuditEntry {
  id: number;
  ts: string;
  action: string;
  user: string;
  taskId: number;
  taskName: string;
  assignedTo: string;
  extra: string;
  changes?: Record<string, [string, string]>;
  _undone?: boolean;
}

// ── Helpers for the dual-shape `Task.assignedTo` field ─────────────
// Read paths get a populated AssignedToRef object; write paths (forms)
// just store the plain _id string. These helpers work with either.
export function assignedToId(task: Pick<Task, 'assignedTo'>): string {
  const a = task.assignedTo;
  return typeof a === 'string' ? a : (a?._id ?? '');
}

export function assignedToName(task: Pick<Task, 'assignedTo' | 'assignedToName'>): string {
  const a = task.assignedTo;
  if (typeof a === 'object' && a?.name) return a.name;
  return task.assignedToName || '—';
}

/** Returns the assignee's access role ('admin' | 'member' | 'viewer') when available, else 'member' as a sane default. */
export function assignedToRole(task: Pick<Task, 'assignedTo'>): string {
  const a = task.assignedTo;
  if (typeof a === 'object' && a?.role) return a.role;
  return 'member';
}
