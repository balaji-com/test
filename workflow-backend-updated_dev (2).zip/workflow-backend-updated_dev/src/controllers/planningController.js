const { randomUUID } = require('crypto');
const fs = require('fs/promises');
const path = require('path');
const ExcelJS = require('exceljs');
const PlanningEntry = require('../models/PlanningEntry');
const PlanningUpload = require('../models/PlanningUpload');
const { AppError } = require('../middleware/errorHandler');

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const MAX_ROWS = 5000;
const MAX_COLUMNS = 20;
const UPLOAD_DIRECTORY = path.resolve(__dirname, '../../uploads/planning');

const EXPECTED_HEADERS = [
  [1, 'week'],
  [2, 'date of publication'],
  [4, 'offerings'],
  [5, 'segments / industries'],
  [6, 'format'],
  [7, 'content objectives'],
  [8, 'content pillars'],
  [9, 'target audience'],
  [10, 'channel'],
  [11, 'kpi'],
  [12, 'assigned to'],
  [13, 'due date for submission'],
  [14, 'actual date of submission'],
  [15, 'reviewer'],
  [16, 'due date for reviewing'],
  [17, 'actual date of reviewing'],
  [18, 'depository link'],
  [19, 'posted link'],
  [20, 'status'],
];

const textAt = (row, column) => String(row.getCell(column).text || '').trim();

const dateAt = (cell) => {
  const value = cell.value;
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }

  const text = String(cell.text || value || '').trim();
  const iso = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(text);
  const slash = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text);
  const parts = iso
    ? [Number(iso[1]), Number(iso[2]), Number(iso[3])]
    : slash
      ? [Number(slash[3]), Number(slash[1]), Number(slash[2])]
      : null;
  if (!parts) return '';

  const [year, month, day] = parts;
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    return '';
  }
  return date.toISOString().slice(0, 10);
};

const readEntry = (row, createdBy, importBatchId, sourceFileName) => ({
  week: Number(textAt(row, 1)) || undefined,
  publicationDate: dateAt(row.getCell(2)),
  contentTitle: textAt(row, 3),
  offerings: textAt(row, 4),
  segmentsIndustries: textAt(row, 5),
  format: textAt(row, 6),
  contentObjectives: textAt(row, 7),
  contentPillars: textAt(row, 8),
  targetAudience: textAt(row, 9),
  channel: textAt(row, 10),
  kpi: textAt(row, 11),
  assignedTo: textAt(row, 12),
  submissionDueDate: dateAt(row.getCell(13)),
  submissionActualDate: dateAt(row.getCell(14)),
  reviewer: textAt(row, 15),
  reviewDueDate: dateAt(row.getCell(16)),
  reviewActualDate: dateAt(row.getCell(17)),
  depositoryLink: textAt(row, 18),
  postedLink: textAt(row, 19),
  status: textAt(row, 20),
  createdBy,
  importBatchId,
  sourceFileName,
});

const hasRowData = (row) =>
  Array.from({ length: MAX_COLUMNS }, (_value, index) => row.getCell(index + 1))
    .some((cell) => cell.value !== null && cell.value !== undefined && cell.text.trim() !== '');

exports.listPlanningEntries = async (req, res, next) => {
  try {
    const { year, month } = req.query;
    const filter = {};
    if (!req.user.isAdmin) filter.createdBy = req.user._id;

    if (year !== undefined || month !== undefined) {
      const yearNumber = Number(year);
      const monthNumber = Number(month);
      if (!Number.isInteger(yearNumber) || yearNumber < 2000 || yearNumber > 2100
        || !Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12) {
        return next(new AppError('Provide a valid month (1-12) and year (2000-2100).', 400));
      }

      const lastDay = new Date(Date.UTC(yearNumber, monthNumber, 0)).getUTCDate();
      const monthText = String(monthNumber).padStart(2, '0');
      filter.publicationDate = {
        $gte: `${yearNumber}-${monthText}-01`,
        $lte: `${yearNumber}-${monthText}-${String(lastDay).padStart(2, '0')}`,
      };
    }

    const entries = await PlanningEntry.find(filter)
      .sort({ publicationDate: 1, contentTitle: 1 })
      .limit(5000);

    res.status(200).json({ status: 'success', total: entries.length, data: entries });
  } catch (err) { next(err); }
};

exports.getPlanningUploadStatus = async (req, res, next) => {
  try {
    const { year, month } = req.query;
    const period = validatePeriod(month, year);
    const upload = await PlanningUpload.findOne({
      createdBy: req.user._id,
      month: period.month,
      year: period.year,
    }).select('isUploaded fileName importedCount uploadedAt');

    res.status(200).json({
      status: 'success',
      data: upload || { isUploaded: false, fileName: '', importedCount: 0, uploadedAt: null },
    });
  } catch (err) { next(err); }
};

exports.updatePlanningEntry = async (req, res, next) => {
  try {
    const { year, month } = req.query;
    const period = validatePeriod(month, year);
    const stringFields = [
      'publicationDate', 'contentTitle', 'offerings', 'segmentsIndustries', 'format',
      'contentObjectives', 'contentPillars', 'targetAudience', 'channel', 'kpi',
      'assignedTo', 'submissionDueDate', 'submissionActualDate', 'reviewer',
      'reviewDueDate', 'reviewActualDate', 'depositoryLink', 'postedLink', 'status',
    ];
    const updates = {};
    for (const field of stringFields) {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) {
        if (typeof req.body[field] !== 'string') {
          return next(new AppError(`${field} must be text.`, 400));
        }
        updates[field] = req.body[field].trim();
      }
    }
    if (Object.prototype.hasOwnProperty.call(req.body, 'week')) {
      if (req.body.week === '' || req.body.week === null) {
        updates.week = undefined;
      } else if (!Number.isInteger(Number(req.body.week)) || Number(req.body.week) < 1) {
        return next(new AppError('Week must be a positive whole number.', 400));
      } else {
        updates.week = Number(req.body.week);
      }
    }
    if (!Object.keys(updates).length) return next(new AppError('Provide at least one planning field to update.', 400));

    if (updates.publicationDate !== undefined) {
      if (!isValidDate(updates.publicationDate)) {
        return next(new AppError('Publication date must be a valid YYYY-MM-DD date.', 400));
      }
      const [entryYear, entryMonth] = updates.publicationDate.split('-').map(Number);
      if (entryYear !== period.year || entryMonth !== period.month) {
        return next(new AppError('Publication date must remain within the selected month.', 400));
      }
    }
    for (const field of ['submissionDueDate', 'submissionActualDate', 'reviewDueDate', 'reviewActualDate']) {
      if (updates[field] && !isValidDate(updates[field])) {
        return next(new AppError(`${field} must be a valid YYYY-MM-DD date or blank.`, 400));
      }
    }
    if (updates.contentTitle === '') return next(new AppError('Content title is required.', 400));

    const filter = { _id: req.params.id };
    if (!req.user.isAdmin) filter.createdBy = req.user._id;
    filter.publicationDate = {
      $gte: `${period.year}-${String(period.month).padStart(2, '0')}-01`,
      $lte: `${period.year}-${String(period.month).padStart(2, '0')}-${String(new Date(Date.UTC(period.year, period.month, 0)).getUTCDate()).padStart(2, '0')}`,
    };
    const update = { $set: updates };
    if (updates.week === undefined) delete update.$set.week;
    if (Object.prototype.hasOwnProperty.call(req.body, 'week') && updates.week === undefined) {
      update.$unset = { week: 1 };
    }
    const entry = await PlanningEntry.findOneAndUpdate(filter, update, {
      new: true,
      runValidators: true,
    });
    if (!entry) return next(new AppError('Planning entry not found or you do not have permission to edit it.', 404));
    res.status(200).json({ status: 'success', data: entry });
  } catch (err) { next(err); }
};

exports.importPlanningWorkbook = async (req, res, next) => {
  let storedPath;
  let importBatchId;
  try {
    if (!req.file) return next(new AppError('Choose an .xlsx workbook to import.', 400));
    if (req.file.size > MAX_FILE_SIZE) {
      return next(new AppError('The workbook must be 10 MB or smaller.', 413));
    }
    const period = validatePeriod(req.body.month, req.body.year);
    const existingUpload = await PlanningUpload.findOne({
      createdBy: req.user._id,
      month: period.month,
      year: period.year,
      isUploaded: true,
    });
    if (existingUpload) {
      return next(new AppError('Delete this month’s current workbook before uploading a replacement.', 409));
    }

    const workbook = new ExcelJS.Workbook();
    try {
      await workbook.xlsx.load(req.file.buffer);
    } catch (_err) {
      return next(new AppError('The uploaded file is not a readable .xlsx workbook.', 400));
    }

    const sheet = workbook.worksheets[0];
    if (!sheet) return next(new AppError('The workbook does not contain a worksheet.', 400));
    if (sheet.rowCount > MAX_ROWS + 1 || sheet.columnCount > MAX_COLUMNS) {
      return next(new AppError(`The worksheet must contain no more than ${MAX_ROWS} data rows and ${MAX_COLUMNS} columns.`, 400));
    }

    const mismatchedHeader = EXPECTED_HEADERS.find(([column, expected]) =>
      textAt(sheet.getRow(1), column).toLowerCase() !== expected
    );
    if (mismatchedHeader) {
      return next(new AppError(
        `Unsupported workbook format: column ${mismatchedHeader[0]} must be "${mismatchedHeader[1]}".`,
        400
      ));
    }

    importBatchId = randomUUID();
    const sourceFileName = req.file.originalname.slice(0, 255);
    const entries = [];
    const invalidRows = [];

    for (let rowNumber = 2; rowNumber <= sheet.rowCount; rowNumber++) {
      const row = sheet.getRow(rowNumber);
      if (!hasRowData(row)) continue;

      const entry = readEntry(row, req.user._id, importBatchId, sourceFileName);
      if (!entry.publicationDate || !entry.contentTitle) {
        invalidRows.push(rowNumber);
        continue;
      }
      entries.push(entry);
    }

    if (invalidRows.length) {
      return next(new AppError(
        `Each non-empty row needs a valid publication date and content title. Check row${invalidRows.length === 1 ? '' : 's'} ${invalidRows.join(', ')}.`,
        400
      ));
    }
    if (!entries.length) return next(new AppError('No dated content rows were found in the workbook.', 400));
    const datesOutsidePeriod = entries.some((entry) => {
      const [entryYear, entryMonth] = entry.publicationDate.split('-').map(Number);
      return entryYear !== period.year || entryMonth !== period.month;
    });
    if (datesOutsidePeriod) {
      return next(new AppError('All publication dates in the workbook must belong to the selected month.', 400));
    }

    await fs.mkdir(UPLOAD_DIRECTORY, { recursive: true });
    const storedName = `${randomUUID()}.xlsx`;
    storedPath = path.join(UPLOAD_DIRECTORY, storedName);
    await fs.writeFile(storedPath, req.file.buffer, { flag: 'wx' });
    const createdEntries = await PlanningEntry.insertMany(entries, { ordered: true });
    await PlanningUpload.findOneAndUpdate(
      { createdBy: req.user._id, month: period.month, year: period.year },
      {
        $set: {
          isUploaded: true,
          fileName: sourceFileName,
          storedName,
          importBatchId,
          importedCount: createdEntries.length,
          uploadedAt: new Date(),
        },
      },
      { upsert: true, new: true, runValidators: true, setDefaultsOnInsert: true }
    );
    res.status(201).json({
      status: 'success',
      importedCount: createdEntries.length,
      importBatchId,
      upload: {
        isUploaded: true,
        fileName: sourceFileName,
        importedCount: createdEntries.length,
      },
      data: createdEntries,
    });
  } catch (err) {
    if (importBatchId) {
      await PlanningEntry.deleteMany({ importBatchId });
    }
    if (storedPath) {
      await fs.unlink(storedPath).catch((cleanupError) => {
        if (cleanupError.code !== 'ENOENT') console.error('Failed to remove incomplete planning upload:', cleanupError);
      });
    }
    next(err);
  }
};

exports.deletePlanningUpload = async (req, res, next) => {
  try {
    const period = validatePeriod(req.query.month, req.query.year);
    const uploads = await PlanningUpload.find({
      month: period.month,
      year: period.year,
      isUploaded: true,
    });
    const storedNames = uploads.map((upload) => upload.storedName).filter(Boolean);
    for (const storedName of storedNames) {
      const safeName = path.basename(storedName);
      if (safeName !== storedName || !/^[\w-]+\.xlsx$/i.test(safeName)) {
        return next(new AppError('A stored planning workbook path is invalid.', 500));
      }
    }
    await Promise.all(storedNames.map(async (storedName) => {
      try {
        await fs.unlink(path.join(UPLOAD_DIRECTORY, storedName));
      } catch (err) {
        if (err.code !== 'ENOENT') throw err;
      }
    }));
    const monthPrefix = `${period.year}-${String(period.month).padStart(2, '0')}-`;
    await PlanningEntry.deleteMany({
      publicationDate: { $gte: `${monthPrefix}01`, $lte: `${monthPrefix}${String(new Date(Date.UTC(period.year, period.month, 0)).getUTCDate()).padStart(2, '0')}` },
    });
    await PlanningUpload.updateMany(
      { month: period.month, year: period.year },
      { $set: { isUploaded: false, storedName: '', importBatchId: '', importedCount: 0 } }
    );

    res.status(200).json({
      status: 'success',
      message: 'All planning entries and uploaded workbooks for the selected month were deleted.',
      data: { isUploaded: false, fileName: '', importedCount: 0 },
    });
  } catch (err) { next(err); }
};

function validatePeriod(month, year) {
  const monthNumber = Number(month);
  const yearNumber = Number(year);
  if (!Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12
    || !Number.isInteger(yearNumber) || yearNumber < 2000 || yearNumber > 2100) {
    throw new AppError('Provide a valid month (1-12) and year (2000-2100).', 400);
  }

  function isValidDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year
      && date.getUTCMonth() === month - 1
      && date.getUTCDate() === day;
  }
  return { month: monthNumber, year: yearNumber };
}
