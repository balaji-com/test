const TaskDropdownOptions = require('../models/TaskDropdownOptions');
const { AppError } = require('../middleware/errorHandler');

const OPTION_FIELDS = ['functions', 'briefingsheets', 'months', 'years', 'statuses'];
const MAX_OPTIONS = 100;
const MAX_OPTION_LENGTH = 100;

exports.getOptions = async (_req, res, next) => {
  try {
    const data = await TaskDropdownOptions.getConfiguredOptions();
    res.status(200).json({ status: 'success', data });
  } catch (err) { next(err); }
};

exports.saveOptions = async (req, res, next) => {
  try {
    const input = req.body;
    if (!input || typeof input !== 'object' || Array.isArray(input)) {
      return next(new AppError('Provide dropdown option settings.', 400));
    }

    const data = {};
    for (const field of OPTION_FIELDS) {
      const values = normalizeOptionList(input[field], field);
      if (!values) return next(new AppError(`${field} must be a non-empty array of unique values.`, 400));
      data[field] = values;
    }

    if (!input.categories || typeof input.categories !== 'object' || Array.isArray(input.categories)) {
      return next(new AppError('categories must map category names to sub-category lists.', 400));
    }
    const rawCategories = Object.entries(input.categories);
    const categoryNames = rawCategories.map(([name]) => name.trim());
    if (!categoryNames.length || categoryNames.length > MAX_OPTIONS
      || categoryNames.some((name) => !name || name.length > MAX_OPTION_LENGTH)
      || new Set(categoryNames.map((name) => name.toLowerCase())).size !== categoryNames.length) {
      return next(new AppError('Add at least one unique category.', 400));
    }
    data.categories = {};
    for (const [rawName, rawValues] of rawCategories) {
      const category = rawName.trim();
      const values = normalizeOptionList(rawValues, `sub-categories for ${category}`, true);
      if (!values) return next(new AppError(`Sub-categories for ${category} must be a list of unique values.`, 400));
      data.categories[category] = values;
    }

    const options = await TaskDropdownOptions.findOneAndUpdate(
      { key: 'task-dropdown-options' },
      { $set: { ...data, updatedBy: req.user._id } },
      { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
    );
    res.status(200).json({
      status: 'success',
      data: {
        functions: options.functions,
        briefingsheets: options.briefingsheets,
        categories: options.categories,
        months: options.months,
        years: options.years,
        statuses: options.statuses,
      },
    });
  } catch (err) { next(err); }
};

function normalizeOptionList(value, field, allowEmpty = false) {
  if (!Array.isArray(value) || value.length > MAX_OPTIONS || (!allowEmpty && value.length === 0)) return null;
  const values = value.map((item) => typeof item === 'string' ? item.trim() : '');
  if (values.some((item) => !item || item.length > MAX_OPTION_LENGTH)) return null;
  if (new Set(values.map((item) => item.toLowerCase())).size !== values.length) return null;
  return values;
}
