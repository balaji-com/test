const mongoose = require('mongoose');

const DEFAULTS = {
  functions: ['Social Media', 'Internal Communication', 'External Communication', 'Events'],
  briefingsheets: ['Given', 'NA', 'Not Given'],
  categories: {
    Content: ['Blog', 'Article', 'Whitepaper', 'Case Study', 'Brochure'],
    Design: ['Banner', 'Infographic', 'Flyer', 'Poster', 'Emailer'],
    Posting: ['LinkedIn', 'Twitter/X', 'Instagram', 'Facebook', 'YouTube'],
    Video: ['Reel', 'Short', 'Corporate Video', 'Webinar'],
    Newsletter: ['Internal', 'External', 'Product Update'],
    Copy: ['Event Page', 'Landing Page', 'Ad Copy', 'Script'],
    PR: ['Press Release', 'Media Note', 'Interview'],
    Campaign: ['Email Campaign', 'Social Campaign', 'SEO Campaign'],
    Reporting: ['Monthly Report', 'Weekly Report', 'Analytics'],
    Other: [],
  },
  months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  years: ['2024', '2025', '2026', '2027'],
  statuses: ['Not Started', 'In Progress', 'In Review', 'Completed'],
};

const taskDropdownOptionsSchema = new mongoose.Schema(
  {
    key: { type: String, default: 'task-dropdown-options', unique: true },
    functions: { type: [String], required: true },
    briefingsheets: { type: [String], required: true },
    categories: { type: mongoose.Schema.Types.Mixed, required: true },
    months: { type: [String], required: true },
    years: { type: [String], required: true },
    statuses: { type: [String], required: true },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true, minimize: false }
);

taskDropdownOptionsSchema.statics.getConfiguredOptions = async function () {
  const options = await this.findOne({ key: 'task-dropdown-options' }).lean();
  if (!options) return DEFAULTS;
  return {
    functions: options.functions,
    briefingsheets: options.briefingsheets,
    categories: options.categories,
    months: options.months,
    years: options.years,
    statuses: options.statuses,
  };
};

taskDropdownOptionsSchema.statics.defaults = DEFAULTS;

module.exports = mongoose.model('TaskDropdownOptions', taskDropdownOptionsSchema);
