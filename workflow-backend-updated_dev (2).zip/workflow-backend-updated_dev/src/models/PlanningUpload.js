const mongoose = require('mongoose');

const planningUploadSchema = new mongoose.Schema(
  {
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    month: { type: Number, required: true, min: 1, max: 12 },
    year: { type: Number, required: true, min: 2000, max: 2100 },
    isUploaded: { type: Boolean, default: false },
    fileName: { type: String, trim: true, maxlength: 255, default: '' },
    storedName: { type: String, trim: true, default: '' },
    importBatchId: { type: String, trim: true, default: '' },
    importedCount: { type: Number, min: 0, default: 0 },
    uploadedAt: { type: Date },
  },
  { timestamps: true }
);

planningUploadSchema.index({ createdBy: 1, year: 1, month: 1 }, { unique: true });

module.exports = mongoose.model('PlanningUpload', planningUploadSchema);
