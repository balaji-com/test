const router = require('express').Router();
const controller = require('../controllers/taskDropdownOptionsController');
const { protect, requirePermission, requireAnyPermission } = require('../middleware/auth');

router.use(protect);
router.get('/', requireAnyPermission(['my_tasks', 'customize_fields'], 'viewer'), controller.getOptions);
router.put('/', requirePermission('customize_fields', 'editor'), controller.saveOptions);

module.exports = router;
