const router = require('express').Router();
const multer = require('multer');
const planningCtrl = require('../controllers/planningController');
const { protect, requirePermission } = require('../middleware/auth');
const { AppError } = require('../middleware/errorHandler');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const isXlsx = /\.xlsx$/i.test(file.originalname)
      && [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/octet-stream',
      ].includes(file.mimetype);
    cb(isXlsx ? null : new AppError('Only .xlsx workbooks can be imported.', 400), isXlsx);
  },
});

router.use(protect);
router.get('/upload-status', requirePermission('planner', 'viewer'), planningCtrl.getPlanningUploadStatus);
router.delete('/upload', requirePermission('planner', 'editor'), planningCtrl.deletePlanningUpload);
router.put('/:id', requirePermission('planner', 'editor'), planningCtrl.updatePlanningEntry);
router.get('/', requirePermission('planner', 'viewer'), planningCtrl.listPlanningEntries);
router.post('/import', requirePermission('planner', 'editor'), upload.single('file'), planningCtrl.importPlanningWorkbook);

module.exports = router;
