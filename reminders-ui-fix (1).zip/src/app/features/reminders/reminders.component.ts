import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskService, TaskListResponse, TaskQuery } from '../../core/services/task.service';
import { UserService, Member } from '../../core/services/user.service';
import { AuthService } from '../../core/services/auth.service';
import { PermissionsService } from '../../core/services/permissions.service';
import { ReminderCountService } from '../../core/services/reminder-count.service';
import { Task, assignedToName, assignedToId } from '../../core/models/task.model';

type ReminderTab = 'all' | 'overdue' | 'today' | 'tomorrow' | 'approval';
interface Toast { msg: string; type: 'success' | 'error'; }

const PAGE_SIZE = 10;
const MONTHS = ['January','February','March','April','May','June','July','August',
                'September','October','November','December'];
const YEARS  = ['2024','2025','2026','2027'];
const STATUSES  = ['Not Started','In Progress','In Review','Completed'] as const;
const PRIORITIES = ['High','Medium','Low'] as const;
const BRIEF_OPTIONS = ['Given','NA','Not Given'];
const CATEGORIES: Record<string,string[]> = {
  'Content':    ['Blog','Article','Whitepaper','Case Study','Brochure'],
  'Design':     ['Banner','Infographic','Flyer','Poster','Emailer'],
  'Posting':    ['LinkedIn','Twitter/X','Instagram','Facebook','YouTube'],
  'Video':      ['Reel','Short','Corporate Video','Webinar'],
  'Newsletter': ['Internal','External','Product Update'],
  'Copy':       ['Event Page','Landing Page','Ad Copy','Script'],
  'PR':         ['Press Release','Media Note','Interview'],
  'Campaign':   ['Email Campaign','Social Campaign','SEO Campaign'],
  'Reporting':  ['Monthly Report','Weekly Report','Analytics'],
  'Other':      [],
};

@Component({
  selector: 'app-reminders',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule],
  templateUrl: './reminders.component.html',
  styleUrl: './reminders.component.css'
})
export class RemindersComponent implements OnInit {
  private readonly svc          = inject(TaskService);
  private readonly userSvc      = inject(UserService);
  private readonly countSvc     = inject(ReminderCountService);
  readonly auth                  = inject(AuthService);
  readonly perms                 = inject(PermissionsService);

  readonly canEdit = computed(() => this.perms.canEdit('my_tasks'));
  readonly isAdmin = computed(() => this.auth.isAdmin());

  // ── Lookup data ──────────────────────────────────────────────────
  members = signal<Member[]>([]);

  // ── Date constants ───────────────────────────────────────────────
  readonly today    = new Date().toISOString().slice(0, 10);
  get tomorrow()    { const d = new Date(); d.setDate(d.getDate()+1); return d.toISOString().slice(0,10); }

  // ── Filters ──────────────────────────────────────────────────────
  activeTab     = signal<ReminderTab>('all');
  filterMember  = signal('');
  filterMonth   = signal('');
  filterYear    = signal('');
  filterSearch  = signal('');

  // ── Data & pagination ────────────────────────────────────────────
  tasks        = signal<Task[]>([]);
  totalRecords = signal(0);
  totalPages   = signal(0);
  currentPage  = signal(1);
  loading      = signal(true);

  // ── Sidebar counts (always full, no pagination) ──────────────────
  counts = signal({ overdue: 0, today: 0, tomorrow: 0, approval: 0, all: 0 });

  // ── Task detail modal ────────────────────────────────────────────
  modalOpen   = signal(false);
  modalTask   = signal<Task | null>(null);
  modalEdit   = signal<Partial<Task>>({});
  modalSaving = signal(false);
  formError   = signal('');

  // Dropdown data for edit form
  readonly MONTHS           = MONTHS;
  readonly YEARS            = YEARS;
  readonly STATUSES         = STATUSES;
  readonly PRIORITIES       = PRIORITIES;
  readonly BRIEF_OPTIONS    = BRIEF_OPTIONS;
  readonly FUNCTIONS        = ['Social Media','Internal Communication','External Communication','Events'];
  readonly CATEGORIES_KEYS  = Object.keys(CATEGORIES);
  readonly subCats          = computed(() => CATEGORIES[this.modalEdit().cat || ''] || []);
  readonly approverList     = computed(() => {
    const me = this.auth.currentUser()?._id;
    return this.members().filter(m => m.isActive && m._id !== me);
  });

  // ── Pagination page numbers ───────────────────────────────────────
  readonly pageNumbers = computed(() => {
    const total = this.totalPages(), cur = this.currentPage();
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: (number | '...')[] = [1];
    if (cur > 3) pages.push('...');
    for (let p = Math.max(2, cur-1); p <= Math.min(total-1, cur+1); p++) pages.push(p);
    if (cur < total - 2) pages.push('...');
    if (total > 1) pages.push(total);
    return pages;
  });

  readonly startRecord = computed(() =>
    this.totalRecords() === 0 ? 0 : (this.currentPage()-1)*PAGE_SIZE + 1
  );
  readonly endRecord = computed(() =>
    Math.min(this.currentPage()*PAGE_SIZE, this.totalRecords())
  );

  // ── Toast ─────────────────────────────────────────────────────────
  toast = signal<Toast | null>(null);
  private toastTimer: ReturnType<typeof setTimeout> | null = null;

  private searchDebounce: ReturnType<typeof setTimeout> | null = null;

  // ── Tab config ────────────────────────────────────────────────────
  readonly TABS: { key: ReminderTab; icon: string; label: string; countKey: keyof ReturnType<typeof this.counts> }[] = [
    { key: 'all',      icon: '🔔', label: 'All',            countKey: 'all'      },
    { key: 'overdue',  icon: '⚠️',  label: 'Overdue',        countKey: 'overdue'  },
    { key: 'today',    icon: '⏰', label: 'Due Today',       countKey: 'today'    },
    { key: 'tomorrow', icon: '📅', label: 'Due Tomorrow',    countKey: 'tomorrow' },
    { key: 'approval', icon: '✍️',  label: 'Pending Approval',countKey: 'approval' },
  ];

  ngOnInit(): void {
    this.userSvc.getUsers().subscribe({ next: m => this.members.set(m), error: () => {} });
    this.loadCounts();
    this.loadTasks();
  }

  // ── Load sidebar counts (fetch all, no pagination) ───────────────
  loadCounts(): void {
    this.svc.getTasksPaginated({
      assignedTo: this.isAdmin() ? (this.filterMember() || undefined) : undefined,
      month:      this.filterMonth()  || undefined,
      year:       this.filterYear()   || undefined,
      search:     this.filterSearch() || undefined,
      limit:      1000,
      page:       1,
    }).subscribe({
      next: (res: TaskListResponse) => {
        const all  = res.data;
        const today = this.today;
        const tom   = this.tomorrow;
        this.counts.set({
          overdue:  all.filter(t => t.dueDate && t.dueDate < today && t.status !== 'Completed').length,
          today:    all.filter(t => t.dueDate === today && t.status !== 'Completed').length,
          tomorrow: all.filter(t => t.dueDate === tom   && t.status !== 'Completed').length,
          approval: all.filter(t => t.approvalStatus === 'Pending').length,
          all:      all.filter(t =>
            t.status !== 'Completed' && (
              (t.dueDate && (t.dueDate < today || t.dueDate === today || t.dueDate === tom)) ||
              t.approvalStatus === 'Pending'
            )
          ).length,
        });
        // Push to shared service so topbar bell can read it
        this.countSvc.update(this.counts());
      },
      error: () => {}
    });
  }

  // ── Load paginated task list ──────────────────────────────────────
  loadTasks(): void {
    this.loading.set(true);
    this.svc.getTasksPaginated(this.buildQuery()).subscribe({
      next: (res: TaskListResponse) => {
        this.tasks.set(res.data);
        this.totalRecords.set(res.total);
        this.totalPages.set(res.pages || 1);
        this.loading.set(false);
      },
      error: (err: Error) => {
        this.showToast(err.message, 'error');
        this.loading.set(false);
      }
    });
  }

  private buildQuery(): TaskQuery {
    const q: TaskQuery = {
      page:   this.currentPage(),
      limit:  PAGE_SIZE,
      month:  this.filterMonth()  || undefined,
      year:   this.filterYear()   || undefined,
      search: this.filterSearch() || undefined,
    };

    if (this.isAdmin() && this.filterMember()) q.assignedTo = this.filterMember();

    const tab = this.activeTab();
    if (tab !== 'all') q.reminderType = tab;

    return q;
  }

  // ── Filter change handlers ────────────────────────────────────────
  setTab(tab: ReminderTab): void {
    this.activeTab.set(tab);
    this.currentPage.set(1);
    this.loadTasks();
  }

  onSearchInput(value: string): void {
    this.filterSearch.set(value);
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.searchDebounce = setTimeout(() => { this.currentPage.set(1); this.loadTasks(); this.loadCounts(); }, 350);
  }

  onFilterChange(): void { this.currentPage.set(1); this.loadTasks(); this.loadCounts(); }

  // ── Pagination ────────────────────────────────────────────────────
  goToPage(p: number | '...'): void {
    if (p === '...' || p === this.currentPage()) return;
    this.currentPage.set(p as number);
    this.loadTasks();
  }
  prevPage(): void { if (this.currentPage() > 1) { this.currentPage.update(p => p-1); this.loadTasks(); } }
  nextPage(): void { if (this.currentPage() < this.totalPages()) { this.currentPage.update(p => p+1); this.loadTasks(); } }

  // ── Task detail modal ─────────────────────────────────────────────
  openModal(task: Task): void {
    this.modalTask.set(task);
    this.modalEdit.set({
      task:             task.task,
      status:           task.status,
      priority:         task.priority,
      dueDate:          task.dueDate,
      startDate:        task.startDate,
      estHrs:           task.estHrs,
      actHrs:           task.actHrs,
      rework:           task.rework,
      notes:            task.notes,
      brief:            task.brief,
      fn:               task.fn,
      cat:              task.cat,
      sub:              task.sub,
      month:            task.month,
      year:             task.year,
      internalCustomer: task.internalCustomer,
      approvalStatus:   task.approvalStatus,
      approvalTo:       task.approvalTo,
      approvalComment:  task.approvalComment,
    });
    this.formError.set('');
    this.modalSaving.set(false);
    this.modalOpen.set(true);
    document.body.style.overflow = 'hidden';
  }

  closeModal(): void {
    this.modalOpen.set(false);
    this.modalTask.set(null);
    document.body.style.overflow = '';
  }

  patchEdit(field: keyof Task, value: any): void {
    this.modalEdit.update(e => ({ ...e, [field]: value }));
    if (field === 'cat') this.modalEdit.update(e => ({ ...e, sub: '' }));
  }

  saveTask(): void {
    const task = this.modalTask();
    if (!task || this.modalSaving()) return;
    this.formError.set('');
    this.modalSaving.set(true);
    this.svc.updateTask(task._id, this.modalEdit()).subscribe({
      next: updated => {
        this.tasks.update(ts => ts.map(t => t._id === updated._id ? updated : t));
        this.modalTask.set(updated);
        this.modalSaving.set(false);
        this.showToast('Task updated successfully.', 'success');
        this.loadCounts();
      },
      error: (err: Error) => {
        this.formError.set(err.message);
        this.modalSaving.set(false);
      }
    });
  }

  // ── Display helpers ───────────────────────────────────────────────
  taskName(t: Task): string  { return assignedToName(t); }

  tagClass(t: Task): string {
    if (t.approvalStatus === 'Pending') return 'tag-approval';
    if (t.dueDate < this.today)         return 'tag-overdue';
    if (t.dueDate === this.today)       return 'tag-today';
    if (t.dueDate === this.tomorrow)    return 'tag-tomorrow';
    return '';
  }

  tagLabel(t: Task): string {
    if (t.approvalStatus === 'Pending') return '✍️ Approval';
    if (t.dueDate < this.today)         return '⚠ Overdue';
    if (t.dueDate === this.today)       return '⏰ Due Today';
    if (t.dueDate === this.tomorrow)    return '📅 Tomorrow';
    return '';
  }

  iconBg(t: Task): string {
    if (t.approvalStatus === 'Pending') return '#f0ebff';
    if (t.dueDate < this.today)         return '#fff0f0';
    if (t.dueDate === this.today)       return '#fff3dc';
    if (t.dueDate === this.tomorrow)    return '#eef6ff';
    return '#f5f5f5';
  }

  iconEmoji(t: Task): string {
    if (t.approvalStatus === 'Pending') return '✍️';
    if (t.dueDate < this.today)         return '⚠️';
    if (t.dueDate === this.today)       return '⏰';
    return '📅';
  }

  statusChipClass(status: string): string {
    const m: Record<string,string> = {
      'Completed':'chip-done','In Progress':'chip-wip',
      'In Review':'chip-rev','Not Started':'chip-ns'
    };
    return m[status] ?? 'chip-ns';
  }

  priorityClass(p: string): string {
    return p === 'High' ? 'pri-high' : p === 'Medium' ? 'pri-medium' : 'pri-low';
  }

  initials(t: Task): string {
    return assignedToName(t).split(' ').map((w: string) => w[0]).join('').slice(0,2).toUpperCase() || '—';
  }

  private showToast(msg: string, type: 'success'|'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
