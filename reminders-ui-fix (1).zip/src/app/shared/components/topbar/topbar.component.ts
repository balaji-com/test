import { Component, inject } from '@angular/core';
import { NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ReminderCountService } from '../../../core/services/reminder-count.service';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [NgIf],
  template: `
    <header class="topbar">
      <div class="topbar-left">
        <div class="topbar-breadcrumb">
          <span class="topbar-app">Hinduja Tech</span>
          <span class="topbar-sep">›</span>
          <span class="topbar-page">{{ currentPage }}</span>
        </div>
      </div>
      <div class="topbar-right">
        <button class="icon-btn bell-btn" (click)="goToReminders()" title="Reminders">
          🔔
          <span class="bell-badge" *ngIf="bellCount() > 0">
            {{ bellCount() > 99 ? '99+' : bellCount() }}
          </span>
        </button>
        <div class="topbar-divider"></div>
        <div class="topbar-user" *ngIf="auth.currentUser() as user">
          <div class="topbar-avatar" [style.background]="user.color || 'var(--accent)'">
            {{ user.name[0].toUpperCase() }}
          </div>
          <div class="topbar-user-info">
            <div class="topbar-name">{{ user.name }}</div>
            <div class="topbar-role">{{ user.role }}</div>
          </div>
          <button class="topbar-logout" (click)="logout()" title="Sign out">⏻</button>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .topbar {
      height: 56px;
      background: var(--white);
      border-bottom: 1.5px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px 0 24px;
      flex-shrink: 0;
      position: relative;
      z-index: 50;
    }

    .topbar-breadcrumb { display: flex; align-items: center; gap: 8px; }
    .topbar-app  { font-size: 12px; font-weight: 600; color: var(--text3); }
    .topbar-sep  { font-size: 14px; color: var(--border2); }
    .topbar-page { font-size: 14px; font-weight: 700; color: var(--text); }

    .topbar-right { display: flex; align-items: center; gap: 4px; }

    .icon-btn {
      position: relative;
      background: none; border: none; cursor: pointer;
      font-size: 17px; padding: 7px 8px;
      border-radius: var(--radius-xs); color: var(--text2);
      transition: background 0.13s;
      line-height: 1;
    }
    .icon-btn:hover { background: var(--bg2); }

    /* ── Bell badge — shows the count number ── */
    .bell-btn { font-size: 18px; }
    .bell-badge {
      position: absolute;
      top: 2px; right: 2px;
      min-width: 16px; height: 16px;
      padding: 0 4px;
      background: var(--red);
      color: #fff;
      border-radius: 10px;
      font-size: 9px;
      font-weight: 800;
      font-family: var(--font);
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1.5px solid var(--white);
      line-height: 1;
    }

    .topbar-divider { width: 1px; height: 24px; background: var(--border); margin: 0 8px; }

    .topbar-user  { display: flex; align-items: center; gap: 10px; }
    .topbar-avatar {
      width: 32px; height: 32px; border-radius: 50%;
      background: var(--accent); color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 13px; flex-shrink: 0;
    }
    .topbar-user-info { display: flex; flex-direction: column; }
    .topbar-name  { font-size: 13px; font-weight: 700; color: var(--text); line-height: 1.2; }
    .topbar-role  { font-size: 10.5px; color: var(--text3); font-weight: 500; line-height: 1.2; }

    .topbar-logout {
      background: none; border: none; cursor: pointer;
      color: var(--text3); font-size: 16px; padding: 5px;
      border-radius: var(--radius-xs); transition: all .13s;
    }
    .topbar-logout:hover { background: var(--red-light); color: var(--red); }
  `]
})
export class TopbarComponent {
  readonly auth        = inject(AuthService);
  readonly countSvc    = inject(ReminderCountService);
  private readonly router = inject(Router);

  readonly bellCount = this.countSvc.bellCount;

  get currentPage(): string {
    const url = this.router.url.split('?')[0].replace('/', '').replace(/-/g, ' ');
    return url ? url.replace(/\b\w/g, c => c.toUpperCase()) : 'Dashboard';
  }

  goToReminders(): void { this.router.navigate(['/reminders']); }

  logout(): void {
    this.auth.logout();
  }
}

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [NgIf],
  template: `
    <header class="topbar">
      <div class="topbar-left">
        <div class="topbar-breadcrumb">
          <span class="topbar-app">Hinduja Tech</span>
          <span class="topbar-sep">›</span>
          <span class="topbar-page">{{ currentPage }}</span>
        </div>
      </div>
      <div class="topbar-right">
        <button class="icon-btn" (click)="state.toggleDarkMode()"
                [title]="state.darkMode() ? 'Switch to Light Mode' : 'Switch to Dark Mode'">
          {{ state.darkMode() ? '☀️' : '🌙' }}
        </button>
        <button class="icon-btn" title="Notifications">
          🔔
          <span class="notif-dot" *ngIf="state.badges().approvals > 0 || state.badges().reminders > 0"></span>
        </button>
        <div class="topbar-divider"></div>
        <div class="topbar-user" *ngIf="state.currentUser() as user">
          <div class="topbar-avatar">{{ user.name[0].toUpperCase() }}</div>
          <div class="topbar-user-info">
            <div class="topbar-name">{{ user.name }}</div>
            <div class="topbar-role">{{ user.role }}</div>
          </div>
          <button class="topbar-logout" (click)="logout()" title="Sign out">⏻</button>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .topbar {
      height: 56px;
      background: var(--white);
      border-bottom: 1.5px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px 0 24px;
      flex-shrink: 0;
      position: relative;
      z-index: 50;
    }

    /* ── Left: breadcrumb ── */
    .topbar-breadcrumb { display: flex; align-items: center; gap: 8px; }
    .topbar-app { font-size: 12px; font-weight: 600; color: var(--text3); }
    .topbar-sep { font-size: 14px; color: var(--border2); }
    .topbar-page { font-size: 14px; font-weight: 700; color: var(--text); }

    /* ── Right: actions ── */
    .topbar-right { display: flex; align-items: center; gap: 4px; }

    .icon-btn {
      position: relative;
      background: none; border: none; cursor: pointer;
      font-size: 17px; padding: 7px 8px;
      border-radius: var(--radius-xs); color: var(--text2);
      transition: background 0.13s;
      line-height: 1;
    }
    .icon-btn:hover { background: var(--bg2); }

    .notif-dot {
      position: absolute; top: 5px; right: 5px;
      width: 7px; height: 7px; border-radius: 50%;
      background: var(--red); border: 1.5px solid var(--white);
    }

    .topbar-divider { width: 1px; height: 24px; background: var(--border); margin: 0 8px; }

    .topbar-user { display: flex; align-items: center; gap: 10px; }
    .topbar-avatar {
      width: 32px; height: 32px; border-radius: 50%;
      background: var(--accent); color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 13px; flex-shrink: 0;
    }
    .topbar-user-info { display: flex; flex-direction: column; }
    .topbar-name  { font-size: 13px; font-weight: 700; color: var(--text); line-height: 1.2; }
    .topbar-role  { font-size: 10.5px; color: var(--text3); font-weight: 500; line-height: 1.2; }

    .topbar-logout {
      background: none; border: none; cursor: pointer;
      color: var(--text3); font-size: 16px; padding: 5px;
      border-radius: var(--radius-xs); transition: all .13s;
    }
    .topbar-logout:hover { background: var(--red-light); color: var(--red); }
  `]
})
export class TopbarComponent {
  readonly state = inject(AppStateService);
  private readonly router = inject(Router);

  get currentPage(): string {
    const url = this.router.url.split('?')[0].replace('/', '').replace(/-/g, ' ');
    return url ? url.replace(/\b\w/g, c => c.toUpperCase()) : 'Dashboard';
  }

  logout(): void {
    this.state.logout();
    this.router.navigate(['/login']);
  }
}
