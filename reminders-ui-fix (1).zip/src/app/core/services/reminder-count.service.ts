import { Injectable, signal, computed } from '@angular/core';

/**
 * Lightweight singleton that holds the live reminder counts.
 * The RemindersComponent populates it after each API load.
 * The TopbarComponent reads it to show the bell badge.
 */
@Injectable({ providedIn: 'root' })
export class ReminderCountService {
  readonly counts = signal({
    overdue:  0,
    today:    0,
    tomorrow: 0,
    approval: 0,
    all:      0,
  });

  /** Total urgent items shown on the bell (overdue + today + pending approval). */
  readonly bellCount = computed(() => {
    const c = this.counts();
    return c.overdue + c.today + c.approval;
  });

  update(counts: { overdue: number; today: number; tomorrow: number; approval: number; all: number }): void {
    this.counts.set(counts);
  }
}
