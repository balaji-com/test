# AI Support Assistant — Full Stack Chapters 1–7

## Run backend
```bash
cd backend
npm install
npm run dev
```

## Run frontend
In a second terminal:
```bash
cd frontend
npm install
npm start
```

Open http://localhost:4200

Ask: `What is Node.js?`

The response streams from Angular -> SSE -> Express -> async generator -> Angular.

The AI is simulated for now. Chapter 8 will replace it with a real LLM SDK.
