import {Router} from "express";
import {sseChatController} from "../controllers/sse.controller.js";
const router=Router();
router.get("/chat/stream",sseChatController);
export default router;