import {Request,Response} from "express";
import {generateAIResponse} from "../services/ai.service.js";
export async function chatController(req:Request,res:Response):Promise<void>{
  const {question}=req.body;
  if(typeof question!=="string"||!question.trim()){res.status(400).json({success:false,message:"question is required"});return;}
  res.setHeader("Content-Type","text/plain; charset=utf-8");
  res.setHeader("Transfer-Encoding","chunked");
  res.setHeader("Cache-Control","no-cache");
  try{for await(const chunk of generateAIResponse(question))res.write(chunk);res.end();}
  catch(error){console.error(error);res.end();}
}