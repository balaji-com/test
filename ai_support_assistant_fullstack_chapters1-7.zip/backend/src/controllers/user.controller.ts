import {Request,Response} from "express";
import {createUser} from "../services/user.service.js";
export function createUserController(req:Request,res:Response):void {
  const {name,email,age}=req.body;
  if(typeof name!=="string"||typeof email!=="string"||typeof age!=="number"){
    res.status(400).json({success:false,message:"name, email and age are required with valid types"}); return;
  }
  res.status(201).json({success:true,data:createUser(name,email,age)});
}