import {Request,Response} from "express";
import {generateAIResponse} from "../services/ai.service.js";
export async function sseChatController(req:Request,res:Response):Promise<void>{
  const question=String(req.query.question??"");
  if(!question.trim()){res.status(400).json({success:false,message:"question is required"});return;}
  res.setHeader("Content-Type","text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control","no-cache, no-transform");
  res.setHeader("Connection","keep-alive");
  res.flushHeaders();
  try{
    for await(const chunk of generateAIResponse(question)){
      res.write("event: token\n");
      res.write(`data: ${chunk.replace(/\r?\n/g,"\\n")}\n\n`);
    }
    res.write("event: done\n");
    res.write("data: [DONE]\n\n");
    res.end();
  }catch(error){console.error(error);res.write("event: error\n");res.write("data: Streaming failed\n\n");res.end();}
}