import express from "express";
import cors from "cors";
import userRoutes from "./routes/user.routes.js";
import chatRoutes from "./routes/chat.routes.js";
import sseRoutes from "./routes/sse.routes.js";

const app=express();
app.use(cors({origin:"http://localhost:4200"}));
app.use(express.json());
app.use("/api",userRoutes);
app.use("/api",chatRoutes);
app.use("/api",sseRoutes);

app.get("/api/health",(_req,res)=>res.json({success:true,message:"AI Support Assistant API is running"}));

const PORT=3000;
app.listen(PORT,()=>console.log(`Backend running on http://localhost:${PORT}`));