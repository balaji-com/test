function delay(ms:number):Promise<void>{return new Promise(r=>setTimeout(r,ms));}
export async function* generateAIResponse(question:string):AsyncGenerator<string>{
  const chunks=[
    `You asked: ${question}. `,
    "This is a simulated AI response. ",
    "The backend is streaming ",
    "the answer chunk by chunk. ",
    "Next we will connect a real LLM."
  ];
  for(const chunk of chunks){await delay(500);yield chunk;}
}