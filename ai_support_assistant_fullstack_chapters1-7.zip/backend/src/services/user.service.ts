import { User } from "../types/user.js";
export function createUser(name:string,email:string,age:number):User {
  return {id:crypto.randomUUID(),name,email,age};
}