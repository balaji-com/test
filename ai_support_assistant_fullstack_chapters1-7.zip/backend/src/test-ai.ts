import {generateAIResponse} from "./services/ai.service.js";
async function main(){for await(const chunk of generateAIResponse("What is Node.js?"))process.stdout.write(chunk);console.log("\nStream complete.");}
main().catch(console.error);