import {Component} from "@angular/core";
import {FormsModule} from "@angular/forms";
import {AiService} from "../../services/ai.service";
@Component({selector:"app-chat",standalone:true,imports:[FormsModule],templateUrl:"./chat.component.html",styleUrl:"./chat.component.css"})
export class ChatComponent{
 question=""; answer=""; loading=false; errorMessage="";
 private eventSource?:EventSource;
 constructor(private readonly aiService:AiService){}
 sendMessage():void{
  const question=this.question.trim();
  if(!question||this.loading)return;
  this.answer="";this.errorMessage="";this.loading=true;this.question="";
  this.eventSource=this.aiService.streamChat(question,
   token=>this.answer+=token,
   ()=>{this.loading=false;this.eventSource=undefined;},
   ()=>{this.errorMessage="Unable to stream the AI response.";this.loading=false;this.eventSource?.close();this.eventSource=undefined;}
  );
 }
 stopStreaming():void{this.eventSource?.close();this.eventSource=undefined;this.loading=false;}
}