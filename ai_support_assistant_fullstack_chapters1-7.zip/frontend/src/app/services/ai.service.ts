import {Injectable} from "@angular/core";
@Injectable({providedIn:"root"})
export class AiService{
 private readonly baseUrl="http://localhost:3000/api";
 streamChat(question:string,onToken:(token:string)=>void,onDone:()=>void,onError:(e:Event)=>void):EventSource{
  const source=new EventSource(`${this.baseUrl}/chat/stream?question=${encodeURIComponent(question)}`);
  source.addEventListener("token",(e:Event)=>onToken((e as MessageEvent).data));
  source.addEventListener("done",()=>{onDone();source.close();});
  source.addEventListener("error",(e:Event)=>{onError(e);source.close();});
  return source;
 }
}