# Hinduja Tech — Project Tracker (Angular 19)

Converted from a monolithic single-file HTML app to a fully structured **Angular 19** application using **Signals** and **lazy-loaded standalone components**.

---

## Quick Start

```bash
npm install
ng serve
# Open http://localhost:4200
```

---

## Architecture Overview

```
src/
└── app/
    ├── app.component.ts          # Root shell (just <router-outlet>)
    ├── app.config.ts             # provideRouter + PreloadAllModules
    ├── app.routes.ts             # All routes with loadComponent() lazy loading
    │
    ├── core/
    │   ├── services/
    │   │   └── app-state.service.ts   # ★ Signal-based global state
    │   └── guards/
    │       └── auth.guard.ts          # CanActivateFn using isAuthenticated signal
    │
    ├── shared/
    │   └── components/
    │       ├── layout/               # App shell (sidebar + topbar + router-outlet)
    │       ├── sidebar/              # ★ Signal-driven nav with live badges
    │       └── topbar/               # Dark-mode toggle, user info
    │
    └── features/                     # ★ Every item = its own lazy chunk
        ├── login/
        ├── my-tasks/
        ├── all-works/
        ├── reminders/
        ├── kanban/
        ├── approvals/
        ├── calendar/
        ├── planner/
        ├── team-overview/
        ├── monthly-reports/
        ├── seo-checker/
        ├── topic-selector/
        ├── ai-configuration/
        ├── customize-fields/
        ├── add-members/
        ├── audit-log/
        ├── backup/
        └── change-password/
```

---

## Signals Used

| Signal / Computed | Where | Purpose |
|---|---|---|
| `currentUser = signal<User \| null>()` | AppStateService | Logged-in user; drives auth guard |
| `isAuthenticated = computed(...)` | AppStateService | Derived boolean for guard |
| `darkMode = signal<boolean>()` | AppStateService | Toggles `.dark-mode` on `<html>` via `effect()` |
| `badges = signal<NavBadges>()` | AppStateService | Live badge counts in sidebar |
| `tasks = signal<Task[]>()` | AppStateService | Task list; mutated with `.update()` |
| `myTasks = computed(...)` | AppStateService | Filtered by current user |
| `pendingApprovals = computed(...)` | AppStateService | Tasks with status `review` |
| `overdueReminders = computed(...)` | AppStateService | Tasks past due date |
| `collapsed = signal<boolean>()` | SidebarComponent | Sidebar expand/collapse |
| `error = signal<string>()` | LoginComponent | Login error message |
| `loading = signal<boolean>()` | LoginComponent | Login in-progress state |

---

## Lazy Loading

Every navigation item maps to its own **`loadComponent()`** route. Angular only downloads the JS chunk for a view when the user first visits it:

```ts
// app.routes.ts
{
  path: 'kanban',
  loadComponent: () =>
    import('./features/kanban/kanban.component')
      .then(m => m.KanbanComponent),
  title: 'Workflow Board',
}
```

`PreloadAllModules` is also enabled so chunks are silently prefetched in the background after the initial load.

---

## Navigation Map

| Section | Route | Component |
|---|---|---|
| **Workspace** | `/my-tasks` | MyTasksComponent |
| | `/all-works` | AllWorksComponent |
| | `/reminders` | RemindersComponent |
| | `/kanban` | KanbanComponent |
| | `/approvals` | ApprovalsComponent |
| **Calendar** | `/calendar` | CalendarComponent |
| | `/planner` | PlannerComponent |
| **Analytics** | `/team-overview` | TeamOverviewComponent |
| | `/monthly-reports` | MonthlyReportsComponent |
| **SEO Tools** | `/seo-checker` | SeoCheckerComponent |
| | `/topic-selector` | TopicSelectorComponent |
| **Settings** | `/ai-configuration` | AiConfigurationComponent |
| | `/customize-fields` | CustomizeFieldsComponent |
| | `/add-members` | AddMembersComponent |
| | `/audit-log` | AuditLogComponent |
| | `/backup` | BackupComponent |
| | `/change-password` | ChangePasswordComponent |

The **Planning Calendar** accepts `.xlsx` content-plan workbooks from the Import Excel button. Imported content is saved through the backend planning API and displayed on its publication date.

---

## Next Steps

Each feature component in `src/app/features/` is a scaffold — replace the placeholder template with the full UI from `Workflow.html`:

- **`my-tasks`** → task table with filters, bulk actions, drag-to-reorder  
- **`kanban`** → Kanban board columns  
- **`approvals`** → approval request cards  
- **`seo-checker`** → SEO analysis form  
- etc.

The `AppStateService` signals (`tasks`, `currentUser`, `badges`) are already wired — inject and consume them directly in each feature.
