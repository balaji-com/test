import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskService, AllWorksGroup, AllWorksMember, ExportFormat } from '../../core/services/task.service';
import { Task, TaskStatus, TaskPriority, assignedToName } from '../../core/models/task.model';

interface Toast { msg: string; type: 'success' | 'error'; }

// ── Category → Sub-category map (mirrors My Tasks for a consistent edit form) ──
const CATEGORIES: Record<string, string[]> = {
  'Content':    ['Blog', 'Article', 'Whitepaper', 'Case Study', 'Brochure'],
  'Design':     ['Banner', 'Infographic', 'Flyer', 'Poster', 'Emailer'],
  'Posting':    ['LinkedIn', 'Twitter/X', 'Instagram', 'Facebook', 'YouTube'],
  'Video':      ['Reel', 'Short', 'Corporate Video', 'Webinar'],
  'Newsletter': ['Internal', 'External', 'Product Update'],
  'Copy':       ['Event Page', 'Landing Page', 'Ad Copy', 'Script'],
  'PR':         ['Press Release', 'Media Note', 'Interview'],
  'Campaign':   ['Email Campaign', 'Social Campaign', 'SEO Campaign'],
  'Reporting':  ['Monthly Report', 'Weekly Report', 'Analytics'],
  'Other':      [],
};

@Component({
  selector: 'app-all-works',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule],
  templateUrl: './all-works.component.html',
  styleUrl: './all-works.component.css'
})
export class AllWorksComponent implements OnInit {
  private readonly svc     = inject(TaskService);

  // ── Data ─────────────────────────────────────────────────────────
  groups    = signal<AllWorksGroup[]>([]);
  members   = signal<AllWorksMember[]>([]);   // for the filter dropdown (all assignees with tasks)
  total     = signal(0);
  loading   = signal(true);
  exporting = signal<ExportFormat | null>(null);
  toast     = signal<Toast | null>(null);

  // ── Filters (all wired to backend — no client-side filtering) ────
  filterQ        = signal('');
  filterMember   = signal('');   // member _id
  filterStatus   = signal('');
  filterPriority = signal('');
  filterMonth    = signal('');
  filterYear     = signal('');

  expandedGroups = signal<Set<string>>(new Set());

  // ── Edit modal state ───────────────────────────────────────────────
  showModal = signal(false);
  form      = signal<Partial<Task>>({});

  readonly MONTHS = ['January','February','March','April','May','June',
                     'July','August','September','October','November','December'];
  readonly YEARS  = ['2024','2025','2026','2027'];
  readonly STATUSES: TaskStatus[]     = ['Not Started', 'In Progress', 'In Review', 'Completed'];
  readonly PRIORITIES: TaskPriority[] = ['High', 'Medium', 'Low'];
  readonly FUNCTIONS = ['Social Media', 'Internal Communication', 'External Communication', 'Events'];
  readonly CATEGORIES_KEYS = Object.keys(CATEGORIES);
  readonly BRIEF_OPTIONS = ['Given', 'NA', 'Not Given'];

  // Sub-categories for the currently selected category in the edit form
  readonly subCats = computed(() => CATEGORIES[this.form().cat || ''] || []);

  private searchDebounce: ReturnType<typeof setTimeout> | null = null;

  ngOnInit(): void {
    this.loadMembers();
    this.loadGroups();
  }

  // ── GET /api/tasks/all-works/members ──────────────────────────────
  loadMembers(): void {
    this.svc.getAllWorksMembers().subscribe({
      next:  (members: AllWorksMember[]) => this.members.set(members),
      error: () => {} // non-critical — the filter dropdown just stays empty
    });
  }

  // ── GET /api/tasks/all-works ──────────────────────────────────────
  loadGroups(): void {
    this.loading.set(true);
    this.svc.getAllWorks({
      search:     this.filterQ()       || undefined,
      assignedTo: this.filterMember()  || undefined,
      status:     (this.filterStatus()   as any) || undefined,
      priority:   (this.filterPriority() as any) || undefined,
      month:      this.filterMonth()   || undefined,
      year:       this.filterYear()    || undefined,
    }).subscribe({
      next: (groups: AllWorksGroup[]) => {
        this.groups.set(groups);
        this.total.set(groups.reduce((a, g) => a + g.count, 0));
        this.loading.set(false);
        // Auto-expand the first few groups so the page isn't empty-looking
        if (this.expandedGroups().size === 0 && groups.length > 0) {
          this.expandedGroups.set(new Set(groups.slice(0, 3).map(g => g.taskName)));
        }
      },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  // ── Debounced search — re-query the server, don't filter client-side ──
  onSearchInput(value: string): void {
    this.filterQ.set(value);
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.searchDebounce = setTimeout(() => this.loadGroups(), 350);
  }

  onFilterChange(): void {
    this.loadGroups();
  }

  // ── Group expand/collapse ─────────────────────────────────────────
  toggleGroup(taskName: string): void {
    this.expandedGroups.update(s => {
      const next = new Set(s);
      next.has(taskName) ? next.delete(taskName) : next.add(taskName);
      return next;
    });
  }
  isExpanded(taskName: string): boolean { return this.expandedGroups().has(taskName); }

  expandAll(): void { this.expandedGroups.set(new Set(this.groups().map(g => g.taskName))); }
  collapseAll(): void { this.expandedGroups.set(new Set()); }

  // ── Export → GET /api/tasks/all-works/export/{csv|excel|pdf} ─────
  exportAs(format: ExportFormat): void {
    this.exporting.set(format);
    this.svc.exportAllWorks(format, {
      search:     this.filterQ()       || undefined,
      assignedTo: this.filterMember()  || undefined,
      status:     (this.filterStatus()   as any) || undefined,
      priority:   (this.filterPriority() as any) || undefined,
      month:      this.filterMonth()   || undefined,
      year:       this.filterYear()    || undefined,
    }).subscribe({
      next: (blob: Blob) => {
        this.svc.downloadBlob(blob, format);
        this.exporting.set(null);
        this.showToast(`${format.toUpperCase()} export downloaded.`, 'success');
      },
      error: (err: Error) => { this.exporting.set(null); this.showToast(err.message, 'error'); }
    });
  }

  // ════════════════════════════════════════════════════════════════
  // View task details. The All Works page is read-only for every user.
  // ════════════════════════════════════════════════════════════════

  openViewModal(t: Task): void {
    const assignedToId = typeof t.assignedTo === 'string' ? t.assignedTo : (t.assignedTo?._id ?? '');
    this.form.set({ ...t, assignedTo: assignedToId });
    this.showModal.set(true);
  }

  closeModal(): void {
    this.showModal.set(false);
    this.form.set({});
  }

  closeOnBackdrop(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) this.closeModal();
  }

  // ── Display helpers ────────────────────────────────────────────────
  taskAssigneeName(t: Task): string { return assignedToName(t); }

  formAssigneeName(): string {
    const assignedTo = this.form().assignedTo;
    if (typeof assignedTo === 'string') {
      return this.members().find(member => member._id === assignedTo)?.name
        || this.form().assignedToName
        || '—';
    }
    return assignedTo?.name || this.form().assignedToName || '—';
  }

  initials(name: string): string {
    return (name || '').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '—';
  }

  completionPct(items: Task[]): number {
    if (!items.length) return 0;
    return Math.round(items.filter(t => t.status === 'Completed').length / items.length * 100);
  }

  statusChip(status: string): string {
    const map: Record<string, string> = {
      'Completed': 'chip-completed', 'In Progress': 'chip-progress',
      'In Review': 'chip-review', 'Not Started': 'chip-ns',
    };
    return map[status] ?? '';
  }

  statusIcon(status: string): string {
    const map: Record<string, string> = {
      'Completed': '✓', 'In Progress': '⚡', 'In Review': '👁', 'Not Started': '○',
    };
    return map[status] ?? status;
  }

  priorityClass(p: string): string {
    return p === 'High' ? 'pri-high' : p === 'Medium' ? 'pri-medium' : 'pri-low';
  }

  rowOverdueClass(t: Task): string {
    const today = new Date().toISOString().slice(0, 10);
    return (t.dueDate && t.dueDate < today && t.status !== 'Completed') ? 'row-overdue' : '';
  }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
