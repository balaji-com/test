import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgIf, NgFor, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import ExcelJS from 'exceljs';
import { jsPDF } from 'jspdf';
import { autoTable } from 'jspdf-autotable';
import { AnalyticsService, MonthlyReportResponse } from '../../core/services/analytics.service';
import { PermissionsService } from '../../core/services/permissions.service';

const MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December'];
const YEARS  = ['2024','2025','2026','2027'];

interface Toast { msg: string; type: 'success'|'error'; }
interface MemberReportSummary {
  uid: string;
  name: string;
  color: string;
  total: number;
  done: number;
  inProg: number;
  inRev: number;
  notSt: number;
  rework: number;
}
interface CategoryReportSummary {
  cat: string;
  total: number;
  done: number;
  inProg: number;
  rework: number;
}

@Component({
  selector: 'app-monthly-reports',
  standalone: true,
  imports: [NgIf, NgFor, NgClass, FormsModule],
  templateUrl: './monthly-reports.component.html',
  styleUrl: './monthly-reports.component.css',
})
export class MonthlyReportsComponent implements OnInit {
  private readonly svc = inject(AnalyticsService);
  readonly perms        = inject(PermissionsService);

  readonly MONTHS = MONTHS;
  readonly YEARS  = YEARS;

  selMonth = signal(new Date().toLocaleString('en', { month: 'long' }));
  selYear  = signal(String(new Date().getFullYear()));
  selectedUser = signal('');
  selectedCategory = signal('');
  selectedStatus = signal('');
  searchTerm = signal('');

  report   = signal<MonthlyReportResponse | null>(null);
  loading  = signal(true);
  toast    = signal<Toast | null>(null);

  readonly allTasks = computed(() => this.report()?.tasks ?? []);
  readonly userOptions = computed(() => this.report()?.byMember ?? []);
  readonly categoryOptions = computed(() => this.report()?.byCategory ?? []);
  readonly tasks = computed(() => {
    const user = this.selectedUser();
    const category = this.selectedCategory();
    const status = this.selectedStatus();
    const search = this.searchTerm().trim().toLocaleLowerCase();
    return this.allTasks().filter(task =>
      (!user || task.assignedToId === user) &&
      (!category || (task.cat || 'Uncategorised') === category) &&
      (!status || task.status === status) &&
      (!search || [task.task, task.assignedTo, task.cat, task.brief]
        .some(value => value.toLocaleLowerCase().includes(search)))
    );
  });
  readonly summary = computed(() => {
    const tasks = this.tasks();
    if (!this.report()) return null;
    const today = new Date().toISOString().slice(0, 10);
    return {
      total: tasks.length,
      done: tasks.filter(task => task.status === 'Completed').length,
      inProg: tasks.filter(task => task.status === 'In Progress').length,
      inRev: tasks.filter(task => task.status === 'In Review').length,
      notSt: tasks.filter(task => task.status === 'Not Started').length,
      rework: tasks.reduce((sum, task) => sum + (task.rework || 0), 0),
      highPri: tasks.filter(task => task.priority === 'High').length,
      overdue: tasks.filter(task => task.dueDate && task.dueDate < today && task.status !== 'Completed').length,
    };
  });
  readonly byMember = computed<MemberReportSummary[]>(() => {
    const memberMap = new Map<string, MemberReportSummary>();
    const members = this.userOptions();
    for (const task of this.tasks()) {
      const key = task.assignedToId || task.assignedTo;
      const original = members.find(member => member.uid === key);
      const member = memberMap.get(key) ?? {
        uid: key,
        name: task.assignedTo,
        color: original?.color ?? 'var(--accent)',
        total: 0, done: 0, inProg: 0, inRev: 0, notSt: 0, rework: 0,
      };
      member.total++;
      if (task.status === 'Completed') member.done++;
      if (task.status === 'In Progress') member.inProg++;
      if (task.status === 'In Review') member.inRev++;
      if (task.status === 'Not Started') member.notSt++;
      member.rework += task.rework || 0;
      memberMap.set(key, member);
    }
    return [...memberMap.values()].sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  });
  readonly byCategory = computed<CategoryReportSummary[]>(() => {
    const categoryMap = new Map<string, CategoryReportSummary>();
    for (const task of this.tasks()) {
      const category = task.cat || 'Uncategorised';
      const stats = categoryMap.get(category) ?? { cat: category, total: 0, done: 0, inProg: 0, rework: 0 };
      stats.total++;
      if (task.status === 'Completed') stats.done++;
      if (task.status === 'In Progress') stats.inProg++;
      stats.rework += task.rework || 0;
      categoryMap.set(category, stats);
    }
    return [...categoryMap.values()].sort((a, b) => b.total - a.total || a.cat.localeCompare(b.cat));
  });
  readonly hasActiveFilters = computed(() =>
    !!(this.selectedUser() || this.selectedCategory() || this.selectedStatus() || this.searchTerm())
  );

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.selectedUser.set('');
    this.selectedCategory.set('');
    this.selectedStatus.set('');
    this.searchTerm.set('');
    this.svc.monthlyReport(this.selMonth(), this.selYear()).subscribe({
      next: res => { this.report.set(res); this.loading.set(false); },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  onFilterChange(): void { this.load(); }

  setStatusFilter(status: string): void {
    this.selectedStatus.set(this.selectedStatus() === status ? '' : status);
  }

  setUserFilter(userId: string): void {
    this.selectedUser.set(this.selectedUser() === userId ? '' : userId);
  }

  setCategoryFilter(category: string): void {
    this.selectedCategory.set(this.selectedCategory() === category ? '' : category);
  }

  clearFilters(): void {
    this.selectedUser.set('');
    this.selectedCategory.set('');
    this.selectedStatus.set('');
    this.searchTerm.set('');
  }

  statusClass(status: string): string {
    return status === 'Completed' ? 'chip-done' :
      status === 'In Progress' ? 'chip-wip' :
      status === 'In Review' ? 'chip-rev' : 'chip-ns';
  }

  priorityClass(priority: string): string {
    return priority === 'High' ? 'chip-high' :
      priority === 'Medium' ? 'chip-med' : 'chip-low';
  }

  initials(name: string): string {
    return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  }

  exportCSV(): void {
    const rows = this.taskExportRows();
    const csv = rows.map(row => row.map(cell => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    this.downloadFile(new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' }), 'csv');
  }

  async exportExcel(): Promise<void> {
    try {
      const summary = this.summary();
      if (!summary) return;
      const workbook = new ExcelJS.Workbook();
      const summarySheet = workbook.addWorksheet('Summary');
      summarySheet.addRows([
        ['Monthly Report', `${this.selMonth()} ${this.selYear()}`],
        ['Tasks', summary.total],
        ['Completed', summary.done],
        ['In Progress', summary.inProg],
        ['In Review', summary.inRev],
        ['Not Started', summary.notSt],
        ['Rework', summary.rework],
        ['Overdue', summary.overdue],
        ['High Priority', summary.highPri],
      ]);
      summarySheet.columns = [{ width: 20 }, { width: 28 }];

      const memberSheet = workbook.addWorksheet('By Team Member');
      memberSheet.addRow(['Team Member', 'Total', 'Completed', 'In Progress', 'In Review', 'Not Started', 'Rework']);
      this.byMember().forEach(member => memberSheet.addRow([
        member.name, member.total, member.done, member.inProg, member.inRev, member.notSt, member.rework,
      ]));
      memberSheet.columns = [{ width: 28 }, ...Array.from({ length: 6 }, () => ({ width: 16 }))];

      const categorySheet = workbook.addWorksheet('By Category');
      categorySheet.addRow(['Category', 'Total', 'Completed', 'In Progress', 'Rework']);
      this.byCategory().forEach(category => categorySheet.addRow([
        category.cat, category.total, category.done, category.inProg, category.rework,
      ]));
      categorySheet.columns = [{ width: 28 }, ...Array.from({ length: 4 }, () => ({ width: 16 }))];

      const taskSheet = workbook.addWorksheet('Tasks');
      this.taskExportRows().forEach(row => taskSheet.addRow(row));
      taskSheet.columns = [
        { width: 32 }, { width: 24 }, { width: 18 }, { width: 14 },
        { width: 24 }, { width: 12 }, { width: 16 }, { width: 48 },
      ];
      [memberSheet, categorySheet, taskSheet].forEach(sheet => {
        sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
        sheet.getRow(1).fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FF2D52E6' },
        };
        sheet.views = [{ state: 'frozen', ySplit: 1 }];
        sheet.autoFilter = {
          from: { row: 1, column: 1 },
          to: { row: sheet.rowCount, column: sheet.columnCount },
        };
      });

      const buffer = await workbook.xlsx.writeBuffer();
      this.downloadFile(
        new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
        'xlsx'
      );
    } catch (error) {
      this.showToast(error instanceof Error ? error.message : 'Unable to export the Excel report.', 'error');
    }
  }

  exportPDF(): void {
    try {
      const summary = this.summary();
      if (!summary) return;
      const doc = new jsPDF({ orientation: 'landscape' });
      doc.setFontSize(18);
      doc.text(`Monthly Report - ${this.selMonth()} ${this.selYear()}`, 14, 18);
      doc.setFontSize(10);
      doc.text(
        `Tasks: ${summary.total}  |  Completed: ${summary.done}  |  In Progress: ${summary.inProg}  |  ` +
        `In Review: ${summary.inRev}  |  Not Started: ${summary.notSt}  |  Rework: ${summary.rework}  |  ` +
        `Overdue: ${summary.overdue}  |  High Priority: ${summary.highPri}`,
        14, 27
      );

      doc.addPage();
      doc.setFontSize(14);
      doc.text('By Team Member', 14, 18);
      autoTable(doc, {
        startY: 24,
        head: [['Team Member', 'Total', 'Completed', 'In Progress', 'In Review', 'Not Started', 'Rework']],
        body: this.byMember().map(member => [
          member.name, member.total, member.done, member.inProg, member.inRev, member.notSt, member.rework,
        ]),
      });

      doc.addPage();
      doc.setFontSize(14);
      doc.text('By Category', 14, 18);
      autoTable(doc, {
        startY: 24,
        head: [['Category', 'Total', 'Completed', 'In Progress', 'Rework']],
        body: this.byCategory().map(category => [
          category.cat, category.total, category.done, category.inProg, category.rework,
        ]),
      });

      doc.addPage();
      doc.setFontSize(14);
      doc.text(`Tasks (${this.tasks().length})`, 14, 18);
      autoTable(doc, {
        startY: 24,
        head: [['Task', 'Assigned To', 'Status', 'Priority', 'Category', 'Rework', 'Due Date', 'Brief']],
        body: this.tasks().map(task => [
          task.task, task.assignedTo, task.status, task.priority, task.cat || '', task.rework || 0,
          task.dueDate || '', task.brief || '',
        ]),
        styles: { fontSize: 8, cellPadding: 2 },
      });
      doc.save(this.reportFilename('pdf'));
    } catch (error) {
      this.showToast(error instanceof Error ? error.message : 'Unable to export the PDF report.', 'error');
    }
  }

  private taskExportRows(): (string | number)[][] {
    return [
      ['Task', 'Assigned To', 'Status', 'Priority', 'Category', 'Rework', 'Due Date', 'Brief'],
      ...this.tasks().map(task => [
        task.task, task.assignedTo, task.status, task.priority, task.cat || '',
        task.rework || 0, task.dueDate || '', task.brief || '',
      ]),
    ];
  }

  private reportFilename(extension: 'csv' | 'xlsx' | 'pdf'): string {
    return `report-${this.selMonth()}-${this.selYear()}.${extension}`;
  }

  private downloadFile(blob: Blob, extension: 'csv' | 'xlsx'): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = this.reportFilename(extension);
    link.click();
    URL.revokeObjectURL(url);
  }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success'|'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
