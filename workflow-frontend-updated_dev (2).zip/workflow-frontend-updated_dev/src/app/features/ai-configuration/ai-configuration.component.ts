import { Component, signal } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
@Component({ selector:'app-ai-configuration', standalone:true, imports:[NgIf,NgFor,FormsModule],
  templateUrl:'./ai-configuration.component.html', styleUrl:'./ai-configuration.component.css' })
export class AiConfigurationComponent {
  providers = signal([
    {id:'anthropic',name:'Anthropic Claude',logo:'🤖',active:true,apiKey:'',model:'claude-sonnet-4-20250514'},
    {id:'openai',name:'OpenAI GPT',logo:'🧠',active:false,apiKey:'',model:'gpt-4o'},
    {id:'google',name:'Google Gemini',logo:'💫',active:false,apiKey:'',model:'gemini-1.5-pro'},
  ]);
  saved = signal(false);
  toggleActive(id:string){
    this.providers.update(ps=>ps.map(p=>({...p,active:p.id===id})));
  }
  updateKey(id:string, key:string){
    this.providers.update(ps=>ps.map(p=>p.id===id?{...p,apiKey:key}:p));
  }
  updateModel(id:string, model:string){
    this.providers.update(ps=>ps.map(p=>p.id===id?{...p,model}:p));
  }
  save(){ this.saved.set(true); setTimeout(()=>this.saved.set(false),2500); }
}
