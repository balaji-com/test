import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf, SlicePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { TaskService } from '../../core/services/task.service';
import { UserService, Member } from '../../core/services/user.service';
import { PermissionsService } from '../../core/services/permissions.service';
import { ApprovalService, ApprovalRequest } from '../../core/services/approval.service';
import { TaskDropdownOptionsService } from '../../core/services/task-dropdown-options.service';
import { DEFAULT_TASK_DROPDOWN_OPTIONS, TaskDropdownOptions } from '../../core/models/task-dropdown-options.model';
import { Task, TaskPriority } from '../../core/models/task.model';

interface Toast { msg: string; type: 'success' | 'error'; }

const EMPTY_FORM = (): Partial<Task> => ({
  task: '', fn: '', cat: '', sub: '', brief: 'NA',
  assignedTo: '', internalCustomer: '',
  priority: 'Medium',
  month: new Date().toLocaleString('en', { month: 'long' }),
  year: String(new Date().getFullYear()),
  startDate: '', dueDate: '', status: 'Not Started',
  estHrs: '', actHrs: '', rework: 0,
  approvalStatus: '', approvalTo: '', approvalComment: '',
  notes: '',
});

@Component({
  selector: 'app-my-tasks',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, SlicePipe, FormsModule],
  templateUrl: './my-tasks.component.html',
  styleUrl: './my-tasks.component.css'
})
export class MyTasksComponent implements OnInit {
  readonly auth          = inject(AuthService);
  readonly perms         = inject(PermissionsService);
  private readonly svc         = inject(TaskService);
  private readonly userSvc     = inject(UserService);
  private readonly approvalSvc = inject(ApprovalService);
  private readonly dropdownOptionsSvc = inject(TaskDropdownOptionsService);

  /** True if the user has 'editor' or 'admin' on my_tasks — gates Add/Edit/Delete UI. */
  readonly canEdit = computed(() => this.perms.canEdit('my_tasks'));

  // ── Data ─────────────────────────────────────────────────────────
  tasks      = signal<Task[]>([]);
  members    = signal<Member[]>([]);
  dropdownOptions = signal<TaskDropdownOptions>(structuredClone(DEFAULT_TASK_DROPDOWN_OPTIONS));
  taskNames  = signal<string[]>([]);   // distinct names from DB
  loading    = signal(true);
  toast      = signal<Toast | null>(null);

  // Active members only — for Assigned To dropdown
  readonly activeMembers = computed(() => this.members().filter(m => m.isActive));

  // Approver list = active members except current user
  readonly approverList = computed(() => {
    const me = this.auth.currentUser()?._id;
    return this.activeMembers().filter(m => m._id !== me);
  });

  // ── Filters ──────────────────────────────────────────────────────
  filterTask     = signal('');
  filterPriority = signal('');
  filterStatus   = signal('');
  filterReminder = signal<'overdue' | ''>('');
  currentPage    = signal(1);
  readonly PAGE_SIZE = 10;
  bulkSelected   = signal<Set<string>>(new Set());
  selectAll      = signal(false);

  // ── Modal state ──────────────────────────────────────────────────
  showModal      = signal(false);
  isEditing      = signal(false);
  saving         = signal(false);
  deleting       = signal<string | null>(null);
  formError      = signal('');
  form           = signal<Partial<Task>>(EMPTY_FORM());

  // Task name combo — 'select' = pick from DB list, 'new' = free-type
  taskNameMode   = signal<'select' | 'new'>('select');
  taskNameSearch = signal('');

  readonly filteredTaskNames = computed(() => {
    const q = this.taskNameSearch().toLowerCase().trim();
    if (!q) return this.taskNames();
    return this.taskNames().filter(n => n.toLowerCase().includes(q));
  });

  // ── Request Approval modal (multi-reviewer, + button rows) ──────────
  approvalModalOpen   = signal(false);
  approvalTask        = signal<Task | null>(null);
  approvalMessage     = signal('');
  approvalSending     = signal(false);
  approvalError       = signal('');
  approvalTaskReqs    = signal<ApprovalRequest[]>([]);
  approvalTaskSummary = signal<{ total: number; approved: number; rejected: number; pending: number } | null>(null);
  approvalTaskLoading = signal(false);

  // Row-based reviewer selection — each row is one reviewer slot
  approvalRows        = signal<{ id: string; uid: string }[]>([]);
  private nextRowId   = 1;

  // UIDs of filled rows (no empty slots)
  readonly filledRows = computed(() =>
    this.approvalRows().map(r => r.uid).filter(Boolean)
  );

  // UIDs already chosen — used to prevent duplicate picks
  private readonly usedIds = computed(() =>
    new Set(this.approvalRows().map(r => r.uid).filter(Boolean))
  );

  // Members available for a specific row (excludes picks in OTHER rows)
  availableForRow(rowUid: string): Member[] {
    const used = this.usedIds();
    return this.approverList().filter(m => m._id === rowUid || !used.has(m._id));
  }

  addApprovalRow(): void {
    if (this.approvalRows().length >= this.approverList().length) return;
    this.approvalRows.update(rows => [...rows, { id: String(this.nextRowId++), uid: '' }]);
  }

  removeApprovalRow(id: string): void {
    this.approvalRows.update(rows => rows.filter(r => r.id !== id));
  }

  setRowReviewer(id: string, uid: string): void {
    this.approvalRows.update(rows => rows.map(r => r.id === id ? { ...r, uid } : r));
  }

  getReviewerName(uid: string):     string { return this.members().find(m => m._id === uid)?.name  || ''; }
  getReviewerColor(uid: string):    string { return this.members().find(m => m._id === uid)?.color || 'var(--accent)'; }
  getInitials(name: string | undefined): string {
    return name?.split(' ').map(word => word[0]).join('').slice(0, 2).toUpperCase() || '??';
  }
  getReviewerInitials(uid: string): string {
    const n = this.getReviewerName(uid);
    return n.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase() || '??';
  }

  // ── Dropdown data ────────────────────────────────────────────────
  get FUNCTIONS(): string[] { return this.dropdownOptions().functions; }
  get CATEGORIES_KEYS(): string[] { return Object.keys(this.dropdownOptions().categories); }
  get MONTHS(): string[] { return this.dropdownOptions().months; }
  get YEARS(): string[] { return this.dropdownOptions().years; }
  readonly PRIORITIES: TaskPriority[] = ['High', 'Medium', 'Low'];
  get STATUSES(): string[] { return this.dropdownOptions().statuses; }
  get BRIEF_OPTIONS(): string[] { return this.dropdownOptions().briefingsheets; }

  // Sub-categories for currently selected category
  readonly subCats = computed(() => this.dropdownOptions().categories[this.form().cat || ''] || []);

  // ── Stats and paginated task list ─────────────────────────────────
  readonly filteredTasks = computed(() => {
    const search = this.filterTask().trim().toLowerCase();
    const priority = this.filterPriority();
    const status = this.filterStatus();
    const reminder = this.filterReminder();
    return this.tasks().filter(task => {
      if (priority && task.priority !== priority) return false;
      if (status && task.status !== status) return false;
      if (reminder === 'overdue' &&
          (!task.dueDate || task.dueDate >= this.today || task.status === 'Completed')) return false;
      if (search && ![task.task, task.cat, task.sub].some(value => value?.toLowerCase().includes(search))) return false;
      return true;
    }).sort((a, b) => {
      const aCreatedAt = Date.parse(a.createdAt ?? '') || 0;
      const bCreatedAt = Date.parse(b.createdAt ?? '') || 0;
      return bCreatedAt - aCreatedAt || b._id.localeCompare(a._id);
    });
  });
  readonly totalPages = computed(() =>
    Math.max(1, Math.ceil(this.filteredTasks().length / this.PAGE_SIZE))
  );
  readonly visibleTasks = computed(() => {
    const start = (this.currentPage() - 1) * this.PAGE_SIZE;
    return this.filteredTasks().slice(start, start + this.PAGE_SIZE);
  });
  readonly pageNumbers = computed(() => {
    const total = this.totalPages(), current = this.currentPage();
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: (number | '...')[] = [1];
    if (current > 3) pages.push('...');
    for (let page = Math.max(2, current - 1); page <= Math.min(total - 1, current + 1); page++) {
      pages.push(page);
    }
    if (current < total - 2) pages.push('...');
    pages.push(total);
    return pages;
  });

  readonly stats = computed(() => {
    const tasks = this.tasks();
    return {
      total:      tasks.length,
      completed:  tasks.filter(t => t.status === 'Completed').length,
      inProgress: tasks.filter(t => t.status === 'In Progress').length,
      overdue:    tasks.filter(t => t.dueDate && t.dueDate < this.today && t.status !== 'Completed').length,
    };
  });

  // ── Lifecycle ──────────────────────────────────────────────────────
  ngOnInit(): void {
    this.loadTasks();
    this.loadMembers();
    this.loadTaskNames();
    this.loadDropdownOptions();
  }

  loadDropdownOptions(): void {
    this.dropdownOptionsSvc.getOptions().subscribe({
      next: options => this.dropdownOptions.set(options),
      error: (err: Error) => this.showToast(`Unable to load task dropdown values: ${err.message}`, 'error'),
    });
  }

  loadTaskNames(): void {
    this.svc.getTaskNames().subscribe({
      next:  names => this.taskNames.set(names),
      error: ()    => {}
    });
  }

  loadTasks(): void {
    this.loading.set(true);
    this.svc.getTasks({
      limit: 1000,
      createdByMe: this.auth.isAdmin() || undefined,
    }).subscribe({
      next:  (tasks: Task[]) => { this.tasks.set(tasks); this.loading.set(false); },
      error: (err: Error)    => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  // ── Local list filters ────────────────────────────────────────────
  onSearchInput(value: string): void {
    this.filterTask.set(value);
    this.currentPage.set(1);
  }

  onFilterChange(): void {
    this.currentPage.set(1);
  }

  setSummaryFilter(filter: 'all' | 'completed' | 'inProgress' | 'overdue'): void {
    this.filterStatus.set(filter === 'completed' ? 'Completed' : filter === 'inProgress' ? 'In Progress' : '');
    this.filterReminder.set(filter === 'overdue' ? 'overdue' : '');
    this.currentPage.set(1);
    this.clearBulk();
  }

  goToPage(page: number | '...'): void {
    if (page !== '...' && page !== this.currentPage()) this.currentPage.set(page);
  }

  prevPage(): void {
    if (this.currentPage() > 1) this.currentPage.update(page => page - 1);
  }

  nextPage(): void {
    if (this.currentPage() < this.totalPages()) this.currentPage.update(page => page + 1);
  }

  private keepCurrentPageInRange(): void {
    if (this.currentPage() > this.totalPages()) this.currentPage.set(this.totalPages());
  }

  loadMembers(): void {
    this.userSvc.getActiveUsers().subscribe({
      next:  (users: Member[]) => this.members.set(users),
      error: () => {} // non-critical — Assigned To dropdown just stays empty
    });
  }

  // ── Date helpers ─────────────────────────────────────────────────
  get today()       { return new Date().toISOString().slice(0, 10); }
  get tomorrow()    { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); }
  get inThreeDays() { const d = new Date(); d.setDate(d.getDate() + 3); return d.toISOString().slice(0, 10); }

  // ── Modal: open for ADD ──────────────────────────────────────────
  openAddModal(): void {
    if (!this.canEdit()) { this.showToast('You have view-only access to this section.', 'error'); return; }
    const me = this.auth.currentUser()?._id ?? '';
    this.form.set({ ...EMPTY_FORM(), assignedTo: me });
    this.taskNameMode.set('select');
    this.taskNameSearch.set('');
    this.isEditing.set(false);
    this.formError.set('');
    this.saving.set(false);
    this.showModal.set(true);
  }

  openEditModal(t: Task): void {
    if (!this.canEdit()) { this.showToast('You have view-only access to this section.', 'error'); return; }
    // Extract plain _id string from assignedTo — it may be a populated object when read from API
    const assignedToId = typeof t.assignedTo === 'object' && t.assignedTo !== null
      ? (t.assignedTo as any)._id ?? ''
      : t.assignedTo ?? '';
    this.form.set({ ...t, assignedTo: assignedToId });
    // If the task name exists in DB list use select mode, else new
    this.taskNameMode.set(this.taskNames().includes(t.task) ? 'select' : 'new');
    this.taskNameSearch.set('');
    this.isEditing.set(true);
    this.formError.set('');
    this.saving.set(false);
    this.showModal.set(true);
  }

  closeModal(): void {
    this.showModal.set(false);
    this.form.set(EMPTY_FORM());
    this.formError.set('');
    this.taskNameMode.set('select');
    this.taskNameSearch.set('');
  }

  closeOnBackdrop(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) this.closeModal();
  }

  // ── Patch form field helper ──────────────────────────────────────
  patchForm(field: keyof Task, value: any): void {
    this.form.update(f => ({ ...f, [field]: value }));
    if (field === 'cat') this.form.update(f => ({ ...f, sub: '' }));
  }

  // ── Submit (Add or Edit) → backend API ───────────────────────────
  submitTask(): void {
    this.formError.set('');
    const f = this.form();

    if (!f.task?.trim())  { this.formError.set('Task name is required.');   return; }
    if (!f.fn)             { this.formError.set('Function is required.');    return; }
    if (!f.cat)            { this.formError.set('Category is required.');    return; }
    if (!f.assignedTo)     { this.formError.set('Assigned To is required.'); return; }
    if (!f.priority)       { this.formError.set('Priority is required.');    return; }
    if (!f.status)         { this.formError.set('Status is required.');      return; }

    this.saving.set(true);

    // Strip fields the backend doesn't accept / shouldn't be overwritten
    const { _id, createdAt, updatedAt, reviewers, ...payload } = f as Task;

    if (this.isEditing() && _id) {
      this.svc.updateTask(_id, payload).subscribe({
        next: (updated: Task) => {
          this.tasks.update(ts => ts.map(t => t._id === updated._id ? updated : t));
          this.saving.set(false);
          this.showModal.set(false);
          this.form.set(EMPTY_FORM());
          this.taskNameMode.set('select');
          this.taskNameSearch.set('');
          this.showToast('✓ Task updated successfully!', 'success');
          this.loadTaskNames(); // refresh in case task name changed
        },
        error: (err: Error) => { this.saving.set(false); this.formError.set(err.message); }
      });
    } else {
      this.svc.createTask({ ...payload, rework: Number(payload.rework) || 0 }).subscribe({
        next: (created: Task) => {
          this.tasks.update(ts => [created, ...ts]);
          this.currentPage.set(1);
          this.saving.set(false);
          this.showModal.set(false);
          this.form.set(EMPTY_FORM());
          this.taskNameMode.set('select');
          this.taskNameSearch.set('');
          this.showToast('✓ Task added successfully!', 'success');
          this.loadTaskNames(); // refresh task name list from DB
        },
        error: (err: Error) => { this.saving.set(false); this.formError.set(err.message); }
      });
    }
  }

  // ── Delete (single) ───────────────────────────────────────────────
  deleteTask(t: Task): void {
    if (!this.canEdit()) { this.showToast("You have view-only access to this section.", 'error'); return; }
    if (!confirm(`Delete "${t.task}"? This cannot be undone.`)) return;
    this.deleting.set(t._id);
    this.svc.deleteTask(t._id).subscribe({
      next: () => {
        this.tasks.update(ts => ts.filter(x => x._id !== t._id));
        this.keepCurrentPageInRange();
        this.deleting.set(null);
        this.showToast('Task deleted.', 'success');
      },
      error: (err: Error) => { this.deleting.set(null); this.showToast(err.message, 'error'); }
    });
  }

  // ── Mark complete (quick action) ──────────────────────────────────
  // ── Request Approval ──────────────────────────────────────────────
  openApprovalModal(t: Task): void {
    this.approvalTask.set(t);
    this.approvalRows.set([{ id: String(this.nextRowId++), uid: '' }]); // one empty row to start
    this.approvalMessage.set('');
    this.approvalError.set('');
    this.approvalSending.set(false);
    this.approvalTaskReqs.set([]);
    this.approvalTaskSummary.set(null);
    this.approvalModalOpen.set(true);
    this.approvalTaskLoading.set(true);
    this.approvalSvc.getForTask(t._id).subscribe({
      next: res => {
        this.approvalTaskReqs.set(res.data);
        this.approvalTaskSummary.set(res.summary);
        this.approvalTaskLoading.set(false);
      },
      error: () => this.approvalTaskLoading.set(false),
    });
  }

  closeApprovalModal(): void {
    this.approvalModalOpen.set(false);
    this.approvalTask.set(null);
    this.approvalRows.set([]);
    this.approvalTaskSummary.set(null);
  }

  sendApproval(): void {
    const task = this.approvalTask();
    if (!task) return;
    if (!this.canRequestApproval(task)) {
      this.approvalError.set('Only the assigned member can send approval requests for this task.');
      return;
    }
    const ids = this.filledRows();
    if (!ids.length) { this.approvalError.set('Add at least one reviewer.'); return; }
    const dupes = ids.length !== new Set(ids).size;
    if (dupes) { this.approvalError.set('Each reviewer can only be added once.'); return; }
    this.approvalError.set('');
    this.approvalSending.set(true);
    this.approvalSvc.send(task._id, ids, this.approvalMessage()).subscribe({
      next: reqs => {
        this.tasks.update(ts => ts.map(t =>
          t._id === task._id ? { ...t, approvalStatus: 'Pending' } : t
        ));
        this.approvalSending.set(false);
        this.approvalModalOpen.set(false);
        this.approvalRows.set([]);
        const count = Array.isArray(reqs) ? reqs.length : ids.length;
        this.showToast(`✓ Approval request sent to ${count} reviewer${count > 1 ? 's' : ''}!`, 'success');
      },
      error: (err: Error) => { this.approvalError.set(err.message); this.approvalSending.set(false); }
    });
  }

  canRequestApproval(task: Task | null): boolean {
    if (!task || task.status === 'Completed' || !this.canEdit()) return false;
    const assignedTo = typeof task.assignedTo === 'object' && task.assignedTo !== null
      ? task.assignedTo._id
      : task.assignedTo;
    return assignedTo === this.auth.currentUser()?._id;
  }

  // ── Reviewer row helpers ──────────────────────────────────────────
  addRow(): void {
    this.approvalRows.update(rows => [...rows, { id: String(this.nextRowId++), uid: '' }]);
  }

  removeRow(rowId: string): void {
    this.approvalRows.update(rows => rows.filter(r => r.id !== rowId));
  }

  setRowMember(rowId: string, uid: string): void {
    this.approvalRows.update(rows => rows.map(r => r.id === rowId ? { ...r, uid } : r));
  }

  // Returns true if this uid is already used in another row (duplicate guard)
  rowMemberUsed(rowId: string, uid: string): boolean {
    if (!uid) return false;
    return this.approvalRows().some(r => r.id !== rowId && r.uid === uid);
  }

  // Approval progress helpers
  approvalBtnLabel(t: Task): string {
    if (!t.approvalStatus) return '✍️';
    if (t.approvalStatus === 'Approved')  return '✅';
    if (t.approvalStatus === 'Rejected')  return '✕✍️';
    if (t.approvalStatus === 'Pending')   return '⏳✍️';
    return '✍️';
  }

  approvalBtnTitle(t: Task): string {
    if (!t.approvalStatus) return 'Request Approval';
    return `Approval: ${t.approvalStatus} — click to view / resend`;
  }

  approvalStatusLabel(t: Task): string {
    const s = t.approvalStatus;
    if (!s)              return '';
    if (s === 'Pending') return '⏳ Pending';
    if (s === 'Approved') return '✓ Approved';
    if (s === 'Rejected') return '✕ Rejected';
    return s;
  }
  approvalStatusClass(t: Task): string {
    const m: Record<string, string> = { Pending:'appr-pending', Approved:'appr-approved', Rejected:'appr-rejected' };
    return m[t.approvalStatus || ''] ?? '';
  }

  markComplete(t: Task): void {
    if (!this.canEdit()) { this.showToast("You have view-only access to this section.", 'error'); return; }
    this.svc.updateTask(t._id, { status: 'Completed' }).subscribe({
      next: (updated: Task) => {
        this.tasks.update(ts => ts.map(x => x._id === updated._id ? updated : x));
        this.showToast('Marked as completed.', 'success');
      },
      error: (err: Error) => this.showToast(err.message, 'error')
    });
  }

  // ── Bulk actions → backend API ──────────────────────────────────
  toggleSelect(id: string): void {
    this.bulkSelected.update(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }
  toggleSelectAll(): void {
    this.selectAll.update(v => !v);
    this.bulkSelected.set(this.selectAll() ? new Set(this.filteredTasks().map(t => t._id)) : new Set());
  }
  isSelected(id: string): boolean { return this.bulkSelected().has(id); }
  clearBulk(): void { this.bulkSelected.set(new Set()); this.selectAll.set(false); }

  bulkMarkDone(): void {
    if (!this.canEdit()) { this.showToast("You have view-only access to this section.", 'error'); return; }
    const ids = [...this.bulkSelected()];
    this.svc.bulkAction(ids, 'complete').subscribe({
      next: () => {
        this.tasks.update(ts => ts.map(t => ids.includes(t._id) ? { ...t, status: 'Completed' } : t));
        this.clearBulk();
        this.showToast(`${ids.length} task(s) marked complete.`, 'success');
      },
      error: (err: Error) => this.showToast(err.message, 'error')
    });
  }

  bulkDelete(): void {
    if (!this.canEdit()) { this.showToast("You have view-only access to this section.", 'error'); return; }
    const ids = [...this.bulkSelected()];
    if (!confirm(`Delete ${ids.length} tasks? This cannot be undone.`)) return;
    this.svc.bulkAction(ids, 'delete').subscribe({
      next: () => {
        this.tasks.update(ts => ts.filter(t => !ids.includes(t._id)));
        this.keepCurrentPageInRange();
        this.clearBulk();
        this.showToast(`${ids.length} task(s) deleted.`, 'success');
      },
      error: (err: Error) => this.showToast(err.message, 'error')
    });
  }

  // ── Helpers: chips / row styles ───────────────────────────────────
  memberName(id: string): string {
    return this.members().find(m => m._id === id)?.name || '—';
  }

  rowClass(t: Task): string {
    if (!t.dueDate || t.status === 'Completed') return '';
    if (t.dueDate < this.today)        return 'row-overdue';
    if (t.dueDate === this.today)      return 'row-due-today';
    if (t.dueDate === this.tomorrow)   return 'row-due-tomorrow';
    if (t.dueDate <= this.inThreeDays) return 'row-due-soon';
    return '';
  }

  duePill(t: Task): { label: string; cls: string } | null {
    if (!t.dueDate || t.status === 'Completed') return null;
    if (t.dueDate < this.today)        return { label: '⚠ Overdue',   cls: 'overdue' };
    if (t.dueDate === this.today)      return { label: '⏰ Today',     cls: 'due-today' };
    if (t.dueDate === this.tomorrow)   return { label: '⏳ Tomorrow',  cls: 'due-tomorrow' };
    if (t.dueDate <= this.inThreeDays) return { label: '🔔 Due Soon',  cls: 'due-soon' };
    return null;
  }

  statusChip(status: string): { label: string; cls: string } {
    const map: Record<string, { label: string; cls: string }> = {
      'Completed':   { label: '✓ Completed',   cls: 'chip-completed' },
      'In Progress': { label: '⚡ In Progress', cls: 'chip-progress'  },
      'In Review':   { label: '👁 In Review',   cls: 'chip-review'    },
      'Not Started': { label: '○ Not Started',  cls: 'chip-ns'        },
    };
    return map[status] ?? { label: status, cls: '' };
  }

  priorityChip(p: string): { label: string; cls: string } {
    const map: Record<string, { label: string; cls: string }> = {
      'High':   { label: '🔴 High',   cls: 'pri-high'   },
      'Medium': { label: '🟡 Medium', cls: 'pri-medium' },
      'Low':    { label: '🟢 Low',    cls: 'pri-low'     },
    };
    return map[p] ?? { label: p, cls: '' };
  }

  // ── Toast ────────────────────────────────────────────────────────
  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
