import { Component, inject, signal } from '@angular/core';
import { AppStateService } from '../../core/services/app-state.service';

@Component({
  selector: 'app-backup', standalone: true, imports: [],
  templateUrl: './backup.component.html', styleUrl: './backup.component.css'
})
export class BackupComponent {
  readonly state = inject(AppStateService);
  restoreFileName = signal('');
  toastMsg = signal('');
  toastErr = signal(false);

  downloadBackup(): void {
    const data = { tasks: this.state.tasks(), exportedAt: new Date().toISOString(), version: '1.0' };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `ht-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    this.showToast('Backup downloaded!');
  }

  onFileChange(e: Event): void {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    this.restoreFileName.set(f.name);
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        if (!data.tasks || !Array.isArray(data.tasks)) throw new Error('Invalid format');
        if (!confirm(`Restore ${data.tasks.length} tasks from "${f.name}"? Current data will be replaced.`)) return;
        this.state.tasks.set(data.tasks);
        this.showToast('Restore successful!');
      } catch { this.showToast('Invalid backup file.', true); }
    };
    reader.readAsText(f);
  }

  clearAll(): void {
    if (confirm('Delete ALL tasks? This cannot be undone.')) {
      this.state.tasks.set([]);
      this.showToast('All tasks cleared.');
    }
  }

  showToast(msg: string, err = false): void {
    this.toastMsg.set(msg);
    this.toastErr.set(err);
    setTimeout(() => this.toastMsg.set(''), 3000);
  }
}
