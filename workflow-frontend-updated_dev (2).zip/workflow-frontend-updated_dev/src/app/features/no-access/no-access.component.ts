import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-no-access',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="no-access-page">
      <div class="no-access-icon">🚫</div>
      <h1>Access Restricted</h1>
      <p>You don't have permission to view this section. Contact your administrator if you believe this is a mistake.</p>
      <a routerLink="/my-tasks" class="back-link">← Back to My Tasks</a>
    </div>
  `,
  styles: [`
    .no-access-page {
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      text-align: center; min-height: 60vh; gap: 12px; padding: 40px 20px;
    }
    .no-access-icon { font-size: 48px; margin-bottom: 8px; }
    h1 { font-size: 20px; font-weight: 800; color: var(--text); margin: 0; }
    p { font-size: 13.5px; color: var(--text3); max-width: 420px; line-height: 1.6; margin: 0; }
    .back-link {
      margin-top: 12px; padding: 9px 20px; background: var(--accent); color: #fff;
      border-radius: var(--radius-sm); font-size: 13px; font-weight: 700;
      text-decoration: none; transition: opacity .15s;
    }
    .back-link:hover { opacity: .88; }
  `]
})
export class NoAccessComponent {}
