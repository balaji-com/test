import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import ExcelJS from 'exceljs';
import { PlanningEntry, PlanningUploadStatus } from '../../core/models/planning-entry.model';
import { PlanningService } from '../../core/services/planning.service';
import { PermissionsService } from '../../core/services/permissions.service';

interface PlannerDay {
  date: Date;
  iso: string;
  isToday: boolean;
  other: boolean;
  planningEntries: PlanningEntry[];
}

@Component({ selector:'app-planner', standalone:true, imports:[NgFor,NgIf,FormsModule],
  templateUrl:'./planner.component.html', styleUrl:'./planner.component.css' })
export class PlannerComponent implements OnInit {
  readonly perms = inject(PermissionsService);
  private readonly planningService = inject(PlanningService);
  private now = new Date();
  currentYear  = signal(this.now.getFullYear());
  currentMonth = signal(this.now.getMonth());
  planningEntries = signal<PlanningEntry[]>([]);
  editDraft = signal<PlanningEntry | null>(null);
  planningLoading = signal(false);
  exportingExcel = signal(false);
  importing = signal(false);
  deletingMonth = signal(false);
  savingEntry = signal(false);
  uploadStatusLoading = signal(false);
  uploadStatus = signal<PlanningUploadStatus>({ isUploaded: false, fileName: '', importedCount: 0 });
  importStatus = signal<{ message: string; error: boolean } | null>(null);
  MONTH_NAMES=['January','February','March','April','May','June','July','August','September','October','November','December'];
  YEARS=Array.from({ length: this.now.getFullYear() + 5 - 2000 + 1 }, (_value, index) => 2000 + index);
  DAY_NAMES=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  COLORS=['#2d52e6','#0aab78','#c8890a','#6336d6','#0887b0','#d43b3b','#e8720c'];

  ngOnInit(): void { this.loadPlanningEntries(); }

  get members(){
    return [...new Set(this.planningEntries().map(entry => entry.assignedTo).filter(Boolean))].sort();
  }
  get monthLabel(){ return `${this.MONTH_NAMES[this.currentMonth()]} ${this.currentYear()}`; }

  memberColor(name:string){ return this.COLORS[(name || 'Unassigned').charCodeAt(0)%this.COLORS.length]; }
  setMonth(month: string | number): void {
    this.currentMonth.set(Number(month));
    this.loadPlanningEntries();
  }
  setYear(year: string | number): void {
    this.currentYear.set(Number(year));
    this.loadPlanningEntries();
  }

  async exportMonthlyExcel(): Promise<void> {
    const entries = this.planningEntries();
    if (this.planningLoading() || this.exportingExcel() || entries.length === 0) return;

    this.exportingExcel.set(true);
    this.importStatus.set(null);
    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet('Monthly Planning');
      sheet.addRow([
        'Week', 'Publication Date', 'Content Title', 'Offerings', 'Segments / Industries',
        'Format', 'Content Objectives', 'Content Pillars', 'Target Audience', 'Channel', 'KPI',
        'Assigned To', 'Submission Due Date', 'Submission Actual Date', 'Reviewer',
        'Review Due Date', 'Review Actual Date', 'Depository Link', 'Posted Link', 'Status',
      ]);
      entries.forEach(entry => sheet.addRow([
        entry.week ?? '', entry.publicationDate, entry.contentTitle, entry.offerings,
        entry.segmentsIndustries, entry.format, entry.contentObjectives, entry.contentPillars,
        entry.targetAudience, entry.channel, entry.kpi, entry.assignedTo, entry.submissionDueDate,
        entry.submissionActualDate, entry.reviewer, entry.reviewDueDate, entry.reviewActualDate,
        entry.depositoryLink, entry.postedLink, entry.status,
      ]));
      sheet.columns = [
        { width: 10 }, { width: 16 }, { width: 32 }, { width: 24 }, { width: 28 },
        { width: 18 }, { width: 32 }, { width: 28 }, { width: 28 }, { width: 20 },
        { width: 20 }, { width: 22 }, { width: 18 }, { width: 20 }, { width: 22 },
        { width: 18 }, { width: 20 }, { width: 36 }, { width: 36 }, { width: 18 },
      ];
      sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      sheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF2D52E6' },
      };
      sheet.views = [{ state: 'frozen', ySplit: 1 }];
      sheet.autoFilter = {
        from: { row: 1, column: 1 },
        to: { row: sheet.rowCount, column: sheet.columnCount },
      };

      const buffer = await workbook.xlsx.writeBuffer();
      const url = URL.createObjectURL(new Blob(
        [buffer],
        { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }
      ));
      const link = document.createElement('a');
      link.href = url;
      link.download = `planning-${this.monthLabel.replace(/\s+/g, '-')}.xlsx`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      this.importStatus.set({
        message: error instanceof Error ? error.message : 'Unable to export monthly planning details.',
        error: true,
      });
    } finally {
      this.exportingExcel.set(false);
    }
  }

  calDays = computed(()=>{
    const y=this.currentYear(), m=this.currentMonth();
    const firstDay=new Date(y,m,1).getDay();
    const daysInMonth=new Date(y,m+1,0).getDate();
    const todayStr=new Date().toISOString().slice(0,10);
    const entries=this.planningEntries();
    const days:PlannerDay[]=[];
    const prev=new Date(y,m,0).getDate();
    for(let i=firstDay-1;i>=0;i--){ const d=new Date(y,m-1,prev-i); days.push({date:d,iso:d.toISOString().slice(0,10),isToday:false,other:true,planningEntries:[]}); }
    for(let d=1;d<=daysInMonth;d++){ const date=new Date(y,m,d); const iso=date.toISOString().slice(0,10); days.push({date,iso,isToday:iso===todayStr,other:false,planningEntries:entries.filter(e=>e.publicationDate===iso)}); }
    const rem=42-days.length;
    for(let d=1;d<=rem;d++){ const date=new Date(y,m+1,d); days.push({date,iso:date.toISOString().slice(0,10),isToday:false,other:true,planningEntries:[]}); }
    return days;
  });

  loadPlanningEntries(): void {
    const month = this.currentMonth();
    const year = this.currentYear();
    this.planningLoading.set(true);
    this.planningEntries.set([]);
    this.importStatus.set(null);
    this.planningService.getEntries(month + 1, year).subscribe({
      next: entries => {
        if (month !== this.currentMonth() || year !== this.currentYear()) return;
        this.planningEntries.set(entries);
        this.planningLoading.set(false);
      },
      error: err => {
        if (month !== this.currentMonth() || year !== this.currentYear()) return;
        this.importStatus.set({ message: err.message, error: true });
        this.planningLoading.set(false);
      },
    });
    this.uploadStatusLoading.set(true);
    this.planningService.getUploadStatus(month + 1, year).subscribe({
      next: status => {
        if (month !== this.currentMonth() || year !== this.currentYear()) return;
        this.uploadStatus.set(status);
        this.uploadStatusLoading.set(false);
      },
      error: err => {
        if (month !== this.currentMonth() || year !== this.currentYear()) return;
        this.importStatus.set({ message: err.message, error: true });
        this.uploadStatusLoading.set(false);
      },
    });
  }

  startEditing(entry: PlanningEntry): void {
    if (!this.perms.canView('planner')) return;
    this.editDraft.set({ ...entry });
  }

  updateEditField(field: keyof PlanningEntry, value: string | number): void {
    if (!this.perms.canEdit('planner')) return;
    this.editDraft.update(draft => draft ? { ...draft, [field]: value } : draft);
  }

  cancelEditing(): void {
    if (!this.savingEntry()) this.editDraft.set(null);
  }

  saveEntry(): void {
    const draft = this.editDraft();
    if (!draft || !this.perms.canEdit('planner') || this.savingEntry()) return;

    this.savingEntry.set(true);
    this.importStatus.set(null);
    this.planningService.updateEntry(draft, this.currentMonth() + 1, this.currentYear()).subscribe({
      next: updated => {
        this.planningEntries.update(entries => entries.map(entry => entry._id === updated._id ? updated : entry));
        this.editDraft.set(null);
        this.savingEntry.set(false);
        this.importStatus.set({ message: 'Planning details saved.', error: false });
      },
      error: err => {
        this.importStatus.set({ message: err.message, error: true });
        this.savingEntry.set(false);
      },
    });
  }

  onWorkbookSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;

    if (!/\.xlsx$/i.test(file.name)) {
      this.importStatus.set({ message: 'Choose an .xlsx workbook.', error: true });
      return;
    }

    this.importing.set(true);
    this.importStatus.set(null);
    this.planningService.importWorkbook(file, this.currentMonth() + 1, this.currentYear()).subscribe({
      next: response => {
        this.planningEntries.set(response.data);
        this.uploadStatus.set(response.upload);
        this.loadPlanningEntries();
        this.importStatus.set({
          message: `${response.importedCount} content plan${response.importedCount === 1 ? '' : 's'} uploaded for ${this.monthLabel}.`,
          error: false,
        });
        this.importing.set(false);
      },
      error: err => {
        this.importStatus.set({ message: err.message, error: true });
        this.importing.set(false);
      },
    });
  }

  deleteWorkbook(): void {
    if (this.deletingMonth()) return;
    if (!confirm(`Delete all ${this.monthLabel} planning details and uploaded workbooks for all users?`)) return;

    this.deletingMonth.set(true);
    this.importStatus.set(null);
    this.planningService.deleteWorkbook(this.currentMonth() + 1, this.currentYear()).subscribe({
      next: status => {
        this.uploadStatus.set({ ...status, importedCount: 0 });
        this.deletingMonth.set(false);
        this.loadPlanningEntries();
        this.importStatus.set({ message: `All ${this.monthLabel} planning details were deleted. You can now upload a replacement.`, error: false });
      },
      error: err => {
        this.importStatus.set({ message: err.message, error: true });
        this.deletingMonth.set(false);
      },
    });
  }

  deleteMonthDetails(): void {
    if (this.planningEntries().length > 0 || this.uploadStatus().isUploaded) this.deleteWorkbook();
  }
}
