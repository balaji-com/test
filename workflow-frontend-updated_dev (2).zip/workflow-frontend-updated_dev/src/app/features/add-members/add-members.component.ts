import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgIf, NgFor, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import {
  UserService, Member, CreateMemberPayload, UpdateMemberPayload,
  AccessLevel, ModuleKey, Permissions
} from '../../core/services/user.service';

interface Toast { msg: string; type: 'success' | 'error'; }
interface ColorOption { hex: string; label: string; }

// Module groups matching the screenshots
const MODULE_GROUPS: { label: string; modules: { key: ModuleKey; label: string }[] }[] = [
  {
    label: 'Workspace',
    modules: [
      { key: 'my_tasks',   label: 'My Tasks'        },
      { key: 'all_works',  label: 'All Works'        },
      { key: 'reminders',  label: 'Reminders'        },
      { key: 'kanban',     label: 'Workflow Board'   },
      { key: 'approvals',  label: 'Approvals'        },
    ]
  },
  {
    label: 'Calendar',
    modules: [
      { key: 'calendar', label: 'My Tasks Calendar' },
      { key: 'planner',  label: 'Planning Calendar' },
    ]
  },
  {
    label: 'Analytics',
    modules: [
      { key: 'team_overview',   label: 'Team Overview'   },
      { key: 'monthly_reports', label: 'Monthly Reports' },
    ]
  },
  {
    label: 'SEO Tools',
    modules: [
      { key: 'seo_checker',    label: 'SEO Blog Checker'    },
      { key: 'topic_selector', label: 'Blog Topic Selector' },
    ]
  },
  {
    label: 'Settings',
    modules: [
      { key: 'ai_configuration', label: 'AI Configuration' },
      { key: 'customize_fields', label: 'Customize Fields' },
      { key: 'add_members',      label: 'Add Members'      },
      { key: 'audit_log',        label: 'Audit Log'        },
      { key: 'backup',           label: 'Backup & Restore' },
      { key: 'change_password',  label: 'Change Password'  },
    ]
  }
];

// Default permissions when role = member
const MEMBER_DEFAULTS: Partial<Permissions> = {
  my_tasks: 'editor', all_works: 'editor', reminders: 'editor',
  kanban: 'editor', approvals: 'editor', calendar: 'editor',
  planner: 'no_access', team_overview: 'no_access', monthly_reports: 'no_access',
  seo_checker: 'no_access', topic_selector: 'no_access',
  ai_configuration: 'no_access', customize_fields: 'no_access',
  add_members: 'no_access', audit_log: 'no_access',
  backup: 'no_access', change_password: 'editor',
};

const ACCESS_OPTIONS: { value: AccessLevel; label: string }[] = [
  { value: 'no_access', label: 'No Access' },
  { value: 'viewer',    label: 'Viewer'    },
  { value: 'editor',    label: 'Editor'    },
  { value: 'admin',     label: 'Admin'     },
];

@Component({
  selector: 'app-add-members',
  standalone: true,
  imports: [NgIf, NgFor, NgClass, FormsModule],
  templateUrl: './add-members.component.html',
  styleUrl: './add-members.component.css'
})
export class AddMembersComponent implements OnInit {
  readonly auth        = inject(AuthService);
  private readonly svc = inject(UserService);

  // ── Signals ──────────────────────────────────────────────────────
  members   = signal<Member[]>([]);
  loading   = signal(true);
  saving    = signal(false);
  deleting  = signal<string | null>(null);
  showForm  = signal(false);
  toast     = signal<Toast | null>(null);
  formError = signal('');
  editingId = signal<string | null>(null);

  // ── Form fields ───────────────────────────────────────────────────
  name     = '';
  email    = '';
  password = '';
  showPwd  = false;
  role: 'admin' | 'member' | 'viewer' = 'member';
  isAdmin  = false;
  color    = '#c8890a';

  // Per-module permissions draft (used when role = member or viewer)
  permDraft: Partial<Permissions> = { ...MEMBER_DEFAULTS };

  // ── Computed ──────────────────────────────────────────────────────
  activeCount   = computed(() => this.members().filter((m: Member) =>  m.isActive).length);
  inactiveCount = computed(() => this.members().filter((m: Member) => !m.isActive).length);
  adminCount    = computed(() => this.members().filter((m: Member) =>  m.isAdmin).length);
  isEditing     = computed(() => !!this.editingId());
  showPermGrid  = computed(() => this.role === 'member' || this.role === 'viewer');

  // Expose to template
  readonly MODULE_GROUPS  = MODULE_GROUPS;
  readonly ACCESS_OPTIONS = ACCESS_OPTIONS;

  readonly COLOR_OPTIONS: ColorOption[] = [
    { hex: '#c8890a', label: 'Gold'   }, { hex: '#0aab78', label: 'Green'  },
    { hex: '#6336d6', label: 'Purple' }, { hex: '#0887b0', label: 'Teal'   },
    { hex: '#d43b3b', label: 'Red'    }, { hex: '#2d52e6', label: 'Blue'   },
    { hex: '#e8720c', label: 'Orange' }, { hex: '#1a1d2e', label: 'Dark'   },
  ];

  // ── Lifecycle ─────────────────────────────────────────────────────
  ngOnInit(): void { this.loadMembers(); }

  loadMembers(): void {
    this.loading.set(true);
    this.svc.getUsers().subscribe({
      next:  (users: Member[]) => { this.members.set(users); this.loading.set(false); },
      error: (err: Error)      => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  // ── Open add form ─────────────────────────────────────────────────
  openAdd(): void {
    this.resetForm();
    this.editingId.set(null);
    this.showForm.set(true);
  }

  // ── Open edit form ────────────────────────────────────────────────
  openEdit(m: Member): void {
    this.name    = m.name;
    this.email   = m.email;
    this.password = '';
    this.showPwd  = false;
    this.role     = m.role;
    this.isAdmin  = m.isAdmin;
    this.color    = m.color || '#c8890a';
    // Load existing permissions into draft
    this.permDraft = m.permissions
      ? { ...(m.permissions as Partial<Permissions>) }
      : { ...MEMBER_DEFAULTS };
    this.formError.set('');
    this.editingId.set(m._id);
    this.showForm.set(true);
    // Scroll form into view
    setTimeout(() => document.querySelector('.member-form')?.scrollIntoView({ behavior: 'smooth' }), 50);
  }

  cancelForm(): void {
    this.showForm.set(false);
    this.editingId.set(null);
    this.resetForm();
  }

  // ── When role changes, reset permissions to appropriate defaults ───
  onRoleChange(): void {
    this.isAdmin = this.role === 'admin';
    if (this.role === 'member') {
      this.permDraft = { ...MEMBER_DEFAULTS };
    } else if (this.role === 'viewer') {
      // Viewer: everything no_access except change_password = viewer
      const draft: Partial<Permissions> = {};
      MODULE_GROUPS.forEach(g => g.modules.forEach(m => { draft[m.key] = 'no_access'; }));
      draft['change_password'] = 'viewer';
      this.permDraft = draft;
    }
  }

  // ── Get/set individual module permission ──────────────────────────
  getPerm(key: ModuleKey): AccessLevel {
    return (this.permDraft[key] as AccessLevel) || 'no_access';
  }

  setPerm(key: ModuleKey, val: AccessLevel): void {
    this.permDraft = { ...this.permDraft, [key]: val };
  }

  // ── Submit: Create or Update ──────────────────────────────────────
  submit(): void {
    this.formError.set('');
    if (!this.name.trim())                          { this.formError.set('Full name is required.'); return; }
    if (!this.email.trim())                         { this.formError.set('Email is required.'); return; }
    if (!/\S+@\S+\.\S+/.test(this.email))          { this.formError.set('Enter a valid email.'); return; }
    if (!this.role)                                 { this.formError.set('Role is required.'); return; }
    if (!this.isEditing() && !this.password)        { this.formError.set('Password is required.'); return; }
    if (this.password && this.password.length < 4)  { this.formError.set('Password must be ≥ 4 chars.'); return; }

    this.saving.set(true);
    this.isEditing() ? this.updateMember() : this.createMember();
  }

  private createMember(): void {
    const payload: CreateMemberPayload = {
      name:        this.name.trim(),
      email:       this.email.trim().toLowerCase(),
      password:    this.password,
      role:        this.role,
      color:       this.color,
      permissions: this.showPermGrid() ? { ...this.permDraft } as Permissions : undefined,
    };
    this.svc.createUser(payload).subscribe({
      next: (m: Member) => {
        this.members.update((ms: Member[]) => [m, ...ms]);
        this.saving.set(false);
        this.showForm.set(false);
        this.resetForm();
        this.showToast(`✓ ${m.name} added successfully!`, 'success');
      },
      error: (err: Error) => { this.saving.set(false); this.formError.set(err.message); }
    });
  }

  private updateMember(): void {
    const id = this.editingId()!;
    const payload: UpdateMemberPayload = {
      name:        this.name.trim(),
      email:       this.email.trim().toLowerCase(),
      role:        this.role,
      color:       this.color,
      isActive:    true,
      permissions: this.showPermGrid() ? { ...this.permDraft } as Permissions : undefined,
    };
    if (this.password) payload.password = this.password;

    this.svc.updateUser(id, payload).subscribe({
      next: (updated: Member) => {
        this.members.update((ms: Member[]) => ms.map((m: Member) => m._id === id ? updated : m));
        this.saving.set(false);
        this.showForm.set(false);
        this.editingId.set(null);
        this.resetForm();
        this.showToast(`✓ ${updated.name} updated successfully!`, 'success');
      },
      error: (err: Error) => { this.saving.set(false); this.formError.set(err.message); }
    });
  }

  // ── Toggle active / inactive ──────────────────────────────────────
  toggleActive(m: Member): void {
    if (this.isCurrentUser(m) && m.isActive) {
      this.showToast('You cannot deactivate your own account.', 'error');
      return;
    }
    this.svc.toggleActive(m._id, !m.isActive).subscribe({
      next: (u: Member) => {
        this.members.update((ms: Member[]) => ms.map((x: Member) => x._id === m._id ? u : x));
        this.showToast(`${u.name} ${u.isActive ? 'activated' : 'deactivated'}.`, 'success');
      },
      error: (err: Error) => this.showToast(err.message, 'error')
    });
  }

  // ── DELETE ────────────────────────────────────────────────────────
  remove(m: Member): void {
    if (this.isCurrentUser(m)) return;
    if (!confirm(`Remove ${m.name}? This deactivates the account.`)) return;
    this.deleting.set(m._id);
    this.svc.deleteUser(m._id).subscribe({
      next: () => {
        this.members.update((ms: Member[]) => ms.filter((x: Member) => x._id !== m._id));
        this.deleting.set(null);
        this.showToast(`${m.name} removed.`, 'success');
      },
      error: (err: Error) => { this.deleting.set(null); this.showToast(err.message, 'error'); }
    });
  }

  // ── Helpers ───────────────────────────────────────────────────────
  initials(name: string): string {
    return name.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase();
  }

  getPermLabel(m: Member, key: ModuleKey): string {
    if (m.isAdmin) return 'Admin';
    const val = m.permissions?.[key] || 'no_access';
    return ACCESS_OPTIONS.find(o => o.value === val)?.label || 'No Access';
  }

  getPermClass(level: AccessLevel | string): string {
    const map: Record<string, string> = {
      no_access: 'lvl-none', viewer: 'lvl-view', editor: 'lvl-edit', admin: 'lvl-admin'
    };
    return map[level] || 'lvl-none';
  }

  isCurrentUser(m: Member): boolean {
    return m._id === this.auth.currentUser()?._id;
  }

  private resetForm(): void {
    this.name = ''; this.email = ''; this.password = '';
    this.showPwd = false; this.role = 'member';
    this.isAdmin = false; this.color = '#c8890a';
    this.permDraft = { ...MEMBER_DEFAULTS };
    this.formError.set('');
  }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
