import { Component, inject, signal } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskDropdownOptions, DEFAULT_TASK_DROPDOWN_OPTIONS } from '../../core/models/task-dropdown-options.model';
import { TaskDropdownOptionsService } from '../../core/services/task-dropdown-options.service';
import { PermissionsService } from '../../core/services/permissions.service';

type OptionListField = 'functions' | 'briefingsheets' | 'years' | 'statuses';

@Component({
  selector: 'app-customize-fields',
  standalone: true,
  imports: [NgIf, NgFor, FormsModule],
  templateUrl: './customize-fields.component.html',
  styleUrl: './customize-fields.component.css',
})
export class CustomizeFieldsComponent {
  private readonly optionsService = inject(TaskDropdownOptionsService);
  readonly perms = inject(PermissionsService);
  options = signal<TaskDropdownOptions>(structuredClone(DEFAULT_TASK_DROPDOWN_OPTIONS));
  loading = signal(true);
  saving = signal(false);
  saved = signal(false);
  error = signal('');
  newValues = signal<Record<string, string>>({});

  readonly optionLists: { key: OptionListField; label: string }[] = [
    { key: 'functions', label: 'Function' },
    { key: 'briefingsheets', label: 'Briefing Sheet' },
    { key: 'years', label: 'Year' },
    { key: 'statuses', label: 'Status' },
  ];

  constructor() {
    this.optionsService.getOptions().subscribe({
      next: options => { this.options.set(options); this.loading.set(false); },
      error: err => { this.error.set(err.message); this.loading.set(false); },
    });
  }

  categoryNames(): string[] { return Object.keys(this.options().categories); }

  setNewValue(key: string, value: string): void {
    this.newValues.update(values => ({ ...values, [key]: value }));
  }

  addOption(field: OptionListField): void {
    const value = (this.newValues()[field] || '').trim();
    if (!value) return;
    const current = this.options()[field];
    if (current.some(item => item.toLowerCase() === value.toLowerCase())) {
      this.error.set(`"${value}" already exists in ${field}.`);
      return;
    }
    this.options.update(options => ({ ...options, [field]: [...options[field], value] }));
    this.newValues.update(values => ({ ...values, [field]: '' }));
    this.error.set('');
  }

  removeOption(field: OptionListField, value: string): void {
    if (this.options()[field].length <= 1) {
      this.error.set(`At least one ${field} value must remain.`);
      return;
    }
    if (!confirm(`Delete "${value}" from ${field}?`)) return;
    this.options.update(options => ({ ...options, [field]: options[field].filter(item => item !== value) }));
    this.error.set('');
  }

  addCategory(): void {
    const value = (this.newValues()['category'] || '').trim();
    if (!value) return;
    if (this.categoryNames().some(item => item.toLowerCase() === value.toLowerCase())) {
      this.error.set(`Category "${value}" already exists.`);
      return;
    }
    this.options.update(options => ({ ...options, categories: { ...options.categories, [value]: [] } }));
    this.newValues.update(values => ({ ...values, category: '' }));
    this.error.set('');
  }

  removeCategory(category: string): void {
    const categories = { ...this.options().categories };
    delete categories[category];
    if (Object.keys(categories).length === 0) {
      this.error.set('At least one category must remain.');
      return;
    }
    if (!confirm(`Delete category "${category}" and its sub-categories?`)) return;
    this.options.update(options => ({ ...options, categories }));
  }

  addSubCategory(category: string): void {
    const key = `subcategory:${category}`;
    const value = (this.newValues()[key] || '').trim();
    if (!value) return;
    const current = this.options().categories[category] || [];
    if (current.some(item => item.toLowerCase() === value.toLowerCase())) {
      this.error.set(`Sub-category "${value}" already exists in ${category}.`);
      return;
    }
    this.options.update(options => ({
      ...options,
      categories: { ...options.categories, [category]: [...current, value] },
    }));
    this.newValues.update(values => ({ ...values, [key]: '' }));
    this.error.set('');
  }

  removeSubCategory(category: string, value: string): void {
    if (!confirm(`Delete sub-category "${value}" from "${category}"?`)) return;
    this.options.update(options => ({
      ...options,
      categories: {
        ...options.categories,
        [category]: options.categories[category].filter(item => item !== value),
      },
    }));
  }

  save(): void {
    if (!this.perms.canEdit('customize_fields') || this.saving()) return;
    this.saving.set(true);
    this.error.set('');
    this.saved.set(false);
    this.optionsService.saveOptions(this.options()).subscribe({
      next: options => {
        this.options.set(options);
        this.saving.set(false);
        this.saved.set(true);
        setTimeout(() => this.saved.set(false), 2500);
      },
      error: err => { this.error.set(err.message); this.saving.set(false); },
    });
  }
}
