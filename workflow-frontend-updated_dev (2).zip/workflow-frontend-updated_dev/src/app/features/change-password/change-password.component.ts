import { Component, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppStateService } from '../../core/services/app-state.service';
@Component({ selector:'app-change-password', standalone:true, imports:[NgIf,FormsModule],
  templateUrl:'./change-password.component.html', styleUrl:'./change-password.component.css' })
export class ChangePasswordComponent {
  readonly state = inject(AppStateService);
  current=''; newPwd=''; confirm='';
  error=signal(''); success=signal('');
  submit(){
    this.error.set(''); this.success.set('');
    if(!this.current||!this.newPwd||!this.confirm){this.error.set('All fields are required.');return;}
    if(this.newPwd.length<4){this.error.set('New password must be at least 4 characters.');return;}
    if(this.newPwd!==this.confirm){this.error.set('Passwords do not match.');return;}
    this.success.set('Password updated successfully!');
    this.current=''; this.newPwd=''; this.confirm='';
  }
}
