import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskService } from '../../core/services/task.service';
import { UserService, Member } from '../../core/services/user.service';
import { AuthService } from '../../core/services/auth.service';
import { PermissionsService } from '../../core/services/permissions.service';
import { Task, TaskStatus, TaskPriority, assignedToId, assignedToName } from '../../core/models/task.model';

interface Toast { msg: string; type: 'success' | 'error' | 'info'; }

const COLUMNS: TaskStatus[] = ['Not Started', 'In Progress', 'In Review', 'Completed'];

const COL_META: Record<TaskStatus, { cls: string; icon: string; accent: string }> = {
  'Not Started': { cls: 'col-ns',       icon: '○',  accent: 'var(--text3)'   },
  'In Progress': { cls: 'col-progress', icon: '⚡', accent: 'var(--teal)'    },
  'In Review':   { cls: 'col-review',   icon: '👁', accent: 'var(--purple)'  },
  'Completed':   { cls: 'col-done',     icon: '✓',  accent: 'var(--green)'   },
};

const MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December'];
const YEARS  = ['2024','2025','2026','2027'];
const PRIORITIES: TaskPriority[] = ['High','Medium','Low'];

@Component({
  selector: 'app-kanban',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule],
  templateUrl: './kanban.component.html',
  styleUrl: './kanban.component.css'
})
export class KanbanComponent implements OnInit {
  private readonly svc     = inject(TaskService);
  private readonly userSvc = inject(UserService);
  private readonly auth    = inject(AuthService);
  readonly perms           = inject(PermissionsService);

  readonly canEdit  = computed(() => this.perms.canEdit('kanban'));
  readonly isAdmin  = computed(() => this.auth.isAdmin());

  // ── Data ─────────────────────────────────────────────────────────
  tasks   = signal<Task[]>([]);
  members = signal<Member[]>([]);
  loading = signal(true);
  toast   = signal<Toast | null>(null);

  // ── Filters (all sent to backend) ─────────────────────────────────
  filterSearch   = signal('');
  filterMember   = signal('');
  filterPriority = signal('');
  filterMonth    = signal('');
  filterYear     = signal('');

  // ── Board constants ───────────────────────────────────────────────
  readonly COLUMNS   = COLUMNS;
  readonly COL_META  = COL_META;
  readonly MONTHS    = MONTHS;
  readonly YEARS     = YEARS;
  readonly PRIORITIES = PRIORITIES;

  // ── Total count per column ────────────────────────────────────────
  readonly colCounts = computed(() => {
    const tasks = this.tasks();
    const result: Record<string, number> = {};
    for (const col of COLUMNS) result[col] = tasks.filter(t => t.status === col).length;
    return result;
  });

  readonly totalShown = computed(() => this.tasks().length);

  // ── Tasks per column (already filtered by backend) ────────────────
  columnTasks(col: TaskStatus): Task[] {
    return this.tasks().filter(t => t.status === col);
  }

  // ── Drag state ────────────────────────────────────────────────────
  dragTaskId    = signal<string | null>(null);
  dragOverCol   = signal<TaskStatus | null>(null);
  savingTaskId  = signal<string | null>(null);   // shows spinner on card being updated

  private searchDebounce: ReturnType<typeof setTimeout> | null = null;

  ngOnInit(): void { this.loadMembers(); this.loadTasks(); }

  // ── Load from backend with all active filters ─────────────────────
  loadTasks(): void {
    this.loading.set(true);
    this.svc.getTasks({
      search:     this.filterSearch()   || undefined,
      assignedTo: this.filterMember()   || undefined,
      priority:   (this.filterPriority() as any) || undefined,
      month:      this.filterMonth()    || undefined,
      year:       this.filterYear()     || undefined,
      limit:      500 as any,           // no pagination on kanban — get all in one shot
      // page:       1 as any,
    }).subscribe({
      next:  (tasks: Task[]) => { this.tasks.set(tasks); this.loading.set(false); },
      error: (err: Error)    => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  loadMembers(): void {
    this.userSvc.getUsers().subscribe({
      next:  (users: Member[]) => this.members.set(users),
      error: () => {}
    });
  }

  // ── Filter change handlers ─────────────────────────────────────────
  onSearchInput(value: string): void {
    this.filterSearch.set(value);
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.searchDebounce = setTimeout(() => this.loadTasks(), 350);
  }

  onFilterChange(): void { this.loadTasks(); }

  clearFilters(): void {
    this.filterSearch.set('');
    this.filterMember.set('');
    this.filterPriority.set('');
    this.filterMonth.set('');
    this.filterYear.set('');
    this.loadTasks();
  }

  readonly hasActiveFilter = computed(() =>
    !!(this.filterSearch() || this.filterMember() || this.filterPriority() ||
       this.filterMonth() || this.filterYear())
  );

  // ── Drag & drop ───────────────────────────────────────────────────
  onDragStart(taskId: string, event: DragEvent): void {
    if (!this.canEdit()) { event.preventDefault(); return; }
    this.dragTaskId.set(taskId);
    event.dataTransfer?.setData('text/plain', taskId);
  }

  onDragOver(col: TaskStatus, event: DragEvent): void {
    if (!this.canEdit()) return;
    event.preventDefault();
    this.dragOverCol.set(col);
  }

  onDragLeave(event: DragEvent): void {
    // Only clear if leaving the column entirely (not entering a child element)
    const rel = event.relatedTarget as HTMLElement | null;
    if (!rel || !(event.currentTarget as HTMLElement).contains(rel)) {
      this.dragOverCol.set(null);
    }
  }

  onDragEnd(): void {
    this.dragTaskId.set(null);
    this.dragOverCol.set(null);
  }

  onDrop(col: TaskStatus, event: DragEvent): void {
    event.preventDefault();
    this.dragOverCol.set(null);
    if (!this.canEdit()) return;

    const id = this.dragTaskId();
    this.dragTaskId.set(null);
    if (!id) return;

    const task = this.tasks().find(t => t._id === id);
    if (!task || task.status === col) return;

    // Optimistic update
    const prev = task.status;
    this.tasks.update(ts => ts.map(t => t._id === id ? { ...t, status: col } : t));
    this.savingTaskId.set(id);

    this.svc.updateTask(id, { status: col }).subscribe({
      next: (updated: Task) => {
        this.tasks.update(ts => ts.map(t => t._id === updated._id ? updated : t));
        this.savingTaskId.set(null);
        this.showToast(`"${updated.task}" moved to ${col}`, 'success');
      },
      error: (err: Error) => {
        // Roll back
        this.tasks.update(ts => ts.map(t => t._id === id ? { ...t, status: prev } : t));
        this.savingTaskId.set(null);
        this.showToast(err.message, 'error');
      }
    });
  }

  // ── Card detail popup ─────────────────────────────────────────────
  detailTask    = signal<Task | null>(null);
  detailEdit    = signal<Partial<Task>>({});
  detailSaving  = signal(false);
  detailError   = signal('');

  readonly STATUS_OPTIONS: TaskStatus[] = COLUMNS;

  openDetail(t: Task, event: MouseEvent): void {
    // Don't open while dragging
    if (this.dragTaskId()) return;
    event.stopPropagation();
    this.detailTask.set(t);
    this.detailEdit.set({
      task:     t.task,
      status:   t.status,
      priority: t.priority,
      dueDate:  t.dueDate,
      startDate:t.startDate,
      estHrs:   t.estHrs,
      actHrs:   t.actHrs,
      rework:   t.rework,
      notes:    t.notes,
      month:    t.month,
      year:     t.year,
    });
    this.detailError.set('');
    this.detailSaving.set(false);
    document.body.style.overflow = 'hidden';
  }

  closeDetail(): void {
    this.detailTask.set(null);
    document.body.style.overflow = '';
  }

  patchDetail(field: keyof Task, value: any): void {
    this.detailEdit.update(e => ({ ...e, [field]: value }));
  }

  saveDetail(): void {
    const task = this.detailTask();
    if (!task || this.detailSaving()) return;
    this.detailError.set('');
    this.detailSaving.set(true);

    this.svc.updateTask(task._id, this.detailEdit()).subscribe({
      next: (updated: Task) => {
        this.tasks.update(ts => ts.map(t => t._id === updated._id ? updated : t));
        this.detailTask.set(updated);
        this.detailSaving.set(false);
        this.showToast(`"${updated.task}" updated.`, 'success');
      },
      error: (err: Error) => {
        this.detailError.set(err.message);
        this.detailSaving.set(false);
      }
    });
  }

  // ── Member display helpers ────────────────────────────────────────
  taskMemberName(t: Task): string {
    const name = assignedToName(t);
    if (name !== '—') return name;
    return this.members().find(m => m._id === assignedToId(t))?.name || 'Unassigned';
  }

  taskMemberColor(t: Task): string {
    if (typeof t.assignedTo === 'object' && t.assignedTo?.color) return t.assignedTo.color;
    return this.members().find(m => m._id === assignedToId(t))?.color || '#c8890a';
  }

  taskInitials(t: Task): string {
    return this.taskMemberName(t).split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'UN';
  }

  colAccent(col: TaskStatus): string { return COL_META[col].accent; }
  colIcon(col: TaskStatus): string   { return COL_META[col].icon; }
  colCls(col: TaskStatus): string    { return COL_META[col].cls; }

  isDropTarget(col: TaskStatus): boolean {
    return this.dragOverCol() === col && this.dragTaskId() !== null;
  }

  isSaving(taskId: string): boolean { return this.savingTaskId() === taskId; }
  isDragging(taskId: string): boolean { return this.dragTaskId() === taskId; }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error' | 'info'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
