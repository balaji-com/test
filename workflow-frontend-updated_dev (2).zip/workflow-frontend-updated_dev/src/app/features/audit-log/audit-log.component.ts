import { Component, inject, signal, computed } from '@angular/core';
import { NgClass, NgFor, NgIf, KeyValuePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppStateService } from '../../core/services/app-state.service';

export interface AuditEntry {
  id: number; ts: string; user: string; action: string;
  taskName: string; assignedTo: string;
  changes?: Record<string, [string, string]>;
  _undone?: boolean;
}

@Component({
  selector: 'app-audit-log', standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule, KeyValuePipe],
  templateUrl: './audit-log.component.html', styleUrl: './audit-log.component.css'
})
export class AuditLogComponent {
  readonly state = inject(AppStateService);
  filterAction = signal('');
  filterSearch = signal('');
  page = signal(1);
  PAGE_SIZE = 25;
  readonly log = signal<AuditEntry[]>([]);

  readonly filtered = computed(() => {
    let l = this.log();
    if (this.filterAction()) l = l.filter(e => e.action === this.filterAction());
    const q = this.filterSearch().toLowerCase();
    if (q) l = l.filter(e => (e.taskName + e.user + e.assignedTo).toLowerCase().includes(q));
    return l;
  });

  readonly paged = computed(() => {
    const p = this.page(), f = this.filtered();
    return f.slice((p - 1) * this.PAGE_SIZE, p * this.PAGE_SIZE);
  });

  get pageCount(): number { return Math.max(1, Math.ceil(this.filtered().length / this.PAGE_SIZE)); }

  prevPage(): void { this.page.update(p => p - 1); }
  nextPage(): void { this.page.update(p => p + 1); }
  onFilterAction(val: string): void { this.filterAction.set(val); this.page.set(1); }
  onFilterSearch(val: string): void { this.filterSearch.set(val); this.page.set(1); }

  fmtTs(iso: string): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
      + ' ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  }

  actionBadgeClass(a: string): string {
    const m: Record<string, string> = {
      'created': 'badge-created', 'edited': 'badge-edited',
      'completed': 'badge-done', 'deleted': 'badge-del',
      'status-changed': 'badge-status', 'bulk-completed': 'badge-bulk', 'bulk-deleted': 'badge-bulk'
    };
    return m[a] || 'badge-status';
  }

  actionLabel(a: string): string {
    const m: Record<string, string> = {
      'created': '✦ Created', 'edited': '✎ Edited',
      'completed': '✓ Completed', 'deleted': '✕ Deleted',
      'status-changed': '⇄ Status', 'bulk-completed': '⊛ Bulk Done', 'bulk-deleted': '⊛ Bulk Del'
    };
    return m[a] || a;
  }

  initials(n: string): string {
    return (n || '').split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase() || '??';
  }

  clearLog(): void { if (confirm('Clear all audit entries?')) this.log.set([]); }
}
