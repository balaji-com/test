import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgIf } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, NgIf],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private readonly auth   = inject(AuthService);
  private readonly router = inject(Router);

  email    = '';
  password = '';
  showPassword = signal(false);
  error    = signal('');
  loading  = signal(false);

  login(): void {
    this.error.set('');

    if (!this.email.trim()) { this.error.set('Email is required.'); return; }
    if (!/\S+@\S+\.\S+/.test(this.email)) { this.error.set('Enter a valid email address.'); return; }
    if (!this.password)     { this.error.set('Password is required.'); return; }

    this.loading.set(true);

    this.auth.login({ email: this.email.trim().toLowerCase(), password: this.password })
      .subscribe({
        next: () => {
          this.loading.set(false);
          this.router.navigate(['/my-tasks']);
        },
        error: (err: Error) => {
          this.loading.set(false);
          this.error.set(err.message || 'Login failed. Please try again.');
        }
      });
  }

  togglePassword(): void { this.showPassword.update(v => !v); }

  onKeyEnter(e: KeyboardEvent): void {
    if (e.key === 'Enter') this.login();
  }
}
