import {
  HttpInterceptorFn, HttpErrorResponse,
  HttpRequest, HttpHandlerFn
} from '@angular/common/http';
import { inject } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, filter, switchMap, take } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';

// ── Module-level refresh queue ─────────────────────────────────────
// Shared across all interceptor invocations so that when multiple
// requests fire simultaneously and all get 401s, only ONE refresh
// call is made. All other 401 requests queue on the BehaviorSubject
// and retry with the new token once it arrives.
let isRefreshing = false;
const newToken$  = new BehaviorSubject<string | null>(null);

// Auth endpoints that must never get the Bearer header injected
// or be intercepted for refresh.
const AUTH_URLS = ['/auth/login', '/auth/register', '/auth/refresh', '/auth/logout'];
const isAuthUrl = (url: string) => AUTH_URLS.some(u => url.includes(u));

const cloneWithToken = (req: HttpRequest<unknown>, token: string) =>
  req.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
    withCredentials: true,
  });

/** Queue this request until the current refresh completes, then retry. */
const waitForRefreshAndRetry = (
  req:  HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<any> =>
  newToken$.pipe(
    filter((t): t is string => t !== null),   // unblocks when new token is set
    take(1),
    switchMap(token => next(cloneWithToken(req, token)))
  );

/** Start a refresh, queue all other 401s, retry all when done. */
const refreshAndRetry = (
  req:  HttpRequest<unknown>,
  next: HttpHandlerFn,
  auth: AuthService
): Observable<any> => {
  isRefreshing = true;
  newToken$.next(null);   // block the queue

  return auth.refreshToken().pipe(
    switchMap(res => {
      isRefreshing = false;
      newToken$.next(res.accessToken);     // unblock the queue
      return next(cloneWithToken(req, res.accessToken));
    }),
    catchError(err => {
      // Refresh token is expired / revoked — force logout WITHOUT
      // calling the backend (that would cause another 401).
      isRefreshing = false;
      newToken$.next(null);
      auth.forceLogout();
      return throwError(() => err);
    })
  );
};

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth  = inject(AuthService);
  const token = auth.getToken();

  // Always send withCredentials so the httpOnly refresh-token cookie
  // is included on the /refresh call.
  const authReq = (token && !isAuthUrl(req.url))
    ? cloneWithToken(req, token)
    : req.clone({ withCredentials: true });

  return next(authReq).pipe(
    catchError((err: HttpErrorResponse) => {
      // Only handle 401 on protected routes
      if (err.status !== 401 || isAuthUrl(req.url)) {
        return throwError(() => err);
      }

      if (isRefreshing) {
        // Another refresh is already running — join the queue
        return waitForRefreshAndRetry(req, next);
      }

      return refreshAndRetry(req, next, auth);
    })
  );
};
