import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { PermissionsService } from '../services/permissions.service';

/**
 * Route guard that checks the current user's module permission before
 * allowing navigation. Attach a `data: { moduleKey: 'kanban' }` to a route,
 * or rely on the path-based fallback in PermissionsService.ROUTE_MODULE_MAP.
 *
 * If the user's level for that module is 'no_access', redirect to
 * /my-tasks (or /login if that's also blocked, the authGuard already
 * handles the unauthenticated case upstream).
 */
export const permissionGuard: CanActivateFn = (route, state) => {
  const perms  = inject(PermissionsService);
  const router = inject(Router);

  const moduleKey = (route.data?.['moduleKey'] as string) || undefined;
  const allowed = moduleKey
    ? perms.canView(moduleKey as any)
    : perms.canViewRoute(state.url);

  if (allowed) return true;

  // Redirect somewhere safe — my-tasks if they can see it, else stay put on a 403-ish fallback
  return perms.canView('my_tasks')
    ? router.createUrlTree(['/my-tasks'])
    : router.createUrlTree(['/no-access']);
};
