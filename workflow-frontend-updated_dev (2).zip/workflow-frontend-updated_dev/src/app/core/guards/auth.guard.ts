import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { from, of } from 'rxjs';
import { switchMap, catchError, map } from 'rxjs/operators';

export const authGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  // Not logged in at all → login
  if (!auth.isLoggedIn()) {
    return router.createUrlTree(['/login']);
  }

  // Access token still valid → allow
  if (!auth.isAccessTokenExpired()) {
    return true;
  }

  // Access token expired — try a silent refresh using the httpOnly cookie.
  // If it succeeds, the interceptor already stored the new token.
  // If it fails, forceLogout() is called inside refreshToken's catchError.
  return from(auth.refreshToken()).pipe(
    map(() => true),
    catchError(() => of(router.createUrlTree(['/login'])))
  );
};
