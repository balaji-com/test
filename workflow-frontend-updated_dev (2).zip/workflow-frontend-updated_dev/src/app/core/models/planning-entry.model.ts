export interface PlanningEntry {
  _id: string;
  week?: number;
  publicationDate: string;
  contentTitle: string;
  offerings: string;
  segmentsIndustries: string;
  format: string;
  contentObjectives: string;
  contentPillars: string;
  targetAudience: string;
  channel: string;
  kpi: string;
  assignedTo: string;
  submissionDueDate: string;
  submissionActualDate: string;
  reviewer: string;
  reviewDueDate: string;
  reviewActualDate: string;
  depositoryLink: string;
  postedLink: string;
  status: string;
  importBatchId: string;
  sourceFileName: string;
  createdAt: string;
  updatedAt: string;
}

export interface PlanningImportResponse {
  status: string;
  importedCount: number;
  importBatchId: string;
  upload: PlanningUploadStatus;
  data: PlanningEntry[];
}

export interface PlanningUploadStatus {
  isUploaded: boolean;
  fileName: string;
  importedCount: number;
  uploadedAt?: string | null;
}
