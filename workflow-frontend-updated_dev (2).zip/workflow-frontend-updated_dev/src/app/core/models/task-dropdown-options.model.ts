export interface TaskDropdownOptions {
  functions: string[];
  briefingsheets: string[];
  categories: Record<string, string[]>;
  months: string[];
  years: string[];
  statuses: string[];
}

export const DEFAULT_TASK_DROPDOWN_OPTIONS: TaskDropdownOptions = {
  functions: ['Social Media', 'Internal Communication', 'External Communication', 'Events'],
  briefingsheets: ['Given', 'NA', 'Not Given'],
  categories: {
    Content: ['Blog', 'Article', 'Whitepaper', 'Case Study', 'Brochure'],
    Design: ['Banner', 'Infographic', 'Flyer', 'Poster', 'Emailer'],
    Posting: ['LinkedIn', 'Twitter/X', 'Instagram', 'Facebook', 'YouTube'],
    Video: ['Reel', 'Short', 'Corporate Video', 'Webinar'],
    Newsletter: ['Internal', 'External', 'Product Update'],
    Copy: ['Event Page', 'Landing Page', 'Ad Copy', 'Script'],
    PR: ['Press Release', 'Media Note', 'Interview'],
    Campaign: ['Email Campaign', 'Social Campaign', 'SEO Campaign'],
    Reporting: ['Monthly Report', 'Weekly Report', 'Analytics'],
    Other: [],
  },
  months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  years: ['2024', '2025', '2026', '2027'],
  statuses: ['Not Started', 'In Progress', 'In Review', 'Completed'],
};
