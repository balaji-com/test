import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { TaskDropdownOptions } from '../models/task-dropdown-options.model';

@Injectable({ providedIn: 'root' })
export class TaskDropdownOptionsService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/task-dropdown-options`;

  getOptions(): Observable<TaskDropdownOptions> {
    return this.http.get<{ status: string; data: TaskDropdownOptions }>(this.base).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  saveOptions(options: TaskDropdownOptions): Observable<TaskDropdownOptions> {
    return this.http.put<{ status: string; data: TaskDropdownOptions }>(this.base, options).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const message = err.error?.message || err.error?.error ||
      (err.status === 0 ? 'Cannot reach the server.' : `Server error ${err.status}`);
    return throwError(() => new Error(message));
  }
}
