import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { Task, TaskPriority, TaskStatus } from '../models/task.model';

export interface MemberOverview {
  _id: string; name: string; email: string; color: string; role: string;
  total: number; done: number; inProg: number; inRev: number; notSt: number;
  rework: number; overdue: number; estHrs: string; actHrs: string; pct: number;
  byPriority: { High: number; Medium: number; Low: number };
}

export interface TeamTotals {
  total: number; done: number; inProg: number; rework: number;
  overdue: number; estHrs: string; actHrs: string; pct: number;
}

export interface TeamOverviewResponse {
  status: string; totals: TeamTotals; data: MemberOverview[];
}

export interface TeamOverviewTaskQuery {
  year?: string;
  month?: string;
  status?: TaskStatus;
  priority?: TaskPriority;
  assignedTo?: string;
  focus?: 'overdue' | 'rework';
  page?: number;
  limit?: number;
}

export interface TeamOverviewTaskResponse {
  status: string;
  total: number;
  page: number;
  limit: number;
  pages: number;
  data: Task[];
}

export interface MemberMonthly {
  uid: string; name: string; color: string;
  total: number; done: number; inProg: number;
  rework: number;
}

export interface CategoryBreakdown { cat: string; total: number; done: number; }

export interface ReportSummary {
  total: number; done: number; inProg: number; inRev: number; notSt: number;
  rework: number; highPri: number; overdue: number;
}

export interface MonthlyReportResponse {
  status: string; month: string; year: string;
  summary: ReportSummary;
  byMember: MemberMonthly[];
  byCategory: CategoryBreakdown[];
  tasks: {
    _id: string; task: string; assignedToId: string; assignedTo: string; status: string;
    priority: string; cat: string;
    rework: number; dueDate: string; brief: string;
  }[];
}

@Injectable({ providedIn: 'root' })
export class AnalyticsService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/analytics`;

  teamOverview(year?: string, month?: string): Observable<TeamOverviewResponse> {
    let params = new HttpParams();
    if (year)  params = params.set('year',  year);
    if (month) params = params.set('month', month);
    return this.http.get<TeamOverviewResponse>(`${this.base}/team-overview`, { params })
      .pipe(catchError(this.handleError));
  }

  teamOverviewTasks(query: TeamOverviewTaskQuery = {}): Observable<TeamOverviewTaskResponse> {
    let params = new HttpParams();
    Object.entries(query).forEach(([key, value]) => {
      if (value !== undefined && value !== '') params = params.set(key, String(value));
    });
    return this.http.get<TeamOverviewTaskResponse>(`${this.base}/team-overview/tasks`, { params })
      .pipe(catchError(this.handleError));
  }

  monthlyReport(month: string, year: string): Observable<MonthlyReportResponse> {
    const params = new HttpParams().set('month', month).set('year', year);
    return this.http.get<MonthlyReportResponse>(`${this.base}/monthly-report`, { params })
      .pipe(catchError(this.handleError));
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg = err.error?.message || err.error?.error ||
      (err.status === 0 ? 'Cannot reach server.' : `Server error ${err.status}`);
    return throwError(() => new Error(msg));
  }
}
