import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { PlanningEntry, PlanningImportResponse, PlanningUploadStatus } from '../models/planning-entry.model';

@Injectable({ providedIn: 'root' })
export class PlanningService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/planning`;

  getEntries(month: number, year: number): Observable<PlanningEntry[]> {
    const params = new HttpParams().set('month', String(month)).set('year', String(year));
    return this.http.get<{ status: string; total: number; data: PlanningEntry[] }>(
      this.base,
      { params }
    ).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  getUploadStatus(month: number, year: number): Observable<PlanningUploadStatus> {
    const params = new HttpParams().set('month', String(month)).set('year', String(year));
    return this.http.get<{ status: string; data: PlanningUploadStatus }>(
      `${this.base}/upload-status`,
      { params }
    ).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  importWorkbook(file: File, month: number, year: number): Observable<PlanningImportResponse> {
    const form = new FormData();
    form.append('file', file);
    form.append('month', String(month));
    form.append('year', String(year));
    return this.http.post<PlanningImportResponse>(`${this.base}/import`, form).pipe(
      catchError(this.handleError)
    );
  }

  deleteWorkbook(month: number, year: number): Observable<{ isUploaded: boolean; fileName: string }> {
    const params = new HttpParams().set('month', String(month)).set('year', String(year));
    return this.http.delete<{ status: string; data: { isUploaded: boolean; fileName: string } }>(
      `${this.base}/upload`,
      { params }
    ).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  updateEntry(entry: PlanningEntry, month: number, year: number): Observable<PlanningEntry> {
    const params = new HttpParams().set('month', String(month)).set('year', String(year));
    return this.http.put<{ status: string; data: PlanningEntry }>(
      `${this.base}/${encodeURIComponent(entry._id)}`,
      entry,
      { params }
    ).pipe(
      map(response => response.data),
      catchError(this.handleError)
    );
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const message = err.error?.message ||
      err.error?.error ||
      (err.status === 0 ? 'Cannot reach the server. Check your connection.' : `Server error ${err.status}`);
    return throwError(() => new Error(message));
  }
}
