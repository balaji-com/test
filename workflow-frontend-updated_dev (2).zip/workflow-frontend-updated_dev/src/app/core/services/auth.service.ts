import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export type AccessLevel = 'no_access' | 'viewer' | 'editor' | 'admin';

export interface AuthUser {
  _id: string;
  name: string;
  email: string;
  role: 'admin' | 'member' | 'viewer';
  isAdmin: boolean;
  color: string;
  permissions?: Record<string, AccessLevel>;
}

export interface LoginPayload    { email: string; password: string; }
export interface RegisterPayload extends LoginPayload { name: string; role?: string; }
export interface AuthResponse    { status: string; accessToken: string; user: AuthUser; }

const TOKEN_KEY = 'ht_access_token';
const USER_KEY  = 'ht_user';

// ── Token expiry check (client-side, before hitting the API) ───────
// Decodes the JWT payload without verifying the signature.
// Used only to avoid making API calls we already know will fail.
function tokenExpiresAt(token: string): number | null {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return typeof payload.exp === 'number' ? payload.exp * 1000 : null;
  } catch {
    return null;
  }
}

function isTokenExpired(token: string | null): boolean {
  if (!token) return true;
  const exp = tokenExpiresAt(token);
  if (exp === null) return false;           // can't tell — treat as valid
  return Date.now() >= exp - 10_000;        // 10-second buffer before actual expiry
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http   = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly base   = `${environment.apiUrl}/auth`;

  readonly currentUser  = signal<AuthUser | null>(this.loadUser());
  readonly accessToken  = signal<string | null>(this.loadToken());
  readonly isLoggedIn   = computed(() => !!this.accessToken() && !!this.currentUser());
  readonly isAdmin      = computed(() => this.currentUser()?.isAdmin ?? false);

  /** True if the stored access token is expired (used by the auth guard). */
  isAccessTokenExpired(): boolean {
    return isTokenExpired(this.accessToken());
  }

  login(payload: LoginPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/login`, payload).pipe(
      tap(res => this.saveSession(res)),
      catchError(this.handleError)
    );
  }

  register(payload: RegisterPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/register`, payload).pipe(
      tap(res => this.saveSession(res)),
      catchError(this.handleError)
    );
  }

  logout(callBackend = true): void {
    if (callBackend) {
      // Best-effort — don't block on failure
      this.http.post(`${this.base}/logout`, {}, { withCredentials: true }).pipe(
        catchError(() => throwError(() => null))
      ).subscribe();
    }
    this.clearSession();
    this.router.navigate(['/login']);
  }

  // Called by the interceptor — does NOT call backend (avoids infinite 401 loop)
  forceLogout(): void {
    this.logout(false);
  }

  refreshToken(): Observable<{ status: string; accessToken: string }> {
    return this.http
      .post<{ status: string; accessToken: string }>(
        `${this.base}/refresh`, {}, { withCredentials: true }
      )
      .pipe(
        tap(res => {
          this.accessToken.set(res.accessToken);
          localStorage.setItem(TOKEN_KEY, res.accessToken);
        }),
        // Do NOT navigate here — let the interceptor handle it
        // so in-flight requests can be properly cancelled first.
        catchError(err => throwError(() => err))
      );
  }

  fetchMe(): Observable<{ status: string; user: AuthUser }> {
    return this.http
      .get<{ status: string; user: AuthUser }>(`${this.base}/me`)
      .pipe(
        tap(res => {
          this.currentUser.set(res.user);
          localStorage.setItem(USER_KEY, JSON.stringify(res.user));
        }),
        catchError(this.handleError)
      );
  }

  changePassword(currentPassword: string, newPassword: string): Observable<AuthResponse> {
    return this.http
      .patch<AuthResponse>(`${this.base}/change-password`, { currentPassword, newPassword })
      .pipe(
        tap(res => this.saveSession(res)),
        catchError(this.handleError)
      );
  }

  getToken(): string | null { return this.accessToken(); }

  private saveSession(res: AuthResponse): void {
    localStorage.setItem(TOKEN_KEY, res.accessToken);
    localStorage.setItem(USER_KEY, JSON.stringify(res.user));
    this.accessToken.set(res.accessToken);
    this.currentUser.set(res.user);
  }

  clearSession(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this.accessToken.set(null);
    this.currentUser.set(null);
  }

  private loadToken(): string | null {
    return typeof localStorage !== 'undefined'
      ? localStorage.getItem(TOKEN_KEY) : null;
  }

  private loadUser(): AuthUser | null {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem(USER_KEY);
    try { return raw ? JSON.parse(raw) : null; } catch { return null; }
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg = err.error?.message || err.error?.error ||
      (err.status === 0 ? 'Cannot reach the server. Check your connection.' : `Server error ${err.status}`);
    return throwError(() => new Error(msg));
  }
}
