import { Injectable, inject, computed } from '@angular/core';
import { AuthService } from './auth.service';

// ── Types ────────────────────────────────────────────────────────
export type AccessLevel = 'no_access' | 'viewer' | 'editor' | 'admin';

export type ModuleKey =
  | 'my_tasks' | 'all_works' | 'reminders' | 'kanban' | 'approvals'
  | 'calendar' | 'planner'
  | 'team_overview' | 'monthly_reports'
  | 'seo_checker' | 'topic_selector'
  | 'ai_configuration' | 'customize_fields' | 'add_members'
  | 'audit_log' | 'backup' | 'change_password';

const LEVEL_ORDER: AccessLevel[] = ['no_access', 'viewer', 'editor', 'admin'];

// Maps every Angular route path → its backend permission module key.
// Keep this in sync with app.routes.ts and the backend's MODULE_KEYS.
export const ROUTE_MODULE_MAP: Record<string, ModuleKey> = {
  'my-tasks':         'my_tasks',
  'all-works':        'all_works',
  'reminders':        'reminders',
  'kanban':           'kanban',
  'approvals':        'approvals',
  'calendar':         'calendar',
  'planner':          'planner',
  'team-overview':    'team_overview',
  'monthly-reports':  'monthly_reports',
  'seo-checker':      'seo_checker',
  'topic-selector':   'topic_selector',
  'ai-configuration': 'ai_configuration',
  'customize-fields': 'customize_fields',
  'add-members':      'add_members',
  'audit-log':        'audit_log',
  'backup':           'backup',
  'change-password':  'change_password',
};

@Injectable({ providedIn: 'root' })
export class PermissionsService {
  private readonly auth = inject(AuthService);

  /** Full permissions map for the current user (empty object if not loaded yet). */
  readonly permissions = computed(() => this.auth.currentUser()?.permissions ?? {});

  /**
   * Returns the access level the current user has for a module.
   * Admins always resolve to 'admin' regardless of their stored map.
   */
  levelFor(moduleKey: ModuleKey): AccessLevel {
    if (this.auth.isAdmin()) return 'admin';
    const level = this.permissions()[moduleKey];
    return (level as AccessLevel) || 'no_access';
  }

  /**
   * True if the user's level for moduleKey is >= requiredLevel.
   * Default requiredLevel is 'viewer' — i.e. "can they see it at all".
   */
  can(moduleKey: ModuleKey, requiredLevel: AccessLevel = 'viewer'): boolean {
    if (this.auth.isAdmin()) return true;
    const have = LEVEL_ORDER.indexOf(this.levelFor(moduleKey));
    const need = LEVEL_ORDER.indexOf(requiredLevel);
    return have >= need;
  }

  /** Convenience: can the user see this module at all (viewer or above)? */
  canView(moduleKey: ModuleKey): boolean { return this.can(moduleKey, 'viewer'); }

  /** Convenience: can the user create/edit/delete in this module? */
  canEdit(moduleKey: ModuleKey): boolean { return this.can(moduleKey, 'editor'); }

  /** True if the user has only read access (viewer) — used to hide edit/delete buttons. */
  isViewerOnly(moduleKey: ModuleKey): boolean {
    return this.levelFor(moduleKey) === 'viewer';
  }

  /** Resolve a route path (e.g. 'kanban') to its module key, or null if unmapped. */
  moduleForRoute(routePath: string): ModuleKey | null {
    const clean = routePath.replace(/^\//, '').split('/')[0];
    return ROUTE_MODULE_MAP[clean] ?? null;
  }

  /** Can the user navigate to this route at all? */
  canViewRoute(routePath: string): boolean {
    const moduleKey = this.moduleForRoute(routePath);
    if (!moduleKey) return true; // unmapped routes (e.g. /login) are always allowed
    return this.canView(moduleKey);
  }
}
