import { Injectable, signal, computed, inject, OnDestroy } from '@angular/core';
import { TaskService, TaskListResponse } from './task.service';
import { AuthService } from './auth.service';
import { ApprovalService, ApprovalRequest } from './approval.service';
import { Task } from '../models/task.model';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface ReminderItem {
  _id: string;
  task: string;
  dueDate: string;
  status: string;
  priority: string;
  approvalStatus?: string;
  assignedToName?: string;
  cat?: string;
  month?: string;
  year?: string;
  assignedTo?: any;
  approvalRequestId?: string;
  requestedByName?: string;
  type: 'overdue' | 'today' | 'tomorrow' | 'approval';
}

@Injectable({ providedIn: 'root' })
export class ReminderCountService implements OnDestroy {
  private readonly taskSvc = inject(TaskService);
  private readonly approvalSvc = inject(ApprovalService);
  private readonly auth    = inject(AuthService);

  // ── Counts ──────────────────────────────────────────────────────
  readonly counts = signal({
    overdue: 0, today: 0, tomorrow: 0, approval: 0, all: 0,
  });

  // ── Live items for the dropdown (max 20 total) ───────────────────
  readonly items = signal<ReminderItem[]>([]);
  readonly loading = signal(false);

  /** Bell badge count = overdue + today + pending approval */
  readonly bellCount = computed(() => {
    const c = this.counts();
    return c.overdue + c.today + c.approval;
  });

  // ── Grouped for the dropdown ─────────────────────────────────────
  readonly overdueItems  = computed(() => this.items().filter(i => i.type === 'overdue'));
  readonly todayItems    = computed(() => this.items().filter(i => i.type === 'today'));
  readonly tomorrowItems = computed(() => this.items().filter(i => i.type === 'tomorrow'));
  readonly approvalItems = computed(() => this.items().filter(i => i.type === 'approval'));

  private pollTimer: ReturnType<typeof setInterval> | null = null;
  private readonly POLL_INTERVAL = 2 * 60 * 1000; // 2 minutes

  // ── Public API ───────────────────────────────────────────────────

  /** Call once after login to start polling. */
  startPolling(): void {
    this.fetch();
    this.pollTimer = setInterval(() => this.fetch(), this.POLL_INTERVAL);
  }

  stopPolling(): void {
    if (this.pollTimer) { clearInterval(this.pollTimer); this.pollTimer = null; }
  }

  /** Manual refresh — called by RemindersComponent after each load. */
  update(counts: { overdue: number; today: number; tomorrow: number; approval: number; all: number }): void {
    this.counts.set(counts);
    // Re-fetch items so the dropdown stays in sync
    this.fetchItems();
  }

  ngOnDestroy(): void { this.stopPolling(); }

  // ── Private ─────────────────────────────────────────────────────

  private fetch(): void {
    if (!this.auth.isLoggedIn()) return;
    this.loading.set(true);

    // One call with limit=100 to derive both counts AND dropdown items
    forkJoin({
      tasks: this.taskSvc.getTasksPaginated({ limit: 100, page: 1 }),
      approvals: this.approvalSvc.list('inbox', 1, 100).pipe(catchError(() => of(null))),
    }).subscribe({
      next: ({ tasks: res, approvals }) => {
        const all    = res.data;
        const today  = new Date().toISOString().slice(0, 10);
        const tom    = (() => { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); })();

        const overdue  = all.filter(t => t.dueDate && t.dueDate < today && t.status !== 'Completed');
        const todayArr = all.filter(t => t.dueDate === today && t.status !== 'Completed');
        const tomArr   = all.filter(t => t.dueDate === tom   && t.status !== 'Completed');
        const approvalRequests = approvals?.data.filter(r => r.status === 'Pending') ?? [];
        const approvalCount = approvals?.counts.inboxPending ?? 0;

        this.counts.set({
          overdue:  overdue.length,
          today:    todayArr.length,
          tomorrow: tomArr.length,
          approval: approvalCount,
          all:      [...new Set([...overdue, ...todayArr, ...tomArr].map(t => t._id))].length + approvalCount,
        });

        // Build dropdown items — cap at 5 per type (20 max total)
        const toItem = (t: Task, type: ReminderItem['type']): ReminderItem => ({
          _id: t._id, task: t.task, dueDate: t.dueDate || '',
          status: t.status, priority: t.priority,
          approvalStatus: t.approvalStatus,
          assignedToName: typeof t.assignedTo === 'object' ? t.assignedTo?.name : t.assignedToName,
          cat: t.cat, month: t.month, year: t.year, assignedTo: t.assignedTo,
          type,
        });

        const approvalItems: ReminderItem[] = approvalRequests.slice(0, 5).map((request: ApprovalRequest) => ({
          _id: typeof request.taskId === 'object' ? request.taskId._id : String(request.taskId),
          task: typeof request.taskId === 'object' ? request.taskId.task : request.taskName,
          dueDate: typeof request.taskId === 'object' ? request.taskId.dueDate || '' : '',
          status: typeof request.taskId === 'object' ? request.taskId.status : 'Pending',
          priority: typeof request.taskId === 'object' ? request.taskId.priority : '',
          approvalRequestId: request._id,
          requestedByName: request.requestedByName || (typeof request.requestedBy === 'object' ? request.requestedBy.name : ''),
          type: 'approval',
        }));

        this.items.set([
          ...overdue.slice(0, 5).map(t => toItem(t, 'overdue')),
          ...todayArr.slice(0, 5).map(t => toItem(t, 'today')),
          ...tomArr.slice(0, 5).map(t => toItem(t, 'tomorrow')),
          ...approvalItems,
        ]);

        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  /** Lightweight re-fetch of items only (after reminders update). */
  private fetchItems(): void { this.fetch(); }
}
