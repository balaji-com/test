import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export type AccessLevel = 'no_access' | 'viewer' | 'editor' | 'admin';

export type ModuleKey =
  | 'my_tasks' | 'all_works' | 'reminders' | 'kanban' | 'approvals'
  | 'calendar' | 'planner'
  | 'team_overview' | 'monthly_reports'
  | 'seo_checker' | 'topic_selector'
  | 'ai_configuration' | 'customize_fields' | 'add_members'
  | 'audit_log' | 'backup' | 'change_password';

export type Permissions = Record<ModuleKey, AccessLevel>;

export interface Member {
  _id: string;
  name: string;
  email: string;
  role: 'admin' | 'member' | 'viewer';
  isAdmin: boolean;
  isActive: boolean;
  color: string;
  permissions?: Partial<Permissions>;
  createdAt?: string;
  updatedAt?: string;
}

export interface CreateMemberPayload {
  name: string; email: string; password: string;
  role: 'admin' | 'member' | 'viewer';
  color?: string;
  permissions?: Partial<Permissions>;
}

export interface UpdateMemberPayload {
  name?: string; email?: string; password?: string;
  role?: 'admin' | 'member' | 'viewer';
  color?: string; isActive?: boolean;
  permissions?: Partial<Permissions>;
}

@Injectable({ providedIn: 'root' })
export class UserService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiUrl}/users`;

  // Open to all logged-in users — returns minimal fields for dropdowns
  getActiveUsers(): Observable<Member[]> {
    return this.http.get<{ status: string; total: number; data: Member[] }>(`${this.base}/active`)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  getUsers(): Observable<Member[]> {
    return this.http.get<{ status: string; total: number; data: Member[] }>(this.base)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  getUser(id: string): Observable<Member> {
    return this.http.get<{ status: string; data: Member }>(`${this.base}/${id}`)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  createUser(p: CreateMemberPayload): Observable<Member> {
    return this.http.post<{ status: string; data: Member }>(this.base, p)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  updateUser(id: string, p: UpdateMemberPayload): Observable<Member> {
    return this.http.patch<{ status: string; data: Member }>(`${this.base}/${id}`, p)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  savePermissions(id: string, permissions: Partial<Permissions>): Observable<Member> {
    return this.http.patch<{ status: string; data: Member }>(
      `${this.base}/${id}/permissions`, { permissions }
    ).pipe(map(r => r.data), catchError(this.handleError));
  }

  toggleActive(id: string, isActive: boolean): Observable<Member> {
    return this.updateUser(id, { isActive });
  }

  deleteUser(id: string): Observable<{ message: string }> {
    return this.http.delete<{ status: string; message: string }>(`${this.base}/${id}`)
      .pipe(map(r => ({ message: r.message })), catchError(this.handleError));
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg = err.error?.message || err.error?.error ||
      (err.status === 0 ? 'Cannot reach the server.' : `Server error ${err.status}`);
    return throwError(() => new Error(msg));
  }
}
