import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { Task } from '../models/task.model';
import { AuthService, AuthUser } from './auth.service';

@Injectable({ providedIn: 'root' })
export class AppStateService {
  private readonly auth = inject(AuthService);

  // ── Proxy auth signals so rest of app can use AppStateService as before ──
  readonly currentUser  = this.auth.currentUser;
  readonly isAuthenticated = this.auth.isLoggedIn;

  // ── Dark mode ────────────────────────────────────────────────
  private _darkMode = signal<boolean>(
    typeof localStorage !== 'undefined'
      ? localStorage.getItem('ht_dark_mode') === 'true'
      : false
  );
  readonly darkMode = this._darkMode.asReadonly();

  // ── Tasks (local signal — synced from API in each feature) ───
  readonly tasks = signal<Task[]>([]);

  readonly myTasks = computed(() => {
    const user = this.currentUser();
    if (!user) return [];
    return this.tasks().filter(
      t => t.assignedTo === (user as AuthUser)._id || t.assignedTo === user.name
    );
  });

  readonly pendingApprovals = computed(() =>
    this.tasks().filter(t => t.approvalStatus === 'Pending')
  );

  readonly overdueReminders = computed(() => {
    const today = new Date().toISOString().slice(0, 10);
    return this.tasks().filter(
      t => t.dueDate && t.dueDate < today && t.status !== 'Completed'
    );
  });

  readonly badges = signal({ myTasks: 0, reminders: 0, approvals: 0 });

  constructor() {
    // Keep badges in sync
    effect(() => {
      this.badges.set({
        myTasks:   this.myTasks().length,
        approvals: this.pendingApprovals().length,
        reminders: this.overdueReminders().length,
      });
    });

    // Sync dark-mode class
    effect(() => {
      if (typeof document !== 'undefined') {
        document.documentElement.classList.toggle('dark-mode', this._darkMode());
        localStorage.setItem('ht_dark_mode', String(this._darkMode()));
      }
    });
  }

  // ── Dark mode ────────────────────────────────────────────────
  toggleDarkMode(): void { this._darkMode.update(v => !v); }

  // ── Auth delegates ────────────────────────────────────────────
  login(user: any): void { /* used by legacy callers — real login goes via AuthService */ }
  logout(): void { this.auth.logout(); }

  // ── Task mutations (local signal) ────────────────────────────
  addTask(task: Task): void {
    this.tasks.update(ts => [...ts, task]);
  }
  updateTask(id: string, patch: Partial<Task>): void {
    this.tasks.update(ts => ts.map(t => String(t.id) === id ? { ...t, ...patch } : t));
  }
  deleteTask(id: string): void {
    this.tasks.update(ts => ts.filter(t => String(t.id) !== id));
  }
}
