import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { permissionGuard } from './core/guards/permission.guard';
import { LayoutComponent } from './shared/components/layout/layout.component';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/login/login.component').then(m => m.LoginComponent),
  },
  {
    path: 'no-access',
    loadComponent: () =>
      import('./features/no-access/no-access.component').then(m => m.NoAccessComponent),
  },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'my-tasks', pathMatch: 'full' },

      // ── Workspace ──
      {
        path: 'my-tasks',
        canActivate: [permissionGuard],
        data: { moduleKey: 'my_tasks' },
        loadComponent: () =>
          import('./features/my-tasks/my-tasks.component').then(m => m.MyTasksComponent),
        title: 'My Tasks',
      },
      {
        path: 'all-works',
        canActivate: [permissionGuard],
        data: { moduleKey: 'all_works' },
        loadComponent: () =>
          import('./features/all-works/all-works.component').then(m => m.AllWorksComponent),
        title: 'All Works',
      },
      {
        path: 'reminders',
        canActivate: [permissionGuard],
        data: { moduleKey: 'reminders' },
        loadComponent: () =>
          import('./features/reminders/reminders.component').then(m => m.RemindersComponent),
        title: 'Reminders',
      },
      {
        path: 'kanban',
        canActivate: [permissionGuard],
        data: { moduleKey: 'kanban' },
        loadComponent: () =>
          import('./features/kanban/kanban.component').then(m => m.KanbanComponent),
        title: 'Workflow Board',
      },
      {
        path: 'approvals',
        canActivate: [permissionGuard],
        data: { moduleKey: 'approvals' },
        loadComponent: () =>
          import('./features/approvals/approvals.component').then(m => m.ApprovalsComponent),
        title: 'Approvals',
      },

      // ── Calendar ──
      {
        path: 'calendar',
        canActivate: [permissionGuard],
        data: { moduleKey: 'calendar' },
        loadComponent: () =>
          import('./features/calendar/calendar.component').then(m => m.CalendarComponent),
        title: 'My Tasks Calendar',
      },
      {
        path: 'planner',
        canActivate: [permissionGuard],
        data: { moduleKey: 'planner' },
        loadComponent: () =>
          import('./features/planner/planner.component').then(m => m.PlannerComponent),
        title: 'Planning Calendar',
      },

      // ── Analytics ──
      {
        path: 'team-overview',
        canActivate: [permissionGuard],
        data: { moduleKey: 'team_overview' },
        loadComponent: () =>
          import('./features/team-overview/team-overview.component').then(m => m.TeamOverviewComponent),
        title: 'Team Overview',
      },
      {
        path: 'monthly-reports',
        canActivate: [permissionGuard],
        data: { moduleKey: 'monthly_reports' },
        loadComponent: () =>
          import('./features/monthly-reports/monthly-reports.component').then(m => m.MonthlyReportsComponent),
        title: 'Monthly Reports',
      },

      // ── SEO Tools ──
      {
        path: 'seo-checker',
        canActivate: [permissionGuard],
        data: { moduleKey: 'seo_checker' },
        loadComponent: () =>
          import('./features/seo-checker/seo-checker.component').then(m => m.SeoCheckerComponent),
        title: 'SEO Blog Checker',
      },
      {
        path: 'topic-selector',
        canActivate: [permissionGuard],
        data: { moduleKey: 'topic_selector' },
        loadComponent: () =>
          import('./features/topic-selector/topic-selector.component').then(m => m.TopicSelectorComponent),
        title: 'Blog Topic Selector',
      },

      // ── Account & Team Settings ──
      {
        path: 'ai-configuration',
        canActivate: [permissionGuard],
        data: { moduleKey: 'ai_configuration' },
        loadComponent: () =>
          import('./features/ai-configuration/ai-configuration.component').then(m => m.AiConfigurationComponent),
        title: 'AI Configuration',
      },
      {
        path: 'customize-fields',
        canActivate: [permissionGuard],
        data: { moduleKey: 'customize_fields' },
        loadComponent: () =>
          import('./features/customize-fields/customize-fields.component').then(m => m.CustomizeFieldsComponent),
        title: 'Customize Fields',
      },
      {
        path: 'add-members',
        canActivate: [permissionGuard],
        data: { moduleKey: 'add_members' },
        loadComponent: () =>
          import('./features/add-members/add-members.component').then(m => m.AddMembersComponent),
        title: 'Add Members',
      },
      {
        path: 'audit-log',
        canActivate: [permissionGuard],
        data: { moduleKey: 'audit_log' },
        loadComponent: () =>
          import('./features/audit-log/audit-log.component').then(m => m.AuditLogComponent),
        title: 'Audit Log',
      },
      {
        path: 'backup',
        canActivate: [permissionGuard],
        data: { moduleKey: 'backup' },
        loadComponent: () =>
          import('./features/backup/backup.component').then(m => m.BackupComponent),
        title: 'Backup & Restore',
      },
      {
        path: 'change-password',
        canActivate: [permissionGuard],
        data: { moduleKey: 'change_password' },
        loadComponent: () =>
          import('./features/change-password/change-password.component').then(m => m.ChangePasswordComponent),
        title: 'Change Password',
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
