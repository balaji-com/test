export const environment = {
  production: true,
  apiUrl: 'https://your-backend-domain.com/api',  // ← replace with your production URL
};
