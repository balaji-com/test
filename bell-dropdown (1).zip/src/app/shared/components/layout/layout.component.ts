import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { TopbarComponent } from '../topbar/topbar.component';
import { ReminderCountService } from '../../../core/services/reminder-count.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, TopbarComponent],
  template: `
    <div class="app-shell">
      <app-sidebar />
      <div class="main-wrap">
        <app-topbar />
        <main class="main-content">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
  styles: [`
    :host { display: flex; height: 100vh; overflow: hidden; }

    .app-shell {
      display: flex;
      width: 100%;
      height: 100vh;
      overflow: hidden;
      background: var(--bg);
    }

    /* Sidebar takes its own fixed width, scrolls internally */
    app-sidebar {
      flex-shrink: 0;
      height: 100vh;
      overflow: hidden;
    }

    /* Right side: topbar (sticky) + scrollable main */
    .main-wrap {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100vh;
      overflow: hidden;
      min-width: 0;
    }

    /* Topbar is fixed at top — never scrolls */
    app-topbar {
      flex-shrink: 0;
    }

    /* Main content area — only this scrolls */
    .main-content {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      padding: 24px;
      scroll-behavior: smooth;
    }

    /* Custom scrollbar for main content */
    .main-content::-webkit-scrollbar { width: 6px; }
    .main-content::-webkit-scrollbar-track { background: transparent; }
    .main-content::-webkit-scrollbar-thumb {
      background: var(--border2);
      border-radius: 3px;
    }
    .main-content::-webkit-scrollbar-thumb:hover { background: var(--text3); }
  `]
})
export class LayoutComponent implements OnInit, OnDestroy {
  private readonly reminderSvc = inject(ReminderCountService);

  ngOnInit():    void { this.reminderSvc.startPolling(); }
  ngOnDestroy(): void { this.reminderSvc.stopPolling(); }
}
