import {
  Component, inject, signal, computed,
  HostListener, ElementRef
} from '@angular/core';
import { NgIf, NgFor, NgClass } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ReminderCountService, ReminderItem } from '../../../core/services/reminder-count.service';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [NgIf, NgFor, NgClass, RouterLink],
  template: `
    <header class="topbar">

      <!-- Left: breadcrumb -->
      <div class="topbar-left">
        <div class="topbar-breadcrumb">
          <span class="topbar-app">Hinduja Tech</span>
          <span class="topbar-sep">›</span>
          <span class="topbar-page">{{ currentPage }}</span>
        </div>
      </div>

      <!-- Right: bell + user -->
      <div class="topbar-right">

        <!-- ── Bell button ── -->
        <div class="bell-wrap">
          <button class="icon-btn bell-btn"
                  (click)="toggleDropdown($event)"
                  [class.bell-active]="dropdownOpen()"
                  title="Reminders">
            <span class="bell-icon">🔔</span>
            <span class="bell-badge" *ngIf="bellCount() > 0">
              {{ bellCount() > 99 ? '99+' : bellCount() }}
            </span>
          </button>

          <!-- ── Dropdown panel ── -->
          <div class="notif-dropdown" *ngIf="dropdownOpen()" (click)="$event.stopPropagation()">

            <!-- Header -->
            <div class="nd-header">
              <div class="nd-title">🔔 Reminders</div>
              <div class="nd-header-right">
                <span class="nd-total-badge" *ngIf="bellCount() > 0">{{ bellCount() }} urgent</span>
                <button class="nd-close" (click)="closeDropdown()">✕</button>
              </div>
            </div>

            <!-- Loading -->
            <div class="nd-loading" *ngIf="loading()">
              <div class="nd-skel" *ngFor="let i of [1,2,3]"></div>
            </div>

            <ng-container *ngIf="!loading()">

              <!-- Empty state -->
              <div class="nd-empty" *ngIf="bellCount() === 0 && tomorrowItems().length === 0">
                <span class="nd-empty-icon">🎉</span>
                <div class="nd-empty-msg">All caught up!</div>
                <div class="nd-empty-sub">No pending reminders right now.</div>
              </div>

              <!-- Count chips row -->
              <div class="nd-chips" *ngIf="hasAny()">
                <span class="nd-chip nd-chip-overdue"  *ngIf="counts().overdue  > 0">⚠ {{ counts().overdue  }} Overdue</span>
                <span class="nd-chip nd-chip-today"    *ngIf="counts().today    > 0">⏰ {{ counts().today    }} Today</span>
                <span class="nd-chip nd-chip-tomorrow" *ngIf="counts().tomorrow > 0">📅 {{ counts().tomorrow }} Tomorrow</span>
                <span class="nd-chip nd-chip-approval" *ngIf="counts().approval > 0">✍️ {{ counts().approval }} Approval</span>
              </div>

              <!-- Overdue -->
              <div class="nd-section" *ngIf="overdueItems().length > 0">
                <div class="nd-section-label nd-label-overdue">⚠️ Overdue</div>
                <div class="nd-item" *ngFor="let r of overdueItems()" (click)="goToReminders(); closeDropdown()">
                  <div class="nd-item-dot nd-dot-overdue"></div>
                  <div class="nd-item-body">
                    <div class="nd-item-title">{{ r.task }}</div>
                    <div class="nd-item-meta">
                      <span>{{ r.assignedToName || 'Unassigned' }}</span>
                      <span class="nd-sep">·</span>
                      <span class="nd-date-overdue">Due {{ r.dueDate }}</span>
                    </div>
                  </div>
                  <span class="nd-pri" [ngClass]="priClass(r.priority)">{{ r.priority }}</span>
                </div>
              </div>

              <!-- Due Today -->
              <div class="nd-section" *ngIf="todayItems().length > 0">
                <div class="nd-section-label nd-label-today">⏰ Due Today</div>
                <div class="nd-item" *ngFor="let r of todayItems()" (click)="goToReminders(); closeDropdown()">
                  <div class="nd-item-dot nd-dot-today"></div>
                  <div class="nd-item-body">
                    <div class="nd-item-title">{{ r.task }}</div>
                    <div class="nd-item-meta">
                      <span>{{ r.assignedToName || 'Unassigned' }}</span>
                      <span class="nd-sep" *ngIf="r.cat">·</span>
                      <span *ngIf="r.cat">{{ r.cat }}</span>
                    </div>
                  </div>
                  <span class="nd-pri" [ngClass]="priClass(r.priority)">{{ r.priority }}</span>
                </div>
              </div>

              <!-- Due Tomorrow -->
              <div class="nd-section" *ngIf="tomorrowItems().length > 0">
                <div class="nd-section-label nd-label-tomorrow">📅 Due Tomorrow</div>
                <div class="nd-item" *ngFor="let r of tomorrowItems()" (click)="goToReminders(); closeDropdown()">
                  <div class="nd-item-dot nd-dot-tomorrow"></div>
                  <div class="nd-item-body">
                    <div class="nd-item-title">{{ r.task }}</div>
                    <div class="nd-item-meta">
                      <span>{{ r.assignedToName || 'Unassigned' }}</span>
                      <span class="nd-sep" *ngIf="r.cat">·</span>
                      <span *ngIf="r.cat">{{ r.cat }}</span>
                    </div>
                  </div>
                  <span class="nd-pri" [ngClass]="priClass(r.priority)">{{ r.priority }}</span>
                </div>
              </div>

              <!-- Pending Approval -->
              <div class="nd-section" *ngIf="approvalItems().length > 0">
                <div class="nd-section-label nd-label-approval">✍️ Pending Approval</div>
                <div class="nd-item" *ngFor="let r of approvalItems()" (click)="goToReminders(); closeDropdown()">
                  <div class="nd-item-dot nd-dot-approval"></div>
                  <div class="nd-item-body">
                    <div class="nd-item-title">{{ r.task }}</div>
                    <div class="nd-item-meta">
                      <span>{{ r.assignedToName || 'Unassigned' }}</span>
                      <span class="nd-sep" *ngIf="r.month">·</span>
                      <span *ngIf="r.month">{{ r.month }} {{ r.year }}</span>
                    </div>
                  </div>
                  <span class="nd-approval-tag">Pending</span>
                </div>
              </div>

            </ng-container>

            <!-- Footer -->
            <div class="nd-footer">
              <button class="nd-view-all" (click)="goToReminders(); closeDropdown()">
                View all reminders →
              </button>
            </div>

          </div><!-- /notif-dropdown -->
        </div><!-- /bell-wrap -->

        <div class="topbar-divider"></div>

        <!-- User -->
        <div class="topbar-user" *ngIf="auth.currentUser() as user">
          <div class="topbar-avatar" [style.background]="user.color || 'var(--accent)'">
            {{ user.name[0].toUpperCase() }}
          </div>
          <div class="topbar-user-info">
            <div class="topbar-name">{{ user.name }}</div>
            <div class="topbar-role">{{ user.role }}</div>
          </div>
          <button class="topbar-logout" (click)="logout()" title="Sign out">⏻</button>
        </div>

      </div>
    </header>
  `,
  styles: [`
    .topbar {
      height: 56px;
      background: var(--white);
      border-bottom: 1.5px solid var(--border);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 20px 0 24px;
      flex-shrink: 0; position: relative; z-index: 200;
    }

    /* ── Breadcrumb ── */
    .topbar-breadcrumb { display:flex; align-items:center; gap:8px; }
    .topbar-app  { font-size:12px; font-weight:600; color:var(--text3); }
    .topbar-sep  { font-size:14px; color:var(--border2); }
    .topbar-page { font-size:14px; font-weight:700; color:var(--text); }

    .topbar-right { display:flex; align-items:center; gap:4px; position:relative; }

    /* ── Icon button ── */
    .icon-btn {
      position:relative; background:none; border:none; cursor:pointer;
      font-size:17px; padding:7px 8px; border-radius:var(--radius-xs);
      color:var(--text2); transition:background .13s; line-height:1;
    }
    .icon-btn:hover, .icon-btn.bell-active { background:var(--bg2); }

    /* ── Bell ── */
    .bell-wrap { position:relative; }
    .bell-btn  { font-size:18px; }
    .bell-icon { display:inline-block; transition:transform .2s; }
    .bell-btn.bell-active .bell-icon { animation:bellRing .4s ease; }
    @keyframes bellRing {
      0%   { transform:rotate(0); }
      20%  { transform:rotate(-20deg); }
      40%  { transform:rotate(20deg); }
      60%  { transform:rotate(-12deg); }
      80%  { transform:rotate(8deg); }
      100% { transform:rotate(0); }
    }

    .bell-badge {
      position:absolute; top:2px; right:2px;
      min-width:16px; height:16px; padding:0 4px;
      background:var(--red); color:#fff; border-radius:10px;
      font-size:9px; font-weight:800; font-family:var(--font);
      display:flex; align-items:center; justify-content:center;
      border:1.5px solid var(--white); line-height:1;
      animation:popIn .2s cubic-bezier(.34,1.56,.64,1);
    }
    @keyframes popIn { from{transform:scale(0)} to{transform:scale(1)} }

    /* ══════════════════════════════════════════
       DROPDOWN PANEL
       ══════════════════════════════════════════ */
    .notif-dropdown {
      position: absolute;
      top: calc(100% + 8px);
      right: 0;
      width: 360px;
      max-height: 520px;
      background: var(--white);
      border: 1.5px solid var(--border);
      border-radius: var(--radius);
      box-shadow: 0 8px 32px rgba(0,0,0,.14);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      animation: dropIn .16s cubic-bezier(.22,.68,0,1.2);
      z-index: 300;
    }
    @keyframes dropIn {
      from { opacity:0; transform:translateY(-8px) scale(.97); }
      to   { opacity:1; transform:translateY(0)    scale(1);   }
    }

    /* caret arrow */
    .notif-dropdown::before {
      content:'';
      position:absolute; top:-6px; right:18px;
      width:10px; height:10px;
      background:var(--white);
      border-top:1.5px solid var(--border);
      border-left:1.5px solid var(--border);
      transform:rotate(45deg);
    }

    /* Header */
    .nd-header {
      display:flex; align-items:center; justify-content:space-between;
      padding:13px 16px 11px;
      border-bottom:1.5px solid var(--border);
      flex-shrink:0;
    }
    .nd-title { font-size:13px; font-weight:800; color:var(--text); }
    .nd-header-right { display:flex; align-items:center; gap:8px; }
    .nd-total-badge {
      background:var(--red-light); color:var(--red);
      border:1px solid var(--red); border-radius:20px;
      font-size:10px; font-weight:800; padding:2px 8px;
    }
    .nd-close {
      background:none; border:none; cursor:pointer; font-size:13px;
      color:var(--text3); padding:2px 6px; border-radius:var(--radius-xs);
      transition:all .12s;
    }
    .nd-close:hover { background:var(--red-light); color:var(--red); }

    /* Loading skeleton */
    .nd-loading { padding:12px 16px; display:flex; flex-direction:column; gap:8px; }
    .nd-skel {
      height:48px; border-radius:var(--radius-xs);
      background:linear-gradient(90deg,var(--bg2) 25%,var(--border) 50%,var(--bg2) 75%);
      background-size:200% 100%; animation:shimmer 1.4s infinite;
    }
    @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }

    /* Empty */
    .nd-empty { text-align:center; padding:32px 20px; }
    .nd-empty-icon { font-size:32px; margin-bottom:8px; }
    .nd-empty-msg  { font-size:13px; font-weight:700; color:var(--text2); }
    .nd-empty-sub  { font-size:11px; color:var(--text3); margin-top:4px; }

    /* Count chips */
    .nd-chips {
      display:flex; gap:6px; flex-wrap:wrap;
      padding:10px 16px 6px;
      border-bottom:1px solid var(--border);
    }
    .nd-chip {
      font-size:10px; font-weight:800; padding:2px 8px;
      border-radius:20px; white-space:nowrap;
    }
    .nd-chip-overdue  { background:var(--red-light);    color:var(--red);    }
    .nd-chip-today    { background:var(--amber-light);  color:var(--amber);  }
    .nd-chip-tomorrow { background:#eef6ff;             color:var(--teal);   }
    .nd-chip-approval { background:var(--purple-light); color:var(--purple); }

    /* Scrollable body */
    .nd-section { flex-shrink:0; }
    .notif-dropdown > .nd-section { /* no individual scroll — outer div scrolls */ }

    .nd-section-label {
      font-size:9.5px; font-weight:800; text-transform:uppercase;
      letter-spacing:.6px; padding:8px 16px 4px;
    }
    .nd-label-overdue  { color:var(--red);    }
    .nd-label-today    { color:var(--amber);  }
    .nd-label-tomorrow { color:var(--teal);   }
    .nd-label-approval { color:var(--purple); }

    /* Individual notification item */
    .nd-item {
      display:grid; grid-template-columns:8px 1fr auto;
      align-items:center; gap:10px;
      padding:9px 16px; cursor:pointer; transition:background .1s;
    }
    .nd-item:hover { background:var(--bg2); }

    .nd-item-dot {
      width:7px; height:7px; border-radius:50%; flex-shrink:0;
    }
    .nd-dot-overdue  { background:var(--red);    }
    .nd-dot-today    { background:var(--amber);  }
    .nd-dot-tomorrow { background:var(--teal);   }
    .nd-dot-approval { background:var(--purple); }

    .nd-item-body { min-width:0; }
    .nd-item-title {
      font-size:12.5px; font-weight:700; color:var(--text);
      overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
    }
    .nd-item-meta {
      font-size:11px; color:var(--text3); margin-top:2px;
      display:flex; align-items:center; gap:5px;
      overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
    }
    .nd-sep { color:var(--border2); }
    .nd-date-overdue { color:var(--red); font-weight:700; }

    /* Priority badge */
    .nd-pri {
      font-size:9.5px; font-weight:800; padding:2px 6px;
      border-radius:20px; white-space:nowrap; flex-shrink:0;
    }
    .pri-High   { background:var(--red-light);   color:var(--red);   }
    .pri-Medium { background:var(--amber-light);  color:var(--amber); }
    .pri-Low    { background:var(--green-light);  color:var(--green); }

    .nd-approval-tag {
      font-size:9.5px; font-weight:800; padding:2px 6px;
      border-radius:20px; background:var(--purple-light);
      color:var(--purple); white-space:nowrap; flex-shrink:0;
    }

    /* Scrollable middle section */
    .notif-dropdown {
      overflow-y: auto;
    }
    .nd-header, .nd-footer {
      position: sticky;
      z-index: 1;
    }
    .nd-header { top: 0; background: var(--white); }
    .nd-footer { bottom: 0; background: var(--white); }

    /* Footer */
    .nd-footer {
      border-top:1.5px solid var(--border);
      padding:10px 16px; flex-shrink:0;
    }
    .nd-view-all {
      width:100%; padding:8px; border:1.5px solid var(--accent);
      border-radius:var(--radius-xs); background:var(--accent-light);
      color:var(--accent); font-size:12.5px; font-weight:700;
      cursor:pointer; font-family:var(--font); transition:all .12s;
    }
    .nd-view-all:hover { background:var(--accent); color:#fff; }

    /* ── Divider ── */
    .topbar-divider { width:1px; height:24px; background:var(--border); margin:0 8px; }

    /* ── User ── */
    .topbar-user  { display:flex; align-items:center; gap:10px; }
    .topbar-avatar {
      width:32px; height:32px; border-radius:50%;
      background:var(--accent); color:#fff;
      display:flex; align-items:center; justify-content:center;
      font-weight:800; font-size:13px; flex-shrink:0;
    }
    .topbar-user-info { display:flex; flex-direction:column; }
    .topbar-name  { font-size:13px; font-weight:700; color:var(--text); line-height:1.2; }
    .topbar-role  { font-size:10.5px; color:var(--text3); font-weight:500; line-height:1.2; }
    .topbar-logout {
      background:none; border:none; cursor:pointer;
      color:var(--text3); font-size:16px; padding:5px;
      border-radius:var(--radius-xs); transition:all .13s;
    }
    .topbar-logout:hover { background:var(--red-light); color:var(--red); }

    /* Mobile */
    @media (max-width:480px) {
      .notif-dropdown { width:calc(100vw - 16px); right:-8px; }
      .topbar-user-info { display:none; }
    }
  `]
})
export class TopbarComponent {
  readonly auth       = inject(AuthService);
  readonly reminderSvc = inject(ReminderCountService);
  private readonly router  = inject(Router);
  private readonly elRef   = inject(ElementRef);

  readonly bellCount     = this.reminderSvc.bellCount;
  readonly counts        = this.reminderSvc.counts;
  readonly loading       = this.reminderSvc.loading;
  readonly overdueItems  = this.reminderSvc.overdueItems;
  readonly todayItems    = this.reminderSvc.todayItems;
  readonly tomorrowItems = this.reminderSvc.tomorrowItems;
  readonly approvalItems = this.reminderSvc.approvalItems;

  readonly dropdownOpen = signal(false);

  readonly hasAny = computed(() => {
    const c = this.counts();
    return c.overdue > 0 || c.today > 0 || c.tomorrow > 0 || c.approval > 0;
  });

  toggleDropdown(event: MouseEvent): void {
    event.stopPropagation();
    this.dropdownOpen.update(v => !v);
  }

  closeDropdown(): void { this.dropdownOpen.set(false); }

  // Close on any click outside the topbar
  @HostListener('document:click', ['$event'])
  onDocClick(e: MouseEvent): void {
    if (!this.elRef.nativeElement.contains(e.target)) {
      this.dropdownOpen.set(false);
    }
  }

  // Close on Escape key
  @HostListener('document:keydown.escape')
  onEsc(): void { this.dropdownOpen.set(false); }

  goToReminders(): void { this.router.navigate(['/reminders']); }

  priClass(p: string): string {
    return `pri-${p}`;   // pri-High, pri-Medium, pri-Low
  }

  get currentPage(): string {
    const url = this.router.url.split('?')[0].replace('/', '').replace(/-/g, ' ');
    return url ? url.replace(/\b\w/g, c => c.toUpperCase()) : 'Dashboard';
  }

  logout(): void { this.auth.logout(); }
}
