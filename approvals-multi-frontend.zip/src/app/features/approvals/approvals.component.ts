import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ApprovalService, ApprovalRequest, ApprovalCounts, ApprovalTaskSummary
} from '../../core/services/approval.service';
import { AuthService } from '../../core/services/auth.service';
import { PermissionsService } from '../../core/services/permissions.service';

type Tab = 'inbox' | 'sent' | 'resolved';
interface Toast { msg: string; type: 'success' | 'error'; }

// ── Group all requests for the same task together (for Sent tab) ───
interface TaskGroup {
  taskId: string;
  taskName: string;
  taskStatus: string;
  taskDue: string;
  message: string;
  createdAt: string;
  requesterName: string;
  requesterColor: string;
  reviewers: ApprovalRequest[];
  // computed
  approved: number;
  rejected: number;
  pending: number;
  total: number;
  allApproved: boolean;
  anyRejected: boolean;
  overallStatus: 'Pending' | 'Approved' | 'Rejected';
}

@Component({
  selector: 'app-approvals',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, FormsModule],
  templateUrl: './approvals.component.html',
  styleUrl: './approvals.component.css'
})
export class ApprovalsComponent implements OnInit {
  private readonly svc = inject(ApprovalService);
  readonly auth         = inject(AuthService);
  readonly perms        = inject(PermissionsService);

  readonly canEdit = computed(() => this.perms.canEdit('approvals'));

  // ── Raw data ──────────────────────────────────────────────────────
  requests = signal<ApprovalRequest[]>([]);
  counts   = signal<ApprovalCounts>({ inboxPending: 0, sentPending: 0, totalResolved: 0 });
  loading  = signal(true);
  toast    = signal<Toast | null>(null);

  // ── Pagination ────────────────────────────────────────────────────
  activeTab   = signal<Tab>('inbox');
  currentPage = signal(1);
  totalPages  = signal(1);
  totalItems  = signal(0);
  readonly PAGE_LIMIT = 20;

  readonly pageNumbers = computed(() => {
    const total = this.totalPages(), cur = this.currentPage();
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: (number | '...')[] = [1];
    if (cur > 3) pages.push('...');
    for (let p = Math.max(2, cur - 1); p <= Math.min(total - 1, cur + 1); p++) pages.push(p);
    if (cur < total - 2) pages.push('...');
    if (total > 1) pages.push(total);
    return pages;
  });

  // ── Sent tab: group by task ───────────────────────────────────────
  // When the sent tab is active we get requests enriched with taskReviewers.
  // We group them by task so the UI shows one card per task with all reviewers.
  readonly sentGroups = computed((): TaskGroup[] => {
    if (this.activeTab() !== 'sent') return [];
    const reqs = this.requests();
    const map = new Map<string, TaskGroup>();

    for (const r of reqs) {
      const tid  = typeof r.taskId === 'object' ? r.taskId._id : String(r.taskId);
      const siblings = r.taskReviewers?.length ? r.taskReviewers : [r];

      if (!map.has(tid)) {
        const approved = siblings.filter(s => s.status === 'Approved').length;
        const rejected = siblings.filter(s => s.status === 'Rejected').length;
        const pending  = siblings.filter(s => s.status === 'Pending').length;
        const total    = siblings.length;

        map.set(tid, {
          taskId:         tid,
          taskName:       typeof r.taskId === 'object' ? r.taskId.task : r.taskName,
          taskStatus:     typeof r.taskId === 'object' ? r.taskId.status : '',
          taskDue:        (typeof r.taskId === 'object' ? r.taskId.dueDate : '') || '',
          message:        r.message || '',
          createdAt:      r.createdAt,
          requesterName:  typeof r.requestedBy === 'object' ? r.requestedBy.name : r.requestedByName,
          requesterColor: (typeof r.requestedBy === 'object' ? r.requestedBy.color : '') || 'var(--accent)',
          reviewers:      siblings,
          approved, rejected, pending, total,
          allApproved:    approved === total && total > 0,
          anyRejected:    rejected > 0,
          overallStatus:  rejected > 0 ? 'Rejected' : approved === total && total > 0 ? 'Approved' : 'Pending',
        });
      }
    }
    return [...map.values()];
  });

  // ── Respond modal ─────────────────────────────────────────────────
  respondingId   = signal<string | null>(null);
  respondAction  = signal<'approve' | 'reject' | null>(null);
  respondComment = signal('');
  respondSaving  = signal(false);

  // ── Cancel confirm ────────────────────────────────────────────────
  cancellingTaskId = signal<string | null>(null);   // cancel all for a task

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.svc.list(this.activeTab(), this.currentPage(), this.PAGE_LIMIT).subscribe({
      next: res => {
        this.requests.set(res.data);
        this.counts.set(res.counts);
        this.totalItems.set(res.total);
        this.totalPages.set(res.pages);
        this.loading.set(false);
      },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.loading.set(false); }
    });
  }

  setTab(tab: Tab): void { this.activeTab.set(tab); this.currentPage.set(1); this.load(); }

  goToPage(p: number | '...'): void {
    if (p === '...' || p === this.currentPage()) return;
    this.currentPage.set(p as number); this.load();
  }
  prevPage(): void { if (this.currentPage() > 1) { this.currentPage.update(p => p - 1); this.load(); } }
  nextPage(): void { if (this.currentPage() < this.totalPages()) { this.currentPage.update(p => p + 1); this.load(); } }

  // ── Respond ───────────────────────────────────────────────────────
  openRespond(r: ApprovalRequest, action: 'approve' | 'reject'): void {
    this.respondingId.set(r._id);
    this.respondAction.set(action);
    this.respondComment.set('');
  }

  submitRespond(): void {
    const id  = this.respondingId();
    const act = this.respondAction();
    if (!id || !act || this.respondSaving()) return;
    this.respondSaving.set(true);
    this.svc.respond(id, act, this.respondComment()).subscribe({
      next: () => {
        this.respondingId.set(null);
        this.respondAction.set(null);
        this.respondSaving.set(false);
        this.showToast(`Request ${act === 'approve' ? 'approved ✓' : 'rejected ✕'} successfully.`, 'success');
        this.load();
      },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.respondSaving.set(false); }
    });
  }

  closeRespond(): void { this.respondingId.set(null); this.respondAction.set(null); }

  // ── Cancel all for a task ─────────────────────────────────────────
  confirmCancelTask(taskId: string): void { this.cancellingTaskId.set(taskId); }
  closeCancelTask(): void { this.cancellingTaskId.set(null); }

  submitCancelTask(): void {
    const taskId = this.cancellingTaskId();
    if (!taskId) return;
    // Cancel by taskId — backend cancels all pending for the task
    const req = this.requests().find(r => {
      const tid = typeof r.taskId === 'object' ? r.taskId._id : String(r.taskId);
      return tid === taskId && r.status === 'Pending';
    });
    if (!req) { this.cancellingTaskId.set(null); return; }
    this.svc.cancel(req._id).subscribe({
      next: () => { this.cancellingTaskId.set(null); this.showToast('All pending requests cancelled.', 'success'); this.load(); },
      error: (err: Error) => { this.showToast(err.message, 'error'); this.cancellingTaskId.set(null); }
    });
  }

  // ── Progress helpers ─────────────────────────────────────────────
  progressPct(g: TaskGroup): number {
    return g.total ? Math.round((g.approved / g.total) * 100) : 0;
  }

  progressColor(g: TaskGroup): string {
    if (g.anyRejected)  return 'var(--red)';
    if (g.allApproved)  return 'var(--green)';
    return 'var(--accent)';
  }

  reviewerStatusIcon(status: string): string {
    return status === 'Approved' ? '✓' : status === 'Rejected' ? '✕' : '⏳';
  }

  reviewerStatusCls(status: string): string {
    return status === 'Approved' ? 'rev-approved' : status === 'Rejected' ? 'rev-rejected' : 'rev-pending';
  }

  overallBadgeCls(g: TaskGroup): string {
    return g.anyRejected ? 'badge-rejected' : g.allApproved ? 'badge-approved' : 'badge-pending';
  }

  overallBadgeLabel(g: TaskGroup): string {
    if (g.anyRejected)  return '✕ Rejected';
    if (g.allApproved)  return '✓ All Approved';
    return `⏳ ${g.approved}/${g.total} Approved`;
  }

  // ── Display helpers ───────────────────────────────────────────────
  requesterName(r: ApprovalRequest): string {
    return typeof r.requestedBy === 'object' ? r.requestedBy.name : r.requestedByName;
  }
  reviewerName(r: ApprovalRequest): string {
    return typeof r.requestedTo === 'object' ? r.requestedTo.name : r.requestedToName;
  }
  requesterColor(r: ApprovalRequest): string {
    return (typeof r.requestedBy === 'object' ? r.requestedBy.color : '') || 'var(--accent)';
  }
  reviewerColor(r: ApprovalRequest): string {
    return (typeof r.requestedTo === 'object' ? r.requestedTo.color : '') || 'var(--accent)';
  }
  initials(name: string): string {
    return (name || '??').split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase();
  }
  taskTitle(r: ApprovalRequest): string {
    return typeof r.taskId === 'object' ? r.taskId.task : r.taskName;
  }
  taskStatus(r: ApprovalRequest): string {
    return typeof r.taskId === 'object' ? r.taskId.status : '';
  }
  taskDue(r: ApprovalRequest): string {
    return (typeof r.taskId === 'object' ? r.taskId.dueDate : '') || '';
  }
  statusBadgeCls(status: string): string {
    const m: Record<string, string> = {
      Pending: 'badge-pending', Approved: 'badge-approved',
      Rejected: 'badge-rejected', Cancelled: 'badge-cancelled',
    };
    return m[status] ?? '';
  }
  statusLabel(status: string): string {
    const m: Record<string, string> = {
      Pending: '⏳ Pending', Approved: '✓ Approved',
      Rejected: '✕ Rejected', Cancelled: '⊘ Cancelled',
    };
    return m[status] ?? status;
  }
  formatDate(iso: string): string {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: '2-digit' });
  }

  isRespondingTo(id: string): boolean  { return this.respondingId() === id; }
  isCancellingTask(tid: string): boolean { return this.cancellingTaskId() === tid; }

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private showToast(msg: string, type: 'success' | 'error'): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast.set({ msg, type });
    this.toastTimer = setTimeout(() => this.toast.set(null), 3500);
  }
}
